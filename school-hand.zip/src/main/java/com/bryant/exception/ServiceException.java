package com.bryant.exception;

import lombok.Getter;

/**
 @author greatcare
 @since 2022-05-12-15:06
 @detail
 */
@Getter
public class ServiceException extends RuntimeException {

    private String code;

    public ServiceException(String code, String msg) {
        super(msg);
        this.code = code;
    }

}
