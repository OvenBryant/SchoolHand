package com.bryant.exception;


import com.bryant.utils.Result;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 @author greatcare
 @since 2022-05-12-15:07
 @detail
 */
@RestControllerAdvice
public class MyGlobalExceptionHandler {

    /**
     * 如果抛出的异常是ServiceException，则调用该方法
     * @param se 业务异常
     * @return Result
     */
    @ExceptionHandler(ServiceException.class)
    public Result handle(ServiceException se){
        return Result.error(se.getCode(),se.getMessage());
    }

//    @ResponseStatus(HttpStatus.BAD_REQUEST) //设置状态码为 400
//    @ExceptionHandler({MethodArgumentNotValidException.class})
//    public Result paramExceptionHandler(ParamServiceException e) {
//        BindingResult exceptions = e.getBindingResult();
//        if (exceptions.hasErrors()) {
//            List<ObjectError> errors = exceptions.getAllErrors();
//            if (!errors.isEmpty()) {
//                FieldError fieldError = (FieldError) errors.get(0);
//                // 将错误信息封装到 Result 对象中返回
//                return Result.error(ConstantsState.CODE_400, fieldError.getDefaultMessage());
//            }
//        }
//
//        return Result.error(ConstantsState.CODE_400, "请求参数错误");
//    }

}
