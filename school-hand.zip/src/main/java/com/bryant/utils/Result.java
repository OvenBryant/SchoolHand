package com.bryant.utils;

import com.bryant.constant.ConstantsState;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 @author greatcare
 @since 2022-05-12-11:35
 @detail 返回对象
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result {

    private String code;
    private String msg;
    private Object data;

    /**
     * 只返回状态码
     * @return
     */
    public static Result success() {
        return new Result(ConstantsState.CODE_200, "", null);
    }

    /**
     * 只返回状态码和传入的参数
     * @param data
     * @return
     */
    public static Result success(Object data) {
        return new Result(ConstantsState.CODE_200, "", data);
    }

    /**
     * 返回状态码和消息
     * @param code
     * @param msg
     * @return
     */
    public static Result error(String code, String msg) {
        return new Result(code, msg, null);
    }

    /**
     * 系统错误
     * @return
     */
    public static Result error() {
        return new Result(ConstantsState.CODE_500, "系统错误", null);
    }
}
