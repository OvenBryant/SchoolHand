package com.bryant.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bryant.model.User;
import com.bryant.model.vo.RegisterVo;
import com.bryant.utils.Result;

public interface IRegisterService extends IService<User> {

    Result getPhoneCode(String phone);

    Result registerUser(RegisterVo registerVo);

}
