package com.bryant.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bryant.model.Notice;
import com.bryant.model.vo.UserAdminVo.Ids;
import com.bryant.model.vo.UserAdminVo.NoticeIdDTO;
import com.bryant.model.vo.UserAdminVo.PageRequestNotice;
import com.bryant.utils.Result;

public interface INoticeService extends IService<Notice> {

    Result listNoticePage(PageRequestNotice pageRequestNotice);

    Result updateNotice(Notice notice);

    Result addNotice(Notice notice);

    Result getLatestFiveNotices();

    Result updateCurrentNotice(Notice notice);

    Result updateNoticeDeleteById(Ids ids);
}
