package com.bryant.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bryant.model.Logs;
import com.bryant.model.vo.UserAdminVo.OperIdDTO;
import com.bryant.model.vo.UserAdminVo.PageRequestLog;
import com.bryant.utils.Result;

public interface IUserAdminLogsService extends IService<Logs> {

    Result PageRequestLog(PageRequestLog pageRequestLog);

    Result deleteMoreByOperId(OperIdDTO operIdDTO);

    Result updateLogsDeleteAll();

}
