package com.bryant.service.aop;

import cn.hutool.core.lang.Dict;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.thread.ThreadUtil;
import cn.hutool.core.util.ObjectUtil;
import com.bryant.annotation.Log;
import com.bryant.enums.BusinessStatus;
import com.bryant.model.Logs;
import com.bryant.model.User;
import com.bryant.service.IUserAdminLogsService;
import com.bryant.utils.JsonUtils;
import com.bryant.utils.JwtTokenUtils;
import com.bryant.utils.Result;
import com.bryant.utils.ServletUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Map;

/**
 * 操作日志记录处理
 */
@Slf4j
@Aspect
@Component
public class LogAspect {


    /**
     * 排除敏感属性字段
     */
    public static final String[] EXCLUDE_PROPERTIES = { "password", "oldPassword", "newPassword", "confirmPassword" };

    @Resource
    IUserAdminLogsService iUserAdminLogsService;

    /**
     * 处理完请求后执行
     *
     * @param joinPoint 切点
     */
    @AfterReturning(pointcut = "@annotation(controllerLog)", returning = "jsonResult")
    public void doAfterReturning(JoinPoint joinPoint, Log controllerLog, Object jsonResult) {
        handleLog(joinPoint, controllerLog, null, jsonResult);
    }

    /**
     * 拦截异常操作
     *
     * @param joinPoint 切点
     * @param e         异常
     */
    @AfterThrowing(value = "@annotation(controllerLog)", throwing = "e")
    public void doAfterThrowing(JoinPoint joinPoint, Log controllerLog, Exception e) {
        handleLog(joinPoint, controllerLog, e, null);
    }

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * 日志AOP
     */
    protected void handleLog(final JoinPoint joinPoint, Log controllerLog, final Exception e, Object jsonResult) {
        try {
            User loginUser = JwtTokenUtils.getCurrentUser();
            if (loginUser == null) { // 用户没有登录的情况下,loginUser为null,如果我们要记录登录注册的日志,可以使用参数或者返回值
                Result result = (Result) jsonResult;

                Object data = result.getData();
                if(data instanceof User){
                    loginUser= (User) data;
                }
            }
            if(loginUser == null){
                log.error("记录日志信息报错,未获取到当前操作用户信息");
                return;
            }
            // 设置方法名称
            String className = joinPoint.getTarget().getClass().getName();
            String methodName = joinPoint.getSignature().getName();
            // 主机地址
            String ip = ServletUtils.getClientIP();
            Logs logs = Logs.builder()
                    .title(controllerLog.title())
                    .businessType(controllerLog.businessType().getValue())
                    .method(className + "." + methodName + "()")
                    .requestMethod(ServletUtils.getRequest().getMethod())
                    .operName(loginUser.getUsername())
                    .operUrl(StringUtils.substring(ServletUtils.getRequest().getRequestURI(),0,255))
                    .operIp(ip)
                    .operParam("")
                    .jsonResult("")
                    .status(BusinessStatus.SUCCESS.ordinal())
                    .operTime(new Date())
                    .build();


            if (e != null) {
                logs.setStatus(BusinessStatus.FAIL.ordinal());
                logs.setErrorMsg(StringUtils.substring(e.getMessage(), 0, 2000));
            }

            if(controllerLog.isSaveRequestData()){
                // 获取参数的信息，传入到数据库中。
                setRequestValue(joinPoint, logs, controllerLog.excludeParamNames());
            }
            // 是否需要保存response，参数和值
            if (controllerLog.isSaveResponseData() && ObjectUtil.isNotNull(jsonResult)) {
                logs.setJsonResult(StringUtils.substring(JsonUtils.toJsonString(jsonResult), 0, 2000));
            }

            // 插入数据到数据库中
            ThreadUtil.execAsync(()->{
                iUserAdminLogsService.save(logs);
            });

        } catch (Exception exp) {
            // 记录本地异常日志
            log.error("异常信息:{}", exp.getMessage());
            exp.printStackTrace();
        }
    }

    private void setRequestValue(JoinPoint joinPoint, Logs logs, String[] excludeParamNames) throws Exception {
        Map<String, String> paramsMap = ServletUtils.getParamMap(ServletUtils.getRequest());
        String requestMethod = logs.getRequestMethod();
        if (MapUtil.isEmpty(paramsMap)
                && HttpMethod.PUT.name().equals(requestMethod) || HttpMethod.POST.name().equals(requestMethod)) {
            String params = argsArrayToString(joinPoint.getArgs(), excludeParamNames);
            logs.setOperParam(StringUtils.substring(params, 0, 2000));
        } else {
            MapUtil.removeAny(paramsMap, EXCLUDE_PROPERTIES);
            MapUtil.removeAny(paramsMap, excludeParamNames);
            logs.setOperParam(StringUtils.substring(JsonUtils.toJsonString(paramsMap), 0, 2000));
        }
    }


    /**
     * 参数拼装
     */
    private String argsArrayToString(Object[] paramsArray, String[] excludeParamNames) {
        StringBuilder params = new StringBuilder();
        if (paramsArray != null && paramsArray.length > 0) {
            for (Object o : paramsArray) {
                if (ObjectUtil.isNotNull(o) && !isFilterObject(o)) {
                    try {
                        String str = JsonUtils.toJsonString(o);
                        Dict dict = JsonUtils.parseMap(str);
                        if (MapUtil.isNotEmpty(dict)) {
                            MapUtil.removeAny(dict, EXCLUDE_PROPERTIES);
                            MapUtil.removeAny(dict, excludeParamNames);
                            str = JsonUtils.toJsonString(dict);
                        }
                        params.append(str).append(" ");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return params.toString().trim();
    }

    /**
     * 判断是否需要过滤的对象。
     *
     * @param o 对象信息。
     * @return 如果是需要过滤的对象，则返回true；否则返回false。
     */
    @SuppressWarnings("rawtypes")
    public boolean isFilterObject(final Object o) {
        Class<?> clazz = o.getClass();
        if (clazz.isArray()) {
            return clazz.getComponentType().isAssignableFrom(MultipartFile.class);
        } else if (Collection.class.isAssignableFrom(clazz)) {
            Collection collection = (Collection) o;
            for (Object value : collection) {
                return value instanceof MultipartFile;
            }
        } else if (Map.class.isAssignableFrom(clazz)) {
            Map map = (Map) o;
            for (Object value : map.entrySet()) {
                Map.Entry entry = (Map.Entry) value;
                return entry.getValue() instanceof MultipartFile;
            }
        }
        return o instanceof MultipartFile || o instanceof HttpServletRequest || o instanceof HttpServletResponse
                || o instanceof BindingResult;
    }
}
