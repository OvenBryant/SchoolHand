package com.bryant.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bryant.model.User;
import com.bryant.utils.Result;

public interface IUserService extends IService<User> {

    Result getCurrentUser(String usernameOrPhone);

    Result updateUserBasicInfoByUsername(User user);

    Result getpwdByUsername(String username, String oldPwd);

    Result resetPwdByUsername(String username, String oldPwd, String newPwd, String surePwd);

    Result validCurrentPhoneByUsername(String username, String phone);

    Result verifyPhoneFirstStep(String username, String phone, String captcha);

    Result verifyPhoneTwoStep(String username, String oldPhone, String newPhone, String captcha);

    Result validCurrentEmailByUsername(String username, String email);

    Result getQQEmailCaptcha(String email);

    Result updateNewQQEmailByUsername(String username, String email, String captcha, String newEmail);
}
