package com.bryant.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bryant.model.User;
import com.bryant.model.vo.Audits.ProductAuditsAndRecordAndUserInfo;
import com.bryant.model.vo.PageRequest;
import com.bryant.model.vo.UserAdminVo.AdminAddUser;
import com.bryant.model.vo.UserAdminVo.IdsDTO;
import com.bryant.utils.Result;
import org.springframework.validation.BindingResult;

public interface IUserAdminService extends IService<User> {

    Result listUserByPage(PageRequest pageRequest);

    Result updateUserIsDeleteById(IdsDTO idsDTO);

    Result updateUserIsStatusById(IdsDTO idsDTO);

    Result addUser(AdminAddUser adminAddUser, BindingResult resultMessage);

    Result getOneUser(String id);

    Result updateUser(User user);

    Result getAuditsInfoList(String status, String productName, String currentUser);

    Result postAuditsInfo(String isSuccess,ProductAuditsAndRecordAndUserInfo productAuditsAndRecordAndUserInfo);

    Result getAdminHomeData();

    // Result updateUserStatusById(long[] ids);
}
