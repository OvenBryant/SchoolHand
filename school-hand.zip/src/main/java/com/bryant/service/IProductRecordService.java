package com.bryant.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bryant.model.Product;
import com.bryant.model.ProductRecord;
import com.bryant.model.vo.Product.PageRequestProduct;
import com.bryant.model.vo.UserAdminVo.Ids;
import com.bryant.utils.Result;

public interface IProductRecordService extends IService<ProductRecord> {

    Result addProductRecord(ProductRecord productRecord);

    Result getProductRecordAndAudits();

    Result getAuditsList(String auditsStatus, String productName);
}
