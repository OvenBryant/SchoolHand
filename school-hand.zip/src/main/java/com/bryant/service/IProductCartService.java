package com.bryant.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bryant.model.ProductCart;
import com.bryant.model.ProductRecord;
import com.bryant.model.vo.ProductCart.LjBuy;
import com.bryant.utils.Result;

public interface IProductCartService extends IService<ProductCart> {

    Result addProductCart(Long product_id);

    Result updateProductCartById(Long id);

    Result listProductCart();

    Result MyProduct();

    Result ljBuyProduct(LjBuy ljBuy);

    Result getProductHistoryOnOrders();
}
