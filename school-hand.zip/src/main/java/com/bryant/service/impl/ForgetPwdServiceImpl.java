package com.bryant.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bryant.constant.ConstantsState;
import com.bryant.email.utils.QQEmailTemplate;
import com.bryant.exception.ServiceException;
import com.bryant.mapper.UserMapper;
import com.bryant.model.User;
import com.bryant.service.IForgetPwdService;
import com.bryant.utils.PubMethods;
import com.bryant.utils.Result;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class ForgetPwdServiceImpl extends ServiceImpl<UserMapper, User> implements IForgetPwdService {

    @Resource
    private QQEmailTemplate qqEmailTemplate;


    @Override
    public Result forgetPwdByEmail(String phone, String email) {

        if(StrUtil.isBlank(phone)||StrUtil.isBlank(email)){
            throw new ServiceException(ConstantsState.CODE_404,"手机号或邮箱不能为空...");
        }
        if(!PubMethods.isValidEmail(email)){
            throw new ServiceException(ConstantsState.CODE_404,"QQ邮箱错误...");
        }
        if(!PubMethods.isValidPhoneNumber(phone)){
            throw new ServiceException(ConstantsState.CODE_404,"手机号格式错误...");
        }

        QueryWrapper<User> queryWrapper = new QueryWrapper();
        queryWrapper.eq("phone",phone);
        queryWrapper.eq("email",email);
        User user = this.getOne(queryWrapper);
        if(user==null){
            throw new ServiceException(ConstantsState.CODE_404,"当前邮箱与手机号不匹配，请检查输入信息!");
        }else{

      //      发送QQ邮箱
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        qqEmailTemplate.sendMessage("密码回溯","您的原始密码是："+user.getPassword());
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }).start();

            return Result.success();
        }

    }

    @Override
    public Result validPhone(String phone) {

        // TODO 手机号不能为空
        if(StrUtil.isBlank(phone)){
            throw new ServiceException(ConstantsState.CODE_404,"手机号不能为空...");
        }

        // TODO  当前手机号是否规范
        if(!PubMethods.isValidPhoneNumber(phone)){
            throw new ServiceException(ConstantsState.CODE_404,"手机号格式错误...");
        }

        // TODO  数据库中是否存在该手机号
        QueryWrapper<User> queryWrapper = new QueryWrapper();
        queryWrapper.eq("phone",phone);
        User user = this.getOne(queryWrapper);
        if(user==null){
            throw new ServiceException(ConstantsState.CODE_404,"当前手机号未注册");
        }
        return Result.success();

    }
}
