package com.bryant.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bryant.constant.ConstantsState;
import com.bryant.mapper.UserAdminLogsMapper;
import com.bryant.model.Logs;
import com.bryant.model.vo.UserAdminVo.OperIdDTO;
import com.bryant.model.vo.UserAdminVo.PageRequestLog;
import com.bryant.service.IUserAdminLogsService;
import com.bryant.utils.Result;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class UserAdminLogsServiceImpl extends ServiceImpl<UserAdminLogsMapper, Logs> implements IUserAdminLogsService {

    @Resource
    UserAdminLogsMapper userAdminLogsMapper;

    @Override
    public Result PageRequestLog(PageRequestLog pageRequestLog) {

        long current = pageRequestLog.getPageNo();
        long size = pageRequestLog.getPageSize();

        Page<Logs> page = new Page<>(current, size);
        QueryWrapper<Logs> queryWrapper = new QueryWrapper<>();
        if(StringUtils.isNotBlank(pageRequestLog.getTitle())){
            queryWrapper.like("title",pageRequestLog.getTitle());
        }
        if(StringUtils.isNotBlank(pageRequestLog.getOperName())){
            queryWrapper.like("oper_name",pageRequestLog.getOperName());
        }
        if(StringUtils.isNotBlank(pageRequestLog.getBusinessType())){
            queryWrapper.eq("business_type",pageRequestLog.getBusinessType());
        }
        if(StringUtils.isNotBlank(pageRequestLog.getStatus())){
            if("成功".equals(pageRequestLog.getStatus())){
                queryWrapper.eq("status",0);
            }if("失败".equals(pageRequestLog.getStatus())){
                queryWrapper.eq("status",1);
            }
        }
        if(StringUtils.isNotBlank(pageRequestLog.getStopOperTime())){
            queryWrapper.ge("oper_time",pageRequestLog.getStartOperTime());
        }
        if(StringUtils.isNotBlank(pageRequestLog.getStopOperTime())){
            queryWrapper.le("oper_time",pageRequestLog.getStopOperTime());
        }

        // 升序、降序、取消排序
        if (StringUtils.isNotBlank(pageRequestLog.getSortField()) && StringUtils.isNotBlank(pageRequestLog.getSortOrder())) {
            String column = pageRequestLog.getSortField();  // operTime
            String order = pageRequestLog.getSortOrder();  // ascend
            if ("ascend".equalsIgnoreCase(order)) {
                queryWrapper.orderByAsc(column);
            } else if ("descend".equalsIgnoreCase(order)) {
                queryWrapper.orderByDesc(column);
            }
        }else{  // 如果为空,则默认降序
            queryWrapper.orderByDesc("operTime");
        }

        Page<Logs> result = this.page(page,queryWrapper);
        return Result.success(result);
    }

    @Override
    public Result deleteMoreByOperId(OperIdDTO operIdDTO) {
        List<Long> operId = operIdDTO.getOperId();
        if(operId==null || operId.isEmpty()){
            return Result.error(ConstantsState.CODE_404,"参数不能为空");
        }
        boolean b = this.removeBatchByIds(operId);
        if(b){
            return Result.success();
        }else{
            return Result.error();
        }
    }

    @Override
    public Result updateLogsDeleteAll() {
        int flag = userAdminLogsMapper.delete(null);
        if(flag!=-1){
            return Result.success();
        }else{
            return Result.error();
        }
    }

}
