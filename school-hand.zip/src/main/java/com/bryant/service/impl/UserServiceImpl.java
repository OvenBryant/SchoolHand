package com.bryant.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bryant.constant.ConstantsState;
import com.bryant.email.utils.QQEmailTemplate;
import com.bryant.exception.ServiceException;
import com.bryant.mapper.UserMapper;
import com.bryant.model.User;
import com.bryant.service.IUserService;
import com.bryant.utils.PubMethods;
import com.bryant.utils.RedisUtils;
import com.bryant.utils.Result;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {


    @Resource
    private QQEmailTemplate qqEmailTemplate;


    @Override
    public Result getCurrentUser(String usernameOrPhone) {

        User user = new User();

        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.or(i -> i.eq("username", usernameOrPhone).or().eq("phone", usernameOrPhone));

        User u = this.getOne(queryWrapper);
        if (u != null) {
            user.setUsername(u.getUsername());
            user.setNickname(u.getNickname());
            user.setSex(u.getSex());
            user.setPhone(u.getPhone());
            user.setEmail(u.getEmail());
            user.setPersProfile(u.getPersProfile());
            user.setAvatar(u.getAvatar());
            user.setRole(u.getRole());
        } else {
            return Result.error(ConstantsState.CODE_404, "当前用户异常!");
        }
        return Result.success(user);
    }

    @Override
    public Result updateUserBasicInfoByUsername(User user) {
        UpdateWrapper<User> updateUser = new UpdateWrapper<>();
        updateUser.eq("username", user.getUsername())
                .set("nickname", user.getNickname())
                .set("sex", user.getSex())
                .set("avatar", user.getAvatar())
                .set("persProfile", user.getPersProfile());
        boolean bool = this.update(updateUser);
        if (bool) {
            return Result.success();
        } else {
            return Result.error();
        }
    }

    @Override
    public Result getpwdByUsername(String username, String oldPwd) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        User user = this.getOne(queryWrapper);
        if (user != null) {
            String password = user.getPassword();
            if (password.equals(oldPwd)) {
                return Result.success();
            } else {
                return Result.error(ConstantsState.CODE_404, "原始密码错误!");
            }
        } else {
            return Result.error(ConstantsState.CODE_404, "当前用户不存在!");
        }
    }

    @Override
    public Result resetPwdByUsername(String username, String oldPwd, String newPwd, String surePwd) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        User user = this.getOne(queryWrapper);
        if (user != null) {
            String password = user.getPassword();
            if (password.equals(oldPwd)) {
                if (newPwd.equals(surePwd)) {
                    UpdateWrapper<User> update = new UpdateWrapper<>();
                    update.eq("username", username).set("password", newPwd);
                    boolean flag = this.update(update);
                    if (flag) {
                        return Result.success();
                    } else {
                        return Result.error();
                    }
                } else {
                    throw new ServiceException(ConstantsState.CODE_404, "新密码不一致!");
                }
            } else {
                return Result.error(ConstantsState.CODE_404, "原始密码错误!");
            }
        } else {
            return Result.error(ConstantsState.CODE_404, "当前用户不存在!");
        }

    }

    @Override
    public Result validCurrentPhoneByUsername(String username, String phone) {
        if (StrUtil.isBlank(username)) {
            throw new ServiceException(ConstantsState.CODE_404, "账号不能为空");
        }
        if (StrUtil.isBlank(phone)) {
            throw new ServiceException(ConstantsState.CODE_404, "手机号不能为空");
        }
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        User user = this.getOne(queryWrapper);
        if (user != null) {
            // 判断手机号是否正确
            if (phone.equals(user.getPhone())) {
                return Result.success();
            } else {
                return Result.error();
            }
        } else {
            return Result.error();
        }
    }

    @Override
    public Result verifyPhoneFirstStep(String username, String phone, String captcha) {
        if (StrUtil.isBlank(username)) {
            throw new ServiceException(ConstantsState.CODE_404, "账号不能为空");
        }
        if (StrUtil.isBlank(phone)) {
            throw new ServiceException(ConstantsState.CODE_404, "手机号不能为空");
        }
        if (StrUtil.isBlank(captcha)) {
            throw new ServiceException(ConstantsState.CODE_404, "验证码不能为空");
        }
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        queryWrapper.eq("phone", phone);
        User user = this.getOne(queryWrapper);

        if (user != null) {
            // 要从redis获取验证码,有效期5分钟
            boolean hkey = RedisUtils.Hkey(phone);
            if (hkey) {
                String redisCaptcha = (String) RedisUtils.get(phone);
                if (!StrUtil.isBlank(redisCaptcha)) {
                    if (redisCaptcha.equals(captcha)) {
                        return Result.success();
                    } else {
                        return Result.error(ConstantsState.CODE_404, "验证码不正确");
                    }

                } else {
                    return Result.error(ConstantsState.CODE_404, "验证码不能为空");
                }
            } else {
                return Result.error(ConstantsState.CODE_404, "请点击获取验证码按钮...");
            }

        } else {
            return Result.error(ConstantsState.CODE_404, "手机号或账号有误!");
        }
    }

    @Override
    public Result verifyPhoneTwoStep(String username, String oldPhone, String newPhone, String captcha) {
        if (StrUtil.isBlank(username)) {
            throw new ServiceException(ConstantsState.CODE_404, "账号不能为空");
        }
        if (StrUtil.isBlank(oldPhone)) {
            throw new ServiceException(ConstantsState.CODE_404, "旧的手机号不能为空");
        }
        if (StrUtil.isBlank(newPhone)) {
            throw new ServiceException(ConstantsState.CODE_404, "新手机号不能为空");
        }
        if (StrUtil.isBlank(captcha)) {
            throw new ServiceException(ConstantsState.CODE_404, "验证码不能为空");
        }

        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        queryWrapper.eq("phone", oldPhone);
        User user = this.getOne(queryWrapper);

        if (user != null) {
            // 要从redis获取验证码,有效期5分钟
            boolean hkey = RedisUtils.Hkey(newPhone);
            if (hkey) {
                String redisCaptcha = (String) RedisUtils.get(newPhone);
                if (!StrUtil.isBlank(redisCaptcha)) {
                    if (redisCaptcha.equals(captcha)) {
                        // 验证码正确则, 更换手机号
                       UpdateWrapper<User> updateWrapper = new UpdateWrapper<>();
                       updateWrapper.eq("username",username).eq("phone",oldPhone)
                               .set("phone",newPhone);
                        boolean flag = this.update(updateWrapper);
                        if(flag){
                            return Result.success();
                        }else{
                            return Result.error();
                        }
                    } else {
                        return Result.error(ConstantsState.CODE_404, "验证码不正确");
                    }

                } else {
                    return Result.error(ConstantsState.CODE_404, "验证码不能为空");
                }
            } else {
                return Result.error(ConstantsState.CODE_404, "请点击获取验证码按钮...");
            }

        } else {
            return Result.error(ConstantsState.CODE_404, "请完成第一步,手机号或账号有误!");
        }

    }

    @Override
    public Result validCurrentEmailByUsername(String username, String email) {

        if (StrUtil.isBlank(username)) {
            throw new ServiceException(ConstantsState.CODE_404, "账号不能为空");
        }
        if (StrUtil.isBlank(email)) {
            throw new ServiceException(ConstantsState.CODE_404, "邮箱不能为空");
        }
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        User user = this.getOne(queryWrapper);
        if (user != null) {
            // 判断手机号是否正确
            if (email.equals(user.getEmail())) {
                return Result.success();
            } else {
                return Result.error();
            }
        } else {
            return Result.error();
        }
    }


    @Override
    public Result getQQEmailCaptcha(String email) {
        // 需要把邮箱存入redis,然后发送验证码到邮箱
        // 前端验证的时候,5分钟过期时间
        if(StrUtil.isBlank(email)){
            throw new ServiceException(ConstantsState.CODE_404, "邮箱不能为空");
        }if(!PubMethods.isValidEmail(email)){
            throw new ServiceException(ConstantsState.CODE_404,"QQ邮箱错误...");
        }
        boolean hkey = RedisUtils.Hkey(email);
        if(hkey){
            String value = (String) RedisUtils.get(email);
            return Result.success(value);
        }else{
            String code = PubMethods.getSixBitRandom();
            // 设置5分钟验证码
            RedisUtils.set(email,code,5, TimeUnit.MINUTES);

            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        qqEmailTemplate.sendMessage("QQ邮箱验证码","您的验证码是："+code);
//                        QQEmailTemplate qqEmailTemplate = new QQEmailTemplate(email,"QQ邮箱验证码","[校园二手交易平台]您的验证码是: ");
//                        qqEmailTemplate.sendMessage(code);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }).start();

            return Result.success(code);

        }

    }

    @Override
    public Result updateNewQQEmailByUsername(String username, String email, String captcha, String newEmail) {
        if(StrUtil.isBlank(username)){
            throw new ServiceException(ConstantsState.CODE_404, "账号不能为空");
        }
        if(StrUtil.isBlank(email)){
            throw new ServiceException(ConstantsState.CODE_404, "QQ邮箱不能为空");
        }
        if(StrUtil.isBlank(captcha)){
            throw new ServiceException(ConstantsState.CODE_404,"原始QQ邮箱的验证码不能为空");
        }
        if(StrUtil.isBlank(newEmail)){
            throw new ServiceException(ConstantsState.CODE_404,"新的QQ邮箱不能为空");
        }
        if(!PubMethods.isValidEmail(email)){
            throw new ServiceException(ConstantsState.CODE_404,"原始QQ邮箱错误...");
        }
        if(!PubMethods.isValidEmail(newEmail)){
            throw new ServiceException(ConstantsState.CODE_404,"新的QQ邮箱错误...");
        }

        Result result = this.validCurrentEmailByUsername(username, email);
        if("200".equals(result.getCode())){
            boolean hkey = RedisUtils.Hkey(email);
            if(hkey){
                String value = (String) RedisUtils.get(email);
                if(StrUtil.equals(captcha,value)){
                    // 更新QQ邮箱
                    UpdateWrapper<User> userUpdateWrapper = new UpdateWrapper<>();
                    userUpdateWrapper.eq("username",username).eq("email",email)
                            .set("email",newEmail);
                    boolean updateFlag = this.update(userUpdateWrapper);
                    if(updateFlag){
                        return Result.success();
                    }else{
                        return Result.error();
                    }

                }else{
                    throw new ServiceException(ConstantsState.CODE_404,"验证码有误!");
                }
            }else{
                return Result.error(ConstantsState.CODE_404, "请点击获取验证码按钮...");
            }
        }else{
            return Result.error(ConstantsState.CODE_404,"原始邮箱不匹配!");
        }

    }
}
