package com.bryant.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bryant.constant.ConstantsState;
import com.bryant.exception.ServiceException;
import com.bryant.mapper.OrderMapper;
import com.bryant.mapper.ProductCartMapper;
import com.bryant.mapper.ProductMapper;
import com.bryant.mapper.UserAddressMapper;
import com.bryant.model.*;
import com.bryant.model.vo.Orders.HistoryProductOnOrders;
import com.bryant.model.vo.ProductCart.LjBuy;
import com.bryant.model.vo.ProductCart.ProductCartAndProduct;
import com.bryant.service.IProductCartService;
import com.bryant.utils.JwtTokenUtils;
import com.bryant.utils.Result;
import com.bryant.utils.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.Random;

@Service
public class ProductCartServiceImpl extends ServiceImpl<ProductCartMapper, ProductCart> implements IProductCartService {


    @Resource
    ProductCartMapper productCartMapper;

    @Resource
    ProductMapper productMapper;

    @Resource
    OrderMapper orderMapper;

    @Resource
    UserAddressMapper userAddressMapper;

    @Transactional
    @Override
    public Result addProductCart(Long product_id) {

        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_401, "用户异常,请重新登录");
        }
        if (product_id == null || product_id < 0) {
            throw new ServiceException(ConstantsState.CODE_404, "商品ID不能为空,并且不能小于0");
        }

        // 查找购物车中的条目
        ProductCart existingPro = productCartMapper.findProductCartByUserIdAndProductId(currentUser.getId(), product_id);
        if (existingPro == null) {
            ProductCart pro = new ProductCart();
            pro.setUserId(currentUser.getId());
            pro.setProductId(product_id);

            boolean save = this.save(pro);
            if (save) {
                return Result.success();
            } else {
                return Result.error();
            }
        } else {
            return Result.success();
        }
    }

    @Override
    public Result updateProductCartById(Long id) {
        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_401, "用户异常,请重新登录");
        }
        if (id == null || id < 0) {
            throw new ServiceException(ConstantsState.CODE_404, "id不能为空,并且不能小于0");
        }

        // 创建 UpdateWrapper 实例
//        UpdateWrapper<ProductCart> updateWrapper = new UpdateWrapper<>();
//        updateWrapper.eq("id", id);
//        updateWrapper.set("is_delete", 1);


        LambdaUpdateWrapper<ProductCart> updateWrapper = Wrappers.lambdaUpdate();
        updateWrapper.eq(ProductCart::getId, id);
        updateWrapper.set(ProductCart::getIsDelete, 1);

        boolean updateResult = this.update(updateWrapper);

        if (updateResult) {
            return Result.success("删除成功");
        } else {
            return Result.error(ConstantsState.CODE_404, "操作失败");
        }

    }

    @Override
    public Result listProductCart() {

        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_401, "用户异常,请重新登录");
        }

        List<ProductCartAndProduct> list = productCartMapper.listProductCart(currentUser.getId());
        return Result.success(list);
        // 检查列表是否为空或者不存在（为null）
//        if (list == null || list.isEmpty()) {
//            // 列表为空或不存在（为null），返回错误结果
//            return Result.error(ConstantsState.CODE_404, "List is empty or does not exist");
//        } else {
//            // 列表非空，返回成功结果
//            return Result.success(list);
//        }

    }

    @Override
    public Result MyProduct() {
        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_401, "用户异常,请重新登录");
        }

        QueryWrapper<Product> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", currentUser.getId());
        queryWrapper.eq("isDelete",0);
        queryWrapper.orderByDesc("createTime");
        List<Product> products = productMapper.selectList(queryWrapper);
        return Result.success(products);
    }

    @Transactional
    @Override
    public Result ljBuyProduct(LjBuy ljBuy) {

        /**
         *     1. todo 当前用户是否存在
         *     2. todo 用户一致
         *     3. todo 当前商品是否存在（有效状态）在售、下架  其实可以不查询这个，
         *     todo 因为都是在售的商品才公布出来，所以购买商品的时候，基本上都是在售的,但也可以保险一点
         *     4. todo 生成订单
         *     5. todo 更新商品库存
          */

        if(ljBuy.getUserId()==null || ljBuy.getUserId() < 1 ){
            throw new ServiceException(ConstantsState.CODE_401, "当前用户异常");
        }
        if(ljBuy.getProductId()==null || ljBuy.getProductId() < 1){
            throw new ServiceException(ConstantsState.CODE_404, "当前商品异常");
        }
        if(ljBuy.getBuilding()==null || ljBuy.getBuilding() < 1 ){
            throw new ServiceException(ConstantsState.CODE_404, "楼宇异常");
        }
        if(ljBuy.getFloor()==null || ljBuy.getFloor() < 1){
            throw new ServiceException(ConstantsState.CODE_404, "楼层异常");
        }
        if(ljBuy.getRoomNumber()==null || ljBuy.getRoomNumber() < 1){
            throw new ServiceException(ConstantsState.CODE_404, "寝室号异常");
        }
        if(StringUtils.isEmpty(ljBuy.getFullAddress())){
            throw new ServiceException(ConstantsState.CODE_404, "详细地址不能为空");
        }

        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_401, "用户异常,请重新登录");
        }
        // 获取当期商品状态是 在售 还是 下架
        Product resultPro = productMapper.getProduct(ljBuy.getUserId(),ljBuy.getProductId());
        if(resultPro.getStatus()==1){   // 生成订单
            Orders order = new Orders();
            order.setOrderId(getOrderId());
            order.setProductId(ljBuy.getProductId());
            order.setUserId(currentUser.getId());
            order.setAddress(joinAddress(ljBuy.getBuilding(), ljBuy.getFloor(), ljBuy.getRoomNumber(), ljBuy.getFullAddress()));
            order.setTotalPrice(resultPro.getSalePrice());
            UserAddress userAddress = new UserAddress();
            userAddress.setUserId(currentUser.getId());
            userAddress.setBuilding(ljBuy.getBuilding());
            userAddress.setFloor(ljBuy.getFloor());
            userAddress.setRoomNumber(ljBuy.getRoomNumber());
            userAddress.setFullAddress(ljBuy.getFullAddress());
            QueryWrapper<UserAddress> queryWrapperAddress = new QueryWrapper<>();
            queryWrapperAddress.eq("user_id",currentUser.getId());
            UserAddress add = userAddressMapper.selectOne(queryWrapperAddress);
            if(add!=null){
                userAddressMapper.updateByUserId(currentUser.getId(),ljBuy.getBuilding(),ljBuy.getFloor(),ljBuy.getRoomNumber(),ljBuy.getFullAddress());
            }else{
                userAddressMapper.insert(userAddress);
            }
            orderMapper.insert(order);
            // 修改商品为下架
            productMapper.updateByIdStatus(ljBuy.getProductId());
            return Result.success();
        }else{
            throw new ServiceException(ConstantsState.CODE_404, "当前商品已售完");
        }
    }

    @Override
    public Result getProductHistoryOnOrders() {

        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_401, "用户异常,请重新登录");
        }

        List<HistoryProductOnOrders> list = orderMapper.getProductHistoryOnOrders(currentUser.getId());
        return Result.success(list);
    }

    private Long getOrderId(){
        Long timestamp = System.currentTimeMillis() % 1000000000;
        int random = new Random().nextInt(1000); // 假设我们只需要一个较小的随机范围
        return timestamp + random;
    }

    private String joinAddress(Integer building,Integer floor,Integer roomNumber,String fullAddress){
       return building+","+floor+","+roomNumber+","+fullAddress;
    }
}
