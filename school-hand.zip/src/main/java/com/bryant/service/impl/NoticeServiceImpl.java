package com.bryant.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bryant.constant.ConstantsState;
import com.bryant.exception.ServiceException;
import com.bryant.mapper.NoticeMapper;
import com.bryant.model.Notice;
import com.bryant.model.User;
import com.bryant.model.vo.UserAdminVo.Ids;
import com.bryant.model.vo.UserAdminVo.NoticeIdDTO;
import com.bryant.model.vo.UserAdminVo.PageRequestNotice;
import com.bryant.service.INoticeService;
import com.bryant.utils.JwtTokenUtils;
import com.bryant.utils.Result;
import org.springframework.stereotype.Service;

import javax.swing.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class NoticeServiceImpl extends ServiceImpl<NoticeMapper, Notice> implements INoticeService {

    /**
     * 分页查询最新的通知公告
     * @param pageRequestNotice
     * @return
     */
    @Override
    public Result listNoticePage(PageRequestNotice pageRequestNotice) {
        long current = pageRequestNotice.getPageNo();
        long size = pageRequestNotice.getPageSize();

        Page<Notice> page = new Page<>(current, size);
        QueryWrapper<Notice> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotBlank(pageRequestNotice.getTitle())) {
            queryWrapper.like("title", pageRequestNotice.getTitle());
        }
        if (StringUtils.isNotBlank(pageRequestNotice.getCreateBy())) {
            queryWrapper.like("create_by", pageRequestNotice.getCreateBy());
        }
        if (StringUtils.isNotBlank(pageRequestNotice.getStatus())) {
            if ("正常".equals(pageRequestNotice.getStatus())) {
                queryWrapper.eq("status", 0);
            }
            if ("关闭".equals(pageRequestNotice.getStatus())) {
                queryWrapper.eq("status", 1);
            }
        }
        // 只查询没有删除的数据
        queryWrapper.eq("isDelete", 0);
        // 升序、降序、取消排序
        if (StringUtils.isNotBlank(pageRequestNotice.getSortField()) && StringUtils.isNotBlank(pageRequestNotice.getSortOrder())) {
            String column = pageRequestNotice.getSortField();
            String order = pageRequestNotice.getSortOrder();
            if ("ascend".equalsIgnoreCase(order)) {
                queryWrapper.orderByAsc(column);
            } else if ("descend".equalsIgnoreCase(order)) {
                queryWrapper.orderByDesc(column);
            }
        }
        else {  // 如果为空,则默认降序
            queryWrapper.orderByDesc("createTime");
        }
        Page<Notice> result = this.page(page, queryWrapper);
        return Result.success(result);
    }

    @Override
    public Result updateNotice(Notice notice) {
        return null;
    }

    @Override
    public Result addNotice(Notice notice) {
        if (StringUtils.isBlank(notice.getTitle())) {
            throw new ServiceException(ConstantsState.CODE_404, "标题不能为空");
        }
        if (StringUtils.isBlank(notice.getContent())) {
            throw new ServiceException(ConstantsState.CODE_404, "内容不能为空");
        }
        if (!"0".equals(notice.getStatus()) && !"1".equals(notice.getStatus())) {
            throw new ServiceException(ConstantsState.CODE_404, "选择状态异常");
        }
        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_404, "创建者异常");
        }
        Notice n = new Notice();
        n.setTitle(notice.getTitle());
        n.setContent(notice.getContent());
        n.setCreateBy(currentUser.getUsername());
        n.setStatus(notice.getStatus());

        boolean flag = this.save(n);
        if (flag) {
            return Result.success();
        } else {
            return Result.error();
        }
    }

    @Override
    public Result getLatestFiveNotices() {
        QueryWrapper<Notice> queryWrapper = new QueryWrapper();
        queryWrapper.select("title", "content", "createTime");
        queryWrapper.eq("status", "0");
        queryWrapper.eq("isDelete", 0);
        queryWrapper.orderByDesc("createTime");
        queryWrapper.last("LIMIT " + 5);
        List<Notice> list = this.list(queryWrapper);
        if (!list.isEmpty()) {
            return Result.success(list);
        } else {
            return Result.error();
        }
    }

    @Override
    public Result updateCurrentNotice(Notice notice) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        if (notice.getId() == null || notice.getId() < 1) {
            throw new ServiceException(ConstantsState.CODE_404, "当前选中的数据异常");
        }
        if (StringUtils.isBlank(notice.getTitle())) {
            throw new ServiceException(ConstantsState.CODE_404, "标题不能为空");
        }
        if (StringUtils.isBlank(notice.getContent())) {
            throw new ServiceException(ConstantsState.CODE_404, "内容不能为空");
        }
        if (!"0".equals(notice.getStatus()) && !"1".equals(notice.getStatus())) {
            throw new ServiceException(ConstantsState.CODE_404, "状态异常");
        }
        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_404, "当前创建者异常");
        }
        UpdateWrapper<Notice> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", notice.getId())
                .set("title", notice.getTitle())
                .set("content", notice.getContent())
                .set("status", notice.getStatus())
                .set("updateTime", sdf.format(new Date()));
        boolean update = this.update(updateWrapper);
        if (update) {
            return Result.success();
        } else {
            return Result.error();
        }
    }

    @Override
    public Result updateNoticeDeleteById(Ids idss) {

        List<Long> ids =  idss.getIds();

        if (ids == null || ids.isEmpty()) {
            return Result.error(ConstantsState.CODE_400, "参数错误，ids不能为空");
        }

        LambdaUpdateWrapper<Notice> updateWrapper = Wrappers.lambdaUpdate();
        updateWrapper.in(Notice::getId, ids);

        Notice notice = new Notice();
        notice.setIsDelete(1);

        boolean updateResult = this.update(notice, updateWrapper);

        if (updateResult) {
            return Result.success("操作成功!");
        } else {
            return Result.error(ConstantsState.CODE_404, "操作失败!");
        }
    }
}
