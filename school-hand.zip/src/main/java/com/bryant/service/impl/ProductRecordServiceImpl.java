package com.bryant.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bryant.constant.ConstantsState;
import com.bryant.email.QQEmailConfig;
import com.bryant.email.utils.QQEmailTemplate;
import com.bryant.exception.ServiceException;
import com.bryant.mapper.ProductRecordMapper;
import com.bryant.model.ProductAudits;
import com.bryant.model.ProductRecord;
import com.bryant.model.User;
import com.bryant.model.vo.ProductRecordAndAudits;
import com.bryant.service.IProductAuditsService;
import com.bryant.service.IProductRecordService;
import com.bryant.utils.JwtTokenUtils;
import com.bryant.utils.Result;
import com.bryant.utils.StringUtils;
import org.apache.ibatis.annotations.Select;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class ProductRecordServiceImpl extends ServiceImpl<ProductRecordMapper, ProductRecord> implements IProductRecordService {

    @Resource
    private QQEmailTemplate qqEmailTemplate;

    @Resource
    private IProductAuditsService iProductAuditsService;

    @Resource
    private IProductRecordService iProductRecordService;


    @Transactional
    @Override
    public Result addProductRecord(ProductRecord productRecord) {
        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_401, "用户异常,请重新登录");
        }
        ProductRecord pro = new ProductRecord();
        pro.setUserId(currentUser.getId());
        pro.setCategory(productRecord.getCategory());
        pro.setDescription(productRecord.getDescription());
        pro.setImage(productRecord.getImage());
        pro.setOriginalPrice(productRecord.getOriginalPrice());
        pro.setProductName(productRecord.getProductName());
        pro.setQuantity(productRecord.getQuantity());
        pro.setSalePrice(productRecord.getSalePrice());
        boolean flag = this.save(pro);
        if (flag) {
            Long currentId = pro.getId(); // 获取插入时的主键ID
            // 审核表
            ProductAudits audits = new ProductAudits();
            audits.setProductId(currentId);  // 把商品提交记录表中的主键ID给审核表中的产品ID
            audits.setUserId(currentUser.getId());
            audits.setAuditStatus(audits.getAuditStatus());
            audits.setAuditRemark(audits.getAuditRemark());
            iProductAuditsService.addProductAudits(audits);
            // 通知管理员我已经发布商品了,告知管理员需要审核该商品
            sendQQEmailToAdmin(currentUser, productRecord.getProductName());
            return Result.success();
        } else {
            return Result.error();
        }
    }

    private void sendQQEmailToAdmin(User user, String productName) {
        //      发送QQ邮箱
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    qqEmailTemplate.sendMessage("商品发布通知 ","用户：" + user.getUsername() + "\r\n" + "商品名称：" + productName);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }).start();
    }

    @Override
    public Result getProductRecordAndAudits() {
        List<ProductRecordAndAudits> list = iProductAuditsService.getProductRecordAndAudits();
        if (list.size() > 0) {
            return Result.success(list);
        } else {
            return Result.error();
        }
    }

    @Transactional
    @Override
    public Result getAuditsList(String auditsStatus, String productName) {
        String newAuditsStatus = "";
        List<ProductAudits> auditsList;

        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_401, "用户异常,请重新登录");
        }

        if (StringUtils.isNotEmpty(auditsStatus) && !auditsStatus.equals("全部")) {
            if (auditsStatus.equals("待审核")) {
                newAuditsStatus = "0";
            } else if (auditsStatus.equals("通过")) {
                newAuditsStatus = "2";
            } else if (auditsStatus.equals("未通过")) {
                newAuditsStatus = "3";
            } else if (auditsStatus.equals("已撤回")) {
                newAuditsStatus = "4";
            } else {
                newAuditsStatus = "0";
            }


            QueryWrapper<ProductAudits> queryWrapperProductAudits = new QueryWrapper();
            queryWrapperProductAudits.eq("audit_status", newAuditsStatus);
            auditsList = iProductAuditsService.list(queryWrapperProductAudits);

        } else {
            QueryWrapper<ProductAudits> queryWrapperProductAudits = new QueryWrapper();
            auditsList = iProductAuditsService.list(queryWrapperProductAudits);
        }

        List<ProductRecordAndAudits> listP = new ArrayList<>();
        for (ProductAudits productAudits : auditsList) {
            Long productId = productAudits.getProductId();
            ProductRecord record = iProductRecordService.getById(productId);

            if (record.getUserId().equals(currentUser.getId())) {    // 当前用户
                if (record != null) { // 确保找到了相应的ProductRecord
                    ProductRecordAndAudits productRecordAndAudits = new ProductRecordAndAudits();

                    try {
                        // 复制ProductAudits的属性到ProductRecordAndAudits
                        BeanUtils.copyProperties(productAudits, productRecordAndAudits);
                        // 复制ProductRecord的属性到ProductRecordAndAudits，注意覆盖相同名称的属性
                        BeanUtils.copyProperties(record, productRecordAndAudits);

                        // 将合并后的对象添加到列表中
                        listP.add(productRecordAndAudits);
                    } catch (Exception e) {
                        // 处理BeanUtils.copyProperties可能抛出的异常
                        e.printStackTrace();
                        // 可以在这里添加日志记录或者返回错误Result
                    }
                } else {
                    return Result.error();
                    // 如果没有找到ProductRecord，可以记录日志或者处理错误情况
                }
            } else {

            }
        }

        if (StringUtils.isNotEmpty(productName)) {
            List<ProductRecordAndAudits> resultList = new ArrayList<>();
            for (ProductRecordAndAudits productRecordAndAudits : listP) {
                String pro = productRecordAndAudits.getProductName();
                if (pro.contains(productName)) {
                    resultList.add(productRecordAndAudits);
                }
            }
            return Result.success(resultList);

        } else {
            return Result.success(listP);
        }
    }

//    @Override
//    public Result getRecord() {
//        List<ProductAudits> auditsList  = iProductAuditsService.list();
//        List<ProductRecordAndAudits> listP = new ArrayList<>();
//        for (ProductAudits productAudits : auditsList ) {
//            ProductRecordAndAudits productRecordAndAudits = new ProductRecordAndAudits();
//            Long productId = productAudits.getProductId();
//            ProductRecord record = iProductRecordService.getById(productId);
//            BeanUtils.copyProperties(productAudits,productRecordAndAudits);
//            BeanUtils.copyProperties(record,productRecordAndAudits);
//            listP.add(productRecordAndAudits);
//
//        }
//        return Result.success(listP);
//    }
}
