package com.bryant.service.impl;

import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bryant.constant.ConstantsState;
import com.bryant.enums.DictCategory;
import com.bryant.exception.ServiceException;
import com.bryant.mapper.DictMapper;
import com.bryant.model.Dict;
import com.bryant.model.User;
import com.bryant.model.vo.Dict.PageRequestDict;
import com.bryant.model.vo.UserAdminVo.Ids;
import com.bryant.service.IDictService;
import com.bryant.utils.JwtTokenUtils;
import com.bryant.utils.Result;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class DictServiceImpl extends ServiceImpl<DictMapper, Dict> implements IDictService {

    @Resource
    DictMapper dictMapper;

    @Override
    public Result listDictPage(PageRequestDict pageRequestDict) {
        long current = pageRequestDict.getPageNo();
        long size = pageRequestDict.getPageSize();

        Page<Dict> page = new Page<>(current, size);

        QueryWrapper<Dict> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotBlank(pageRequestDict.getName())) {
            queryWrapper.like("name", pageRequestDict.getName());
        }
        if(StringUtils.isNotBlank(pageRequestDict.getCategoryId())){
            queryWrapper.like("category_id",pageRequestDict.getCategoryId());
        }
        if (StringUtils.isNotBlank(pageRequestDict.getCreateBy())) {
            queryWrapper.like("create_by", pageRequestDict.getCreateBy());
        }
        // 只查询没有删除的数据
        queryWrapper.eq("isDelete", 0);

        // 升序、降序、取消排序
        if (StringUtils.isNotBlank(pageRequestDict.getSortField()) &&
                StringUtils.isNotBlank(pageRequestDict.getSortOrder())) {
            String column = pageRequestDict.getSortField();
            String order = pageRequestDict.getSortOrder();
            if ("ascend".equalsIgnoreCase(order)) {
                queryWrapper.orderByAsc(column);
            } else if ("descend".equalsIgnoreCase(order)) {
                queryWrapper.orderByDesc(column);
            }
        } else {  // 如果为空,则默认降序
            queryWrapper.orderByDesc("createTime");
        }

        Page<Dict> result = this.page(page, queryWrapper);
        return Result.success(result);

    }

    @Override
    public Result updateDict(Dict dict) {
        if (dict.getId() == null || dict.getId() < 1) {
            throw new ServiceException(ConstantsState.CODE_404, "当前选中的数据异常");
        }
        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_401, "用户不存在，请重新登录");
        }
        int categoryId = dict.getCategoryId();
        if(categoryId <= 0){
            throw new ServiceException(ConstantsState.CODE_404,"字典类型有误,字典类型必须大于0");
        }
        if(StringUtils.isBlank(dict.getName())){
            throw new ServiceException(ConstantsState.CODE_404,"字典名称不能为空");
        }
        UpdateWrapper<Dict> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id",dict.getId())
                .set("name",dict.getName())
                .set("category_id",dict.getCategoryId())
                .set("create_by",currentUser.getUsername())
                .set("updateTime", DateUtil.now());  // yyyy-MM-dd HH:mm:ss

        boolean update = this.update(updateWrapper);
        if(update){
            return Result.success();
        }else{
            return Result.error();
        }
    }

    @Override
    public Result addDict(Dict dict) {
        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_401, "用户不存在，请重新登录");
        }
        // getCategoryId()返回一个有效的int类型值，因此不需要检查null
        int categoryId = dict.getCategoryId();
        if(categoryId <= 0){
            throw new ServiceException(ConstantsState.CODE_404,"字典类型有误,字典类型必须大于0");
        }
        if(StringUtils.isBlank(dict.getName())){
            throw new ServiceException(ConstantsState.CODE_404,"字典名称不能为空");
        }
        Dict d = new Dict();
        d.setName(dict.getName());
        d.setCategoryId(dict.getCategoryId());
        d.setCreateBy(currentUser.getUsername());

        boolean save = this.save(d);
        if(save){
            return Result.success();
        }else{
            return Result.error();
        }
    }

    @Override
    public Result updateDictDeleteById(Ids idss) {
        List<Long> ids =  idss.getIds();

        if (ids == null || ids.isEmpty()) {
            return Result.error(ConstantsState.CODE_400, "参数错误，ids不能为空");
        }

        LambdaUpdateWrapper<Dict> updateWrapper = Wrappers.lambdaUpdate();
        updateWrapper.in(Dict::getId, ids);

        Dict dict = new Dict();
        dict.setIsDelete(1);

        boolean updateResult = this.update(dict, updateWrapper);

        if (updateResult) {
            return Result.success("操作成功!");
        } else {
            return Result.error(ConstantsState.CODE_404, "操作失败!");
        }
    }

    @Override
    public Result getDictNameByCategoryId() {
        // select `name` from dict where category_id = 1
        QueryWrapper<Dict> queryWrapper = new QueryWrapper();
        queryWrapper.eq("category_id", DictCategory.PRODUCT.getValue());
        queryWrapper.select("name");
        List<Object> names = dictMapper.selectObjs(queryWrapper);
        if(!names.isEmpty()){
            return Result.success(names);
        }else{
            return Result.error();
        }
    }
}
