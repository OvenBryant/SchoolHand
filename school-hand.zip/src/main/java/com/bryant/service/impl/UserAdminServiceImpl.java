package com.bryant.service.impl;

import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bryant.constant.ConstantsState;
import com.bryant.exception.ServiceException;
import com.bryant.mapper.OrderMapper;
import com.bryant.mapper.ProductMapper;
import com.bryant.mapper.UserMapper;
import com.bryant.model.Product;
import com.bryant.model.ProductAudits;
import com.bryant.model.User;
import com.bryant.model.vo.Audits.ProductAuditsAndRecordAndUserInfo;
import com.bryant.model.vo.PageRequest;
import com.bryant.model.vo.Product.ProductLimit5;
import com.bryant.model.vo.UserAdminVo.AdminAddUser;
import com.bryant.model.vo.UserAdminVo.IdsDTO;
import com.bryant.service.IProductAuditsService;
import com.bryant.service.IProductService;
import com.bryant.service.IUserAdminService;
import com.bryant.utils.JwtTokenUtils;
import com.bryant.utils.Result;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserAdminServiceImpl extends ServiceImpl<UserMapper, User> implements IUserAdminService {


    @Resource
    UserMapper userAdminMapper;

    @Resource
    IProductService iProductService;

    @Resource
    ProductMapper productMapper;

    @Resource
    OrderMapper orderMapper;

    @Resource
    IProductAuditsService iProductAuditsService;

    /**
     * 分页查询用户列表
     *
     * @param pageRequest
     * @return
     */
    @Override
    public Result listUserByPage(PageRequest pageRequest) {
        long current = pageRequest.getPageNo();
        long size = pageRequest.getPageSize();
        Page<User> page = new Page<>(current, size);
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotBlank(pageRequest.getStatus())) {
            queryWrapper.eq("status", pageRequest.getStatus());
        }
        if (StringUtils.isNotBlank(pageRequest.getIsDelete())) {
            queryWrapper.eq("isDelete", pageRequest.getIsDelete());
        }
        if (StringUtils.isNotBlank(pageRequest.getNickname())) {
            queryWrapper.like("nickname", pageRequest.getNickname());
        }
        if (StringUtils.isNotBlank(pageRequest.getSex())) {
            queryWrapper.eq("sex", pageRequest.getSex());
        }
        if (StringUtils.isNotBlank(pageRequest.getCreateTime())) {
            queryWrapper.ge("createTime", pageRequest.getCreateTime());
        }
        if (StringUtils.isNotBlank(pageRequest.getUpdateTime())) {
            queryWrapper.le("createTime", pageRequest.getUpdateTime());
        }
        // Sorting
        if (StringUtils.isNotBlank(pageRequest.getSortField()) &&
                StringUtils.isNotBlank(pageRequest.getSortOrder())) {
            String column = pageRequest.getSortField();
            String order = pageRequest.getSortOrder();
            if ("ascend".equalsIgnoreCase(order)) {
                queryWrapper.orderByAsc(column);
            } else if ("descend".equalsIgnoreCase(order)) {
                queryWrapper.orderByDesc(column);
            }
        }
        Page<User> result = this.page(page, queryWrapper);
        return Result.success(result);
    }

    @Override
    public Result updateUserIsDeleteById(IdsDTO idsDTO) {
        List<Long> ids = idsDTO.getIds();
        // todo 1删除0恢复
        int extraParam = idsDTO.getExtraParam();

        if (ids == null || ids.isEmpty()) {
            return Result.error(ConstantsState.CODE_400, "参数错误，ids不能为空");
        }
        // 简单校验，确保 extraParam 是 0 或 1
        if (extraParam != 0 && extraParam != 1) {
            return Result.error(ConstantsState.CODE_400, "extraParam 必须是 0 或 1");
        }


        LambdaUpdateWrapper<User> updateWrapper = Wrappers.lambdaUpdate();
        updateWrapper.in(User::getId, ids);

        User user = new User();
        if (extraParam == 1) user.setIsDelete(1);  // 设置你想更新的字段和值
        if (extraParam == 0) user.setIsDelete(0);  // 设置你想更新的字段和值

        boolean updateResult = this.update(user, updateWrapper);

        if (updateResult) {
            return Result.success("操作成功!");
        } else {
            return Result.error(ConstantsState.CODE_404, "操作失败!");
        }

    }

    @Override
    public Result updateUserIsStatusById(IdsDTO idsDTO) {

        List<Long> ids = idsDTO.getIds();
        int extraParam = idsDTO.getExtraParam();

        if (ids == null || ids.isEmpty()) {
            return Result.error(ConstantsState.CODE_400, "参数错误，ids不能为空");
        }
        // 简单校验，确保 extraParam 是 0 或 1
        if (extraParam != 0 && extraParam != 1) {
            return Result.error(ConstantsState.CODE_400, "extraParam 必须是 0 或 1");
        }


        LambdaUpdateWrapper<User> updateWrapper = Wrappers.lambdaUpdate();
        updateWrapper.in(User::getId, ids);

        User user = new User();
        if (extraParam == 1) user.setStatus(1);  // 设置你想更新的字段和值
        if (extraParam == 0) user.setStatus(0);

        boolean updateResult = this.update(user, updateWrapper);

        if (updateResult) {
            return Result.success("锁定成功!");
        } else {
            return Result.error(ConstantsState.CODE_404, "锁定失败!");
        }
    }

    /**
     * 添加用户
     *
     * @param adminAddUser
     * @param resultMessage
     * @return
     */
    @Override
    public Result addUser(AdminAddUser adminAddUser, BindingResult resultMessage) {
        if (resultMessage.hasErrors()) {
            List<ObjectError> errors = resultMessage.getAllErrors();
            return Result.error(ConstantsState.CODE_400, errors.get(0).getDefaultMessage());
        }
        // 检查是否存在相同的username
        if (userAlreadyExists(adminAddUser.getUsername())) {
            return Result.error(ConstantsState.CODE_400, "账号已经存在!");
        }
        User user = new User();
        BeanUtils.copyProperties(adminAddUser, user);

        this.save(user);

        return Result.success();
    }

    @Override
    public Result getOneUser(String id) {
        if (!StringUtils.isNotBlank(id)) {
            throw new ServiceException(ConstantsState.CODE_404, "当前用户异常");
        }
        User user = this.getById(id);
        if (user != null) {
            return Result.success(user);
        } else {
            return Result.error();
        }
    }

    @Override
    public Result updateUser(User user) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        Long id = user.getId();
        if (id != null && id > 0) {
            UpdateWrapper<User> updateWrapper = new UpdateWrapper<>();
            updateWrapper.eq("id", id).eq("username", user.getUsername())
                    .set("nickname", user.getNickname())
                    .set("sex", user.getSex())
                    .set("password", user.getPassword())
                    .set("email", user.getEmail())
                    .set("phone", user.getPhone())
                    .set("persProfile", user.getPersProfile())
                    .set("status", user.getStatus())
                    .set("role", user.getRole())
                    .set("updateTime", sdf.format(new Date()));
            boolean update = this.update(updateWrapper);
            if (update) {
                return Result.success();
            } else {
                return Result.error();
            }
        } else {
            throw new ServiceException(ConstantsState.CODE_404, "当前用户异常");
        }
    }

    private boolean userAlreadyExists(String username) {
        // 根据username查询数据库，如果存在则返回true，否则返回false
        User u = this.getOne(new QueryWrapper<User>().eq("username", username));
        return u != null ? true : false;
    }


    @Override
    public Result getAuditsInfoList(String status, String productName, String currentUser) {
        /**
         * SELECT * FROM `product_audits` audits
         * INNER JOIN `product_record` record ON audits.product_id = record.id
         * inner JOIN `user` u ON u.id = audits.user_id
         *
         */
        List<ProductAuditsAndRecordAndUserInfo> list = userAdminMapper.getAuditsInfoList(status, productName, currentUser);
        return Result.success(list);
    }

    @Override
    public Result postAuditsInfo(String isSuccess, ProductAuditsAndRecordAndUserInfo productAuditsAndRecordAndUserInfo) {
        if ("1".equals(isSuccess)) { // 通过
            return auditSuccess(productAuditsAndRecordAndUserInfo);
        } else {  // 不通过
            return auditError(productAuditsAndRecordAndUserInfo);
        }
    }

    @Override
    public Result getAdminHomeData() {
        Map<String, Object> map = new HashMap<>();
        int male = userAdminMapper.getUserMaleCount();
        int female = userAdminMapper.getUserFemaleCount();
        int productCount = productMapper.getProductItem();
        List<ProductLimit5> productLimit5 = productMapper.getProductLimit();
        int orderCount = orderMapper.getOrderItem();
        int totalPrice = orderMapper.getOrderTotalPrice();
        map.put("male", male);
        map.put("female", female);
        map.put("productCount", productCount);
        map.put("orderCount", orderCount);
        map.put("totalPrice", totalPrice);
        map.put("productLimit5",productLimit5);
        return Result.success(map);
    }

    /**
     * 审核失败
     *
     * @param productAuditsAndRecordAndUserInfo
     * @return
     */

    @Transactional
    public Result auditError(ProductAuditsAndRecordAndUserInfo productAuditsAndRecordAndUserInfo) {

        UpdateWrapper<ProductAudits> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", productAuditsAndRecordAndUserInfo.getAuditsId())
                .set("audit_status", ConstantsState.未通过)
                .set("audit_remark", productAuditsAndRecordAndUserInfo.getAuditRemark())
                .set("audit_time", DateUtil.now());
        iProductAuditsService.update(updateWrapper);

        return Result.success();
    }

    /**
     * 审核通过
     *
     * @param productAuditsAndRecordAndUserInfo
     * @return
     */
    @Transactional
    public Result auditSuccess(ProductAuditsAndRecordAndUserInfo productAuditsAndRecordAndUserInfo) {

        // 1 添加商品到商品表
        // 2 同时修改审核表中的状态为通过状态

        Product product = new Product();
        product.setUserId(productAuditsAndRecordAndUserInfo.getUserId());
        product.setProductName(productAuditsAndRecordAndUserInfo.getProductName());
        product.setDescription(productAuditsAndRecordAndUserInfo.getDescription());
        product.setImage(productAuditsAndRecordAndUserInfo.getImage());
        product.setCategory(productAuditsAndRecordAndUserInfo.getCategory());
        product.setQuantity(productAuditsAndRecordAndUserInfo.getQuantity());
        product.setOriginalPrice(productAuditsAndRecordAndUserInfo.getOriginalPrice());
        product.setSalePrice(productAuditsAndRecordAndUserInfo.getSalePrice());
        product.setStatus(ConstantsState.在售);
        // 算审核通过的时间
        product.setCreateTime(new Date(System.currentTimeMillis()));
        iProductService.save(product);

        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_401, "用户异常,请重新登录");
        }

        UpdateWrapper<ProductAudits> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", productAuditsAndRecordAndUserInfo.getAuditsId())
                .set("audit_status", ConstantsState.通过)
                .set("user_id", currentUser.getId())  // 审核人
                .set("audit_time", DateUtil.now());
        iProductAuditsService.update(updateWrapper);

        return Result.success();
    }
}
