package com.bryant.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bryant.constant.ConstantsState;
import com.bryant.exception.ServiceException;
import com.bryant.mapper.LoginMapper;
import com.bryant.model.User;
import com.bryant.phone.utils.SMSTemplate;
import com.bryant.service.ILoginService;
import com.bryant.utils.*;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;


@Service
public class LoginServiceImpl extends ServiceImpl<LoginMapper, User> implements ILoginService {

    @Resource
    private SMSTemplate smsTemplate;

    @Override
    public Result getPhoneCode(String phone) {

        //判断手机号是否为空
        if (StringUtils.isEmpty(phone)) {
            throw new ServiceException(ConstantsState.CODE_404,"手机号不能为空");
        }
        // 如果缓存中有该手机号,说明验证码没有过期,直接读取手机验证码
        boolean hkey = RedisUtils.Hkey(phone);
        if(hkey){
            String value = (String) RedisUtils.get(phone);
            return Result.success(value);
        }else{
            String code = PubMethods.getSixBitRandom();
            try {
                String msg = smsTemplate.GetPhoneCode(phone, code);
                if("OK".equals(msg)){
                    // 设置5分钟验证码
                    RedisUtils.set(phone,code,5, TimeUnit.MINUTES);
                    return Result.success(code);
                }else{
                    return Result.error("404", msg);
                }
            }catch(Exception e){
                return Result.error("404", "错误");
            }
        }
    }

    @Override
    public Result login(String username, String password) {
        if(StrUtil.isEmpty(username)||StrUtil.isEmpty(password)){
            throw new ServiceException(ConstantsState.CODE_404,"账户,密码不能为空");
        }
        QueryWrapper<User> queryWrapper = new QueryWrapper();
        queryWrapper.eq("username",username);
        queryWrapper.eq("password",password);
        User user = this.getOne(queryWrapper);
        if(user!=null){
            String token = JwtTokenUtils.getToken(String.valueOf(user.getId()), user.getUsername());
            User u = new User();
            u.setUsername(user.getUsername());
            u.setToken(token);
            u.setRole(user.getRole());
            return Result.success(u);
        }
        else{
            return Result.error();
        }
    }

    @Override
    public Result phoneLogin(String phone, String captcha) {

        // TODO 当前手机号是否存在
        User u = this.getOne(new QueryWrapper<User>().eq("phone", phone));
        if(u==null){
            throw new ServiceException(ConstantsState.CODE_404,"请先注册该手机号!");
        } else{

            boolean hkey = RedisUtils.Hkey(phone);
            // TODO 当前手机号的验证码是否正确
            if(hkey){
                String value = (String) RedisUtils.get(phone);
                if(!StrUtil.equals(value, captcha)){
                    throw new ServiceException(ConstantsState.CODE_404,"手机验证码错误...");
                }else{
                    // Todo 验证码正确
                    // 存在该手机号
                    String token = JwtTokenUtils.getToken(String.valueOf(u.getId()), u.getUsername());
                    User user = new User();
                    user.setToken(token);
                    user.setUsername(u.getUsername());
                    user.setPhone(phone);
                    user.setRole(u.getRole());
                    return Result.success(user);
                }
            }else{
                throw new ServiceException(ConstantsState.CODE_404,"请点击获取验证码按钮...");
            }
        }

    }

}
