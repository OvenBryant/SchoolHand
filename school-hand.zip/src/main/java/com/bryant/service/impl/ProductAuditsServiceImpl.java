package com.bryant.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bryant.constant.ConstantsState;
import com.bryant.exception.ServiceException;
import com.bryant.mapper.ProductAuditsMapper;
import com.bryant.mapper.ProductRecordMapper;
import com.bryant.model.ProductAudits;
import com.bryant.model.ProductRecord;
import com.bryant.model.User;
import com.bryant.model.vo.ProductRecordAndAudits;
import com.bryant.service.IProductAuditsService;
import com.bryant.service.IProductRecordService;
import com.bryant.utils.JwtTokenUtils;
import com.bryant.utils.Result;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class ProductAuditsServiceImpl extends ServiceImpl<ProductAuditsMapper, ProductAudits> implements IProductAuditsService {

    @Resource
    ProductAuditsMapper productAuditsMapper;

    @Override
    public Result addProductAudits(ProductAudits productAudits) {
        this.save(productAudits);
        return Result.success();
    }

    @Override
    public List<ProductRecordAndAudits> getProductRecordAndAudits() {
        return productAuditsMapper.getProductRecordAndAudits();
    }
}
