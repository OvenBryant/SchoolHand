package com.bryant.service.impl;

import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bryant.constant.ConstantsState;
import com.bryant.exception.ServiceException;
import com.bryant.mapper.ProductMapper;
import com.bryant.model.*;
import com.bryant.model.vo.Product.ImageJson;
import com.bryant.model.vo.Product.PageRequestProduct;
import com.bryant.model.vo.UserAdminVo.Ids;
import com.bryant.service.IProductService;
import com.bryant.utils.JwtTokenUtils;
import com.bryant.utils.Result;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl extends ServiceImpl<ProductMapper, Product> implements IProductService {


    @Resource
    ProductMapper productMapper;

    /**
     * SELECT p.*, u.username
     * FROM `product` p
     * LEFT JOIN `user` u ON p.user_id = u.id
     * AND u.username LIKE '%ad%'
     * AND p.product_name LIKE '%手%'
     * AND p.category = '2'
     * WHERE u.username IS NOT NULL;
     *
     * @param pageRequestProduct
     * @return
     */
    @Override
    public Result listProductPage(PageRequestProduct pageRequestProduct) {
        long current = pageRequestProduct.getPageNo();
        long size = pageRequestProduct.getPageSize();
        Page<Product> page = new Page<>(current, size);
        String productName = pageRequestProduct.getProductName();
        String category = pageRequestProduct.getCategory();
        String username = pageRequestProduct.getUsername();
        Integer status = pageRequestProduct.getStatus();
        String sortField = pageRequestProduct.getSortField();
        String sortOrder = pageRequestProduct.getSortOrder();

        Page<Product> result = productMapper.
                getProductPage(page, productName, category, username, status, sortField, sortOrder);
        if (result != null) {
            return Result.success(result);
        } else {
            return Result.error();
        }
    }

    @Override
    public Result updateProductDeleteById(Ids idss) {
        List<Long> ids = idss.getIds();

        if (ids == null || ids.isEmpty()) {
            return Result.error(ConstantsState.CODE_400, "参数错误，ids不能为空");
        }

        LambdaUpdateWrapper<Product> updateWrapper = Wrappers.lambdaUpdate();
        updateWrapper.in(Product::getId, ids);
        updateWrapper.eq(Product::getStatus, 1);

        List<Product> productsWithStatusOne = this.list(updateWrapper);


        // 如果所有产品的status都是1，则不允许删除
        if (productsWithStatusOne.size() == ids.size()) {
            return Result.error(ConstantsState.CODE_400, "当前产品在售状态,不允许删除");
        }

        // 如果部分产品的status为1，只删除status不为1的产品
        if (!productsWithStatusOne.isEmpty()) {
            // 提取status不为1的产品的ID
            List<Long> idsToDelete = ids.stream()
                    .filter(id -> productsWithStatusOne.stream()
                            .noneMatch(product -> product.getId().equals(id)))
                    .collect(Collectors.toList());

            // 如果没有要删除的ID，则返回成功消息（或根据需要调整）
            if (idsToDelete.isEmpty()) {
                return Result.success("没有需要删除的产品");
            }

            LambdaUpdateWrapper<Product> wrapper = Wrappers.lambdaUpdate();
            wrapper.in(Product::getId, idsToDelete);
            wrapper.set(Product::getIsDelete, 1);

            boolean updateResult = this.update(wrapper);


            if (updateResult) {
                return Result.success("操作成功，部分产品已被删除");
            } else {
                return Result.error(ConstantsState.CODE_404, "操作失败");
            }
        }

        // 如果所有产品的status都不为1，则删除所有产品
        boolean updateResult = this.update(
                Wrappers.lambdaUpdate(Product.class)
                        .set(Product::getIsDelete, 1)
                        .in(Product::getId, ids)
        );

        if (updateResult) {
            return Result.success("操作成功，所有产品已被删除");
        } else {
            return Result.error(ConstantsState.CODE_404, "操作失败");
        }

    }

    @Override
    public Result updateProduct(Product product) {
        if (product.getId() == null || product.getId() < 1) {
            throw new ServiceException(ConstantsState.CODE_404, "当前选中的数据异常");
        }

        if (product.getStatus() != 1 && product.getStatus() != 2) {
            throw new ServiceException(ConstantsState.CODE_404, "当前选中的数据异常");
        }
        // 这里就不统计谁修改这个商品的了
//        User currentUser = JwtTokenUtils.getCurrentUser();
//        if (currentUser == null) {
//            throw new ServiceException(ConstantsState.CODE_401, "用户不存在，请重新登录");
//        }

        UpdateWrapper<Product> updateWrapper = new UpdateWrapper<>();
        UpdateWrapper<Product> updateSetData = updateWrapper.eq("id", product.getId())
                .set("category", product.getCategory())
                .set("description", product.getDescription())
                .set("original_price", product.getOriginalPrice())
                .set("product_name", product.getProductName())
                .set("quantity", product.getQuantity())
                .set("sale_price", product.getSalePrice())
                .set("status", product.getStatus());

        // 因为status是整型，所以不能判断字符串，我已经在前端转换整型了
        //        if("在售".equals(product.getStatus())){
        //            updateSetData.set("status",1);
        //        } else if("下架".equals(product.getStatus())){
        //            updateSetData.set("status",2);
        //        }else{
        //            throw new ServiceException(ConstantsState.CODE_404,"当前商品状态只能是在售或下架");
        //        }

        boolean update = this.update(updateSetData);
        if (update) {
            return Result.success();
        } else {
            return Result.error();
        }
    }

    @Override
    public Result addProduct(Product product) {
        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_401, "用户异常,请重新登录");
        }

        //List<ImageJson> image = product.getImage();

        Product pro = new Product();
        pro.setUserId(currentUser.getId());
        pro.setCategory(product.getCategory());
        pro.setDescription(product.getDescription());
        pro.setImage(product.getImage());
        pro.setOriginalPrice(product.getOriginalPrice());
        pro.setProductName(product.getProductName());
        pro.setQuantity(product.getQuantity());
        pro.setSalePrice(product.getSalePrice());
        pro.setStatus(product.getStatus());

        boolean save = this.save(pro);
        if (save) {
            return Result.success();
        } else {
            return Result.error();
        }

    }

    @Override
    public Result updateProductById(Long id) {
        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_401, "用户异常,请重新登录");
        }
        if (id == null || id < 0) {
            throw new ServiceException(ConstantsState.CODE_404, "id不能为空,并且不能小于0");
        }

        // 创建 UpdateWrapper 实例
//        UpdateWrapper<ProductCart> updateWrapper = new UpdateWrapper<>();
//        updateWrapper.eq("id", id);
//        updateWrapper.set("is_delete", 1);


        LambdaUpdateWrapper<Product> updateWrapper = Wrappers.lambdaUpdate();
        updateWrapper.eq(Product::getId, id);
        updateWrapper.set(Product::getIsDelete, 1);
        updateWrapper.set(Product::getStatus, 0);

        boolean updateResult = this.update(updateWrapper);

        if (updateResult) {
            return Result.success("删除成功");
        } else {
            return Result.error(ConstantsState.CODE_404, "操作失败");
        }



    }

//    // 只查询没有删除的数据
//        queryWrapper.eq("isDelete", 0);
//
//    // 升序、降序、取消排序
//        if (StringUtils.isNotBlank(pageRequestProduct.getSortField()) && StringUtils.isNotBlank(pageRequestProduct.getSortOrder())) {
//        String column = pageRequestProduct.getSortField();
//        String order = pageRequestProduct.getSortOrder();
//        if ("ascend".equalsIgnoreCase(order)) {
//            queryWrapper.orderByAsc(column);
//        } else if ("descend".equalsIgnoreCase(order)) {
//            queryWrapper.orderByDesc(column);
//        }
//    } else {  // 如果为空,则默认降序
//        queryWrapper.orderByDesc("createTime");
//    }
}
