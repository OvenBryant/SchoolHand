package com.bryant.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bryant.constant.ConstantsState;
import com.bryant.exception.ServiceException;
import com.bryant.mapper.RegisterMapper;
import com.bryant.model.User;
import com.bryant.model.vo.RegisterVo;
import com.bryant.phone.utils.SMSTemplate;
import com.bryant.service.IRegisterService;
import com.bryant.utils.PubMethods;
import com.bryant.utils.RedisUtils;
import com.bryant.utils.Result;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Random;
import java.util.concurrent.TimeUnit;


@Service
public class RegisterServiceImpl extends ServiceImpl<RegisterMapper, User> implements IRegisterService {


    @Resource
    private SMSTemplate smsTemplate;

    @Override
    public Result getPhoneCode(String phone) {
        //判断手机号是否为空
        if (StrUtil.isEmpty(phone)) {
            throw new ServiceException(ConstantsState.CODE_404,"手机号不能为空");
        }
        // 如果缓存中有该手机号,说明验证码没有过期,直接读取手机验证码
        boolean hkey = RedisUtils.Hkey(phone);
        if(hkey){
            String value = (String) RedisUtils.get(phone);
            return Result.success(value);
        }else{
            String code = PubMethods.getSixBitRandom();
            String msg = smsTemplate.GetPhoneCode(phone, code);
            if("OK".equals(msg)){
                // 设置5分钟验证码
                RedisUtils.set(phone,code,5, TimeUnit.MINUTES);
                return Result.success(code);
            }else{
                return Result.error("404", msg);
            }
        }

    }

    @Override
    public Result registerUser(RegisterVo registerVo) {
        String captcha = registerVo.getCaptcha();
        String password = registerVo.getPassword();
        String password2 = registerVo.getPassword2();
        String email = registerVo.getEmail();
        String phone = registerVo.getPhone();
        validParams(captcha, password, password2, email, phone);
        User u = this.getOne(new QueryWrapper<User>().eq("phone", phone));
        if(u!=null){
            throw new ServiceException(ConstantsState.CODE_404,"该手机号已被注册!");
        }
        String username;
        // TODO 生成一个7位数字且不重复的用户名账号
        do {
            username = UUidAccount();  // 随机生成用户名账号
        }while (this.getOne(new QueryWrapper<User>().eq("username",username))!=null);
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPhone(phone);
        user.setPassword(password);
        boolean flag = this.save(user);
        if(flag){
            User u1 = new User();
            u1.setUsername(username);
            return Result.success(u1);
        }else{
            return Result.error();
        }
    }


    private static void validParams(String captcha, String password, String password2, String email, String phone) {
        // 验证是否为空
        if(StrUtil.isBlank(captcha)||StrUtil.isBlank(password)||
                StrUtil.isBlank(password2)||StrUtil.isBlank(email)||
                StrUtil.isBlank(phone)){
            throw new ServiceException(ConstantsState.CODE_404,"参数不能为空...");
        }


        if(password.length()<6|| password2.length()<6){
            throw new ServiceException(ConstantsState.CODE_404,"密码长度不能小于6...");
        }

        if(!password.equals(password2)){
            throw new ServiceException(ConstantsState.CODE_404,"密码不一致...");
        }

        if(!PubMethods.isValidEmail(email)){
            throw new ServiceException(ConstantsState.CODE_404,"QQ邮箱错误...");
        }
        if(!PubMethods.isValidPhoneNumber(phone)){
            throw new ServiceException(ConstantsState.CODE_404,"手机号格式错误...");
        }


        boolean hkey = RedisUtils.Hkey(phone);
        if(hkey){
            String value = (String) RedisUtils.get(phone);
            if(!StrUtil.equals(value, captcha)){
                throw new ServiceException(ConstantsState.CODE_404,"手机验证码错误...");
            }
        }else{
            throw new ServiceException(ConstantsState.CODE_404,"请点击获取验证码按钮...");
        }
    }

    private static String UUidAccount(){
        Random rand = new Random();
        // 生成一个7位的随机数字
        return String.valueOf(rand.nextInt(9000000) + 999999);
    }
}
