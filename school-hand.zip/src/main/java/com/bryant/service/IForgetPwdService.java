package com.bryant.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bryant.model.User;
import com.bryant.utils.Result;

public interface IForgetPwdService extends IService<User> {
    Result forgetPwdByEmail(String phone,String email);

    Result validPhone(String phone);
}
