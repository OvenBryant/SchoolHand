package com.bryant.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bryant.model.Dict;
import com.bryant.model.vo.Dict.PageRequestDict;
import com.bryant.model.vo.UserAdminVo.Ids;
import com.bryant.utils.Result;

public interface IDictService extends IService<Dict> {

    Result listDictPage(PageRequestDict pageRequestDict);

    Result updateDict(Dict dict);

    Result addDict(Dict dict);

    Result updateDictDeleteById(Ids ids);

    Result getDictNameByCategoryId();
}
