package com.bryant.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bryant.model.Product;
import com.bryant.model.vo.Product.PageRequestProduct;
import com.bryant.model.vo.UserAdminVo.Ids;
import com.bryant.utils.Result;

public interface IProductService extends IService<Product> {

    Result listProductPage(PageRequestProduct pageRequestProduct);


    Result updateProductDeleteById(Ids ids);

    Result updateProduct(Product product);

    Result addProduct(Product product);

    Result updateProductById(Long id);

}
