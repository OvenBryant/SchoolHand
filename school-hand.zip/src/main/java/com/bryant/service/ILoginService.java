package com.bryant.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bryant.model.User;
import com.bryant.utils.Result;

public interface ILoginService extends IService<User> {

    Result getPhoneCode(String phone);

    Result login(String username, String password);

    Result phoneLogin(String phone, String captcha);
}
