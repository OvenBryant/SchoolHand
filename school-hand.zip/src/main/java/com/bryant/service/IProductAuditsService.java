package com.bryant.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bryant.model.ProductAudits;
import com.bryant.model.ProductRecord;
import com.bryant.model.vo.ProductRecordAndAudits;
import com.bryant.utils.Result;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface IProductAuditsService extends IService<ProductAudits> {

    Result addProductAudits(ProductAudits productAudits);

    List<ProductRecordAndAudits> getProductRecordAndAudits();
}
