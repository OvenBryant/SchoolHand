package com.bryant.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@TableName("product_cart")
@Data
public class ProductCart extends BaseEntity{

    // 用户id
    @TableField("user_id")
    private Long userId;

    @TableField("product_id")
    private Long productId;
}
