package com.bryant.model;

import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.FastjsonTypeHandler;
import com.bryant.model.vo.Product.ImageJson;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import lombok.Data;

import java.util.List;

@TableName(value = "product",autoResultMap = true)
@Data
public class Product extends BaseEntity{

    // 用户id
    @TableField("user_id")
    private Long userId;

    // 商品名称
    @TableField("product_name")
    private String productName;

    // 商品描述
    private String description;

    // 商品图片
//    private String image;
//    private List<ImageJson> image;

    @TableField(typeHandler = FastjsonTypeHandler.class)
    private List<ImageJson> image;


    // 商品类型
    private String category;

    // 商品数量
    private Integer quantity;

    // 商品原价
    @TableField("original_price")
    private Double originalPrice;

    // 商品售价
    @TableField("sale_price")
    private Double salePrice;

    // 商品状态 (1:在售,2:下架)
    private Integer status;

    /**
     * 确定对话框显示
     */
    @TableField(exist = false)
    private boolean showConfirm = false;


}
