package com.bryant.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("orders")
public class Orders {

    @TableField("order_id")
    private Long orderId; // 订单id

    @TableField("product_id")
    private Integer productId; // 产品id

    @TableField("user_id")
    private Long userId; // 用户id，可以为null
    private Integer orderStatus; // 订单状态，可以为null
    private Integer paymentStatus; // 支付状态，可以为null

    @TableField("shipping_method")
    private String shippingMethod; // 配送方式，可以为null

    @TableField("shipping_cost")
    private BigDecimal shippingCost; // 配送费用，可以为null

    @TableField("total_price")
    private Double totalPrice; // 订单总价(元)，可以为null

    private String address; // 地址，可以为null

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updateTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date paymentTime; // 付款时间，可以为null

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date deliveryTime; // 发货时间，可以为null

}