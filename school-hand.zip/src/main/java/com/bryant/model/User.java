package com.bryant.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName(value = "user")
public class User extends BaseEntity {

    private String nickname = "xxx";  // 昵称
    private String sex;  // 性别
    private String persProfile;  // 个人简介

    private String username;
    private String password;
    private String avatar;
    private String email;
    private String phone;
    private Integer status;
    private String role;

    @TableField(exist = false)
    private String token;

}
