package com.bryant.model;


import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * 通知公告表 sys_notice
 *
 * @author Fast Vue
 */
@Data
@TableName("notice")
public class Notice extends BaseEntity {

    /**
     * 公告标题
     */
    private String title;

    /**
     * 公告类型（1通知 2公告）
     */
    private String type;

    /**
     * 公告内容
     */
    private String content;

    /**
     * 公告状态（0正常 1关闭）
     */
    private String status;

    /**
     * 创建者
     */
    @TableField("create_by")
    private String createBy;

    /**
     * 确定对话框显示
     */
    @TableField(exist = false)
    private boolean showConfirm = false;


}
