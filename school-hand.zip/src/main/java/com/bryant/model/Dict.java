package com.bryant.model;


import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * 通知公告表 sys_notice
 *
 * @author Fast Vue
 */
@Data
@TableName("dict")
public class Dict extends BaseEntity {

    /**
     * 类别Id
     */
    @TableField("category_id")
    private int categoryId;

    /**
     * 分类名称
     */
    private String name;

    /**
     * 创建者
     */
    @TableField("create_by")
    private String createBy;

    /**
     * 确定对话框显示
     */
    @TableField(exist = false)
    private boolean showConfirm = false;


}
