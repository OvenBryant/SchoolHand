package com.bryant.model;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("logs")
@Builder
public class Logs implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 日志主键
     */
//    @TableId(value = "oper_id",type = IdType.AUTO)
    // 不采用Long类型,而采用String类型,防止雪花精度丢失
    @JsonSerialize(using = ToStringSerializer.class)
    @TableId(value = "oper_id", type = IdType.ASSIGN_ID)   // 主键生成策略,雪花算法
    private Long operId;


    /**
     * 操作模块
     */
    private String title;

    /**
     * 业务类型（0其它 1新增 2修改 3删除）
     */
    @TableField("business_type")
    private String businessType;

    /**
     * 请求方法
     */
    private String method;

    /**
     * 请求方式
     */
    @TableField("request_method")
    private String requestMethod;


    /**
     * 操作人员
     */

    @TableField("oper_name")
    private String operName;


    /**
     * 请求url
     */
    @TableField("oper_url")
    private String operUrl;

    /**
     * 操作地址
     */
    @TableField("oper_Ip")
    private String operIp;

    /**
     * 操作地点
     */

    /**
     * 请求参数
     */
    @TableField("oper_param")
    private String operParam;

    /**
     * 返回参数
     */
    @TableField("json_result")
    private String jsonResult;

    /**
     * 操作状态（0正常 1异常）
     */
    private Integer status;

    /**
     * 错误消息
     */
    @TableField("error_msg")
    private String errorMsg;

    /**
     * 操作时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField("oper_time")
    private Date operTime;

    @TableLogic
    private Integer isDelete;

    /**
     * 请求参数
     */
    @TableField(exist = false)
    private Map<String, Object> params = new HashMap<>();

}
