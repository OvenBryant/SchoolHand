package com.bryant.model.vo.Dict;

import lombok.Data;

@Data
public class PageRequestDict {

    private long pageNo = 1;
    /**
     * 页面大小
     */
    private long pageSize = 10;

    /**
     * 字典名称
     */
    private String name;

    /**
     * 字典类型
     */
    private String categoryId;

    /**
     * 操作人员
     */
    private String createBy;

    /**
     * 排序字段
     */
    private String sortField;

    /**
     * 排序顺序
     */
    private String sortOrder;
}
