package com.bryant.model.vo.Orders;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.extension.handlers.FastjsonTypeHandler;
import com.bryant.model.vo.Product.ImageJson;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HistoryProductOnOrders {


    private String productName;


    private String description;

    @TableField(typeHandler = FastjsonTypeHandler.class)
    private List<ImageJson> image;


    private String category;


    private Integer quantity;


    private Double originalPrice;


    private Double salePrice;


    // 订单时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime;




}
