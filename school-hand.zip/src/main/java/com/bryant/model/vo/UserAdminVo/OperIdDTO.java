package com.bryant.model.vo.UserAdminVo;

import lombok.Data;

import java.util.List;

@Data
public class OperIdDTO {
    private List<Long> operId;
}
