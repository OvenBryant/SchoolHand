package com.bryant.model.vo.Audits;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.extension.handlers.FastjsonTypeHandler;
import com.bryant.model.vo.Product.ImageJson;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductAuditsAndRecordAndUserInfo implements Serializable {

    private Long userId;
    private String nickname;
    private String username;
    private String sex;
    private String email;
    private String phone;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date userCreateTime;

    private Long auditsId;
    private String auditStatus;
    private String auditRemark;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date auditTime;


    private String productName;

    private String description;

    @TableField(typeHandler = FastjsonTypeHandler.class)
    private List<ImageJson> image;

    private String category;

    private Integer quantity;


    private Double originalPrice;

    private Double salePrice;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date productCreateTime;


}
