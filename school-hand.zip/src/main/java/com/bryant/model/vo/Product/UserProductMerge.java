package com.bryant.model.vo.Product;

import com.bryant.model.Product;
import lombok.Data;

/**
 * 返回数据结果，用户和商品关联
 */
@Data
public class UserProductMerge extends Product{

    private String nickname;
    private String username;
    private String sex;
    private String email;
    private String phone;

}
