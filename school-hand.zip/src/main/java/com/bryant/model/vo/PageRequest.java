package com.bryant.model.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PageRequest {

    /**
     * 当前页号
     */
    private long pageNo = 1;
    /**
     * 页面大小
     */
    private long pageSize = 10;
    /**
     * 昵称
     */
    private String nickname;
    /**
     * [0正常 1 删除]
     */
    private String isDelete;
    /**
     * 性别
     */
    private String sex;
    /**
     * [0正常 1锁定]
     */
    private String status;

    /**
     * 排序字段
     */
    private String sortField;

    /**
     * 排序顺序
     */
    private String sortOrder;

    private String createTime;
    private String updateTime;
}
