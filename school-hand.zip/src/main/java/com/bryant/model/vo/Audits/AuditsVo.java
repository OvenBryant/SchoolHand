package com.bryant.model.vo.Audits;

import lombok.Data;

import java.io.Serializable;

@Data
public class AuditsVo implements Serializable {
    private String selectAuditsStatus;
    private String selectProductName;
}
