package com.bryant.model.vo.ProductCart;

import com.bryant.model.Product;
import lombok.Data;

@Data
public class ProductCartAndProduct extends VoProduct {

    private Integer cartId;

    private Integer userId;

    private Integer proUserId;
}
