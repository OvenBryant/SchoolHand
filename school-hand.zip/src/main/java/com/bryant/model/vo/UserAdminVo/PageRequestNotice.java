package com.bryant.model.vo.UserAdminVo;

import lombok.Data;

@Data
public class PageRequestNotice {

    private long pageNo = 1;
    /**
     * 页面大小
     */
    private long pageSize = 10;

    /**
     * 公告标题
     */
    private String title;

    /**
     * 操作人员
     */
    private String createBy;

    /**
     * 正常,失败
     */
    private String status;

    /**
     * 排序字段
     */
    private String sortField;

    /**
     * 排序顺序
     */
    private String sortOrder;
}
