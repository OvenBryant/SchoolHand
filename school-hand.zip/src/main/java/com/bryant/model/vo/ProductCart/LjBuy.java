package com.bryant.model.vo.ProductCart;

import lombok.Data;

@Data
public class LjBuy {
    private Integer userId;
    private Integer productId;
    private Integer building;
    private Integer floor;
    private Integer roomNumber;
    private String fullAddress;
}
