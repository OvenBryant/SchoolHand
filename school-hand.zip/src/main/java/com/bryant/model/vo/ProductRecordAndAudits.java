package com.bryant.model.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.handlers.FastjsonTypeHandler;
import com.bryant.model.vo.Product.ImageJson;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
public class ProductRecordAndAudits implements Serializable {

    private Long id;

    @TableField("product_id")
    private Long productId;

    @TableField("user_id")
    private Long userId;

    /**
     *  0:待审核 1:审核中 2:通过 3:未通过 4:已撤回
     */
    @TableField("audit_status")
    private Integer auditStatus;

    @TableField("audit_remark")
    private String auditRemark;

    @TableField("audit_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date auditTime;

    private Integer isDelete;


    // 商品名称
    @TableField("product_name")
    private String productName;

    // 商品描述
    private String description;

    // 商品图片
//    private String image;
//    private List<ImageJson> image;

    @TableField(typeHandler = FastjsonTypeHandler.class)
    private List<ImageJson> image;

    // 商品类型
    private String category;

    // 商品数量
    private Integer quantity;

    // 商品原价
    @TableField("original_price")
    private Double originalPrice;

    // 商品售价
    @TableField("sale_price")
    private Double salePrice;

    /**
     * 确定对话框显示
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime;


}
