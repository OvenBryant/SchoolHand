package com.bryant.model.vo.UserAdminVo;

import lombok.Data;

@Data
public class PageRequestLog {

    private long pageNo = 1;
    /**
     * 页面大小
     */
    private long pageSize = 10;

    /**
     * 系统模块
     */
    private String title;

    /**
     * 操作人员
     */
    private String operName;

    /**
     * 类型,增删改
     */
    private String businessType;

    /**
     * 正常,失败
     */
    private String status;

    /**
     * 操作时间筛选
     */
    private String startOperTime;
    private String stopOperTime;

    /**
     * 排序字段
     */
    private String sortField;

    /**
     * 排序顺序
     */
    private String sortOrder;
}
