package com.bryant.model.vo.UserAdminVo;

import lombok.Data;

import java.util.Date;

@Data
public class UserExp {

//    @Alias("昵称")
    private String nickname;  // 昵称

//    @Alias("性别")
    private String sex;  // 性别

//    @Alias("个人简介")
    private String persProfile;  // 个人简介

//    @Alias("账号")
    private String username;

//    @Alias("头像")
    private String avatar;

//    @Alias("邮箱")
    private String email;

//    @Alias("手机号")
    private String phone;

//    @Alias("用户状态")
    private Integer status;

//    @Alias("用户角色")
    private String role;

//    @Alias("ID")
    private Long id;

//    @Alias("创建时间")
    private Date createTime;

//    @Alias("更新时间")
    private Date updateTime;

//    @Alias("删除标识")
    private Integer isDelete;


}
