package com.bryant.model.vo.ProductCart;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.FastjsonTypeHandler;
import com.bryant.model.BaseEntity;
import com.bryant.model.vo.Product.ImageJson;
import lombok.Data;

import java.util.List;

@Data
public class VoProduct extends BaseEntity {


//    private Long userId;

    private String productName;

    // 商品描述
    private String description;

    // 商品图片
//    private String image;
//    private List<ImageJson> image;

    @TableField(typeHandler = FastjsonTypeHandler.class)
    private List<ImageJson> image;


    // 商品类型
    private String category;

    // 商品数量
    private Integer quantity;

    private Double originalPrice;

    private Double salePrice;

    // 商品状态 (1:在售,2:下架)
    private Integer status;

    /**
     * 确定对话框显示
     */
    @TableField(exist = false)
    private boolean showConfirm = false;


}
