package com.bryant.model.vo.Product;

import lombok.Data;

@Data
public class ProductLimit5 {
    private String category;
    private String count;
}
