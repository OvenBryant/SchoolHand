package com.bryant.model.vo.UserAdminVo;

import lombok.Data;

import java.util.List;

@Data
public class Ids {

    private List<Long> ids;
}
