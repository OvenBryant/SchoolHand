package com.bryant.model.vo.Product;

import com.bryant.model.User;
import lombok.Data;

@Data
public class PageRequestProduct {

    private long pageNo = 1;
    /**
     * 页面大小
     */
    private long pageSize = 100;

    /**
     * 商品名称
     */
    private String productName;

    /**
     * 商品类别
     */
    private String category;

    /**
     * 上传者
     */
    private String username;

    /**
     * 商品状态 （1: 在售 2: 下架）
     */
    private Integer status;

    /**
     * 排序字段
     */
    private String sortField;

    /**
     * 排序顺序
     */
    private String sortOrder;
}
