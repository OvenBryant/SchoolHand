package com.bryant.model.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegisterVo {

    private String captcha;
    private String email;
    private String password;
    private String password2;
    private String phone;
}
