package com.bryant.model.vo.UserAdminVo;

import lombok.Data;

import java.util.List;

@Data
public class IdsDTO {
    private List<Long> ids;
    private int extraParam;
}
