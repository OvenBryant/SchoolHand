package com.bryant.model.vo.UserAdminVo;

import com.bryant.model.BaseEntity;
import lombok.Data;

import javax.validation.constraints.*;

@Data
public class AdminAddUser extends BaseEntity {

    @NotBlank(message = "头像不能为空")
    private String avatar;

    @NotBlank(message = "邮箱不能为空")
    @Email(message = "无效的邮箱格式")
    @Pattern(regexp = "\\d{5,11}@qq\\.com", message = "邮箱必须是QQ邮箱格式")
    private String email;

    @NotBlank(message = "昵称不能为空")
    private String nickname;

    @NotBlank(message = "密码不能为空")
    @Size(min = 6, message = "密码至少为6个字符")
    private String password;

    @NotBlank(message = "手机号不能为空")
    @Pattern(regexp = "\\d{11}", message = "无效的手机号格式")
    private String phone;

    @NotBlank(message = "个人简介不能为空")
    private String persProfile;

    @NotNull(message = "用户状态不能为空")
    private Integer status;

    @NotBlank(message = "用户角色不能为空")
    private String role;

    @NotBlank(message = "性别不能为空")
    private String sex;

    @NotBlank(message = "账号不能为空")
    @Pattern(regexp = "\\d{7}", message = "账号必须为7位数字")
    private String username;
}
