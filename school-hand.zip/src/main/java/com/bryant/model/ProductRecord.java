package com.bryant.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.FastjsonTypeHandler;
import com.bryant.model.vo.Product.ImageJson;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@TableName(value = "product_record",autoResultMap = true)
@Data
public class ProductRecord{

    @TableId(type = IdType.AUTO)
    private Long id;

    // 用户id
    @TableField("user_id")
    private Long userId;

    // 商品名称
    @TableField("product_name")
    private String productName;

    // 商品描述
    private String description;

    // 商品图片
//    private String image;
//    private List<ImageJson> image;

    @TableField(typeHandler = FastjsonTypeHandler.class)
    private List<ImageJson> image;

    // 商品类型
    private String category;

    // 商品数量
    private Integer quantity;

    // 商品原价
    @TableField("original_price")
    private Double originalPrice;

    // 商品售价
    @TableField("sale_price")
    private Double salePrice;

//    // 商品状态 (1:在售,2:下架)
//    private Integer status;

    /**
     * 确定对话框显示
     */

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime;

    //    // 逻辑删除(0:未删除,1:已删除) 不是真的删除
    // 我要统计,isDelete的数据,这个@TableLogin就要注释掉,不然会
    // SELECT COUNT(*) AS total FROM user WHERE isDelete = 0 AND (isDelete = ? AND status = ?)
//    @TableLogic
    private Integer isDelete;


    @TableField(exist = false)
    private boolean showConfirm = false;


}
