package com.bryant.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Data
public class BaseEntity implements Serializable {

    @TableId(type = IdType.AUTO)
    private Long id;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updateTime;

//    // 逻辑删除(0:未删除,1:已删除) 不是真的删除
    // 我要统计,isDelete的数据,这个@TableLogin就要注释掉,不然会
    // SELECT COUNT(*) AS total FROM user WHERE isDelete = 0 AND (isDelete = ? AND status = ?)
//    @TableLogic
    private Integer isDelete;

    // 其他参数
    @TableField(exist = false)
    private Map<String,Object> param = new HashMap<>();
}
