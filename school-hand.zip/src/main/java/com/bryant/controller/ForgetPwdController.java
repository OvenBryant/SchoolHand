package com.bryant.controller;

import com.bryant.service.IForgetPwdService;
import com.bryant.utils.Result;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@RequestMapping("/forget")
public class ForgetPwdController {

    @Resource
    private IForgetPwdService forgetPwdService;


    /**
     * 根据QQ邮箱找回密码
     * @param email
     * @return
     */
//    @Log(title = "找回密码",businessType = BusinessType.OTHER)
    @PostMapping("/findPwd/email/{phone}/{email}")
    public Result findPwd(@PathVariable("phone") String phone,@PathVariable("email") String email){
        return forgetPwdService.forgetPwdByEmail(phone,email);
    }

    /**
     * 找回密码之手机号验证
     * @param phone
     * @return
     */
//    @Log(title = "找回密码",businessType = BusinessType.OTHER)
    @PostMapping("/findPwd/phone/{phone}")
    public Result validPhone(@PathVariable("phone") String phone){
        return forgetPwdService.validPhone(phone);
    }

}
