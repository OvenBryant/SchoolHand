package com.bryant.controller;

import com.bryant.annotation.AuthAccess;
import com.bryant.annotation.Log;
import com.bryant.enums.BusinessType;
import com.bryant.service.ILoginService;
import com.bryant.utils.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@Api(tags = "登录接口")
@RestController
@RequestMapping("/login")
public class LoginController {

    @Resource
    private ILoginService iLoginService;

    /**
     * 获取手机验证码
     * @return
     */
    @ApiOperation(value = "获取手机号验证码")
    @AuthAccess
    @PostMapping("/getPhoneCode/{phone}")
    public Result getPhoneCode(@PathVariable("phone") String phone){
        return iLoginService.getPhoneCode(phone);
    }

    /** 先测试一下账号密码登录设置token,手机号登录则不设置token了
     * 账号密码登录（返回账号[username]）
     * @param username
     * @param password
     * @return
     */
    @ApiOperation(value = "账号密码登录")
    @AuthAccess
    @Log(title = "登录功能",businessType = BusinessType.LOGIN)
    @PostMapping("/login/{username}/{password}")
    public Result login(@PathVariable("username") String username,@PathVariable("password") String password){
        return iLoginService.login(username,password);
    }

    /**
     * 手机号登录（返回手机号[phone]）
     * @param phone
     * @param captcha
     * @return
     */
    @ApiOperation(value = "手机号登录")
    @AuthAccess
    @Log(title = "登录功能",businessType = BusinessType.LOGIN)
    @PostMapping("/phoneLogin/{phone}/{captcha}")
    public Result phoneLogin(@PathVariable("phone") String phone,@PathVariable("captcha") String captcha){
        return iLoginService.phoneLogin(phone,captcha);
    }

}
