package com.bryant.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.bryant.annotation.AuthAccess;
import com.bryant.annotation.Log;
import com.bryant.constant.ConstantsState;
import com.bryant.enums.BusinessType;
import com.bryant.exception.ServiceException;
import com.bryant.mapper.UserAddressMapper;
import com.bryant.model.User;
import com.bryant.model.UserAddress;
import com.bryant.model.vo.ProductCart.LjBuy;
import com.bryant.service.IProductCartService;
import com.bryant.service.IProductService;
import com.bryant.utils.JwtTokenUtils;
import com.bryant.utils.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@Api(tags = "商品管理")
@RestController
@RequestMapping("/user/productMan")
public class UserProductManController {

    @Resource
    IProductCartService iProductCartService;

    @Resource
    IProductService iProductService;

    @Resource
    UserAddressMapper userAddressMapper;


    /**
     * 添加到购物车中
     * @param product_id
     * @return
     */
    @ApiOperation(value = "添加到购物车")
    @Log(title = "购物车", businessType = BusinessType.INSERT)
    @PostMapping("/productCart/add/{product_id}")
    public Result addProductCart(@PathVariable("product_id") Long product_id) {
        return iProductCartService.addProductCart(product_id);
    }


    /**
     * 根据ID删除购物车中的商品
     * @param Id
     * @return
     */
    @ApiOperation(value = "根据ID删除购物车中的商品")
    @Log(title = "购物车",businessType = BusinessType.DELETE)
    @PutMapping("/productCart/delete/{Id}")
    public Result updateProductCartById(@PathVariable("Id") Long Id){
        return iProductCartService.updateProductCartById(Id);
    }

    /**
     * 根据ID删除我的的商品
     * @param Id
     * @return
     */
    @ApiOperation(value = "根据ID删除我的商品")
    @Log(title = "我的商品",businessType = BusinessType.DELETE)
    @PutMapping("/product/delete/{Id}")
    public Result updateProductById(@PathVariable("Id") Long Id){
        return iProductService.updateProductById(Id);
    }


    /**
     * 获取用户购物车中信息
     * @return
     */
    @ApiOperation(value = "获取购物车中的所有信息")
    @GetMapping("/productCart/getList")
    public Result listProductCart(){
        return iProductCartService.listProductCart();
    }


    /**
     * 普通用户-商品管理-我的商品
     * @return
     */
    @ApiOperation(value = "商品管理-我的商品")
    @GetMapping("/myProduct")
    public Result MyProduct(){
        return iProductCartService.MyProduct();
    }


    /**
     * 立即购买
     * @param ljBuy
     * @return
     */
    @ApiOperation(value = "立即购买")
    @Log(title = "立即购买", businessType = BusinessType.INSERT)
    @PostMapping("/ljBuy")
    public Result ljBuyProduct(@RequestBody LjBuy ljBuy) {
        return iProductCartService.ljBuyProduct(ljBuy);
    }

    /**
     * 购买历史-根据订单表中获取购买的历史记录
     * @return
     */
    @ApiOperation(value = "购买历史")
    @GetMapping("/getHistory")
    public Result getProductHistoryOnOrders() {
        return iProductCartService.getProductHistoryOnOrders();
    }

    /**
     *
     * @return
     */
    @ApiOperation(value = "用户地址")
    @GetMapping("/userAddress")
    public Result getUserAddress(){

        User currentUser = JwtTokenUtils.getCurrentUser();
        if (currentUser == null) {
            throw new ServiceException(ConstantsState.CODE_401, "用户异常,请重新登录");
        }

        QueryWrapper<UserAddress> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id",currentUser.getId());
        UserAddress res = userAddressMapper.selectOne(queryWrapper);
        if(res!=null){
            return Result.success(res);
        }else{
            return Result.error();
        }
    }
}
