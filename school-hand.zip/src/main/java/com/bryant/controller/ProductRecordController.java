package com.bryant.controller;

import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.bryant.annotation.AuthAccess;
import com.bryant.annotation.Log;
import com.bryant.constant.ConstantsState;
import com.bryant.enums.BusinessType;
import com.bryant.exception.ServiceException;
import com.bryant.model.Product;
import com.bryant.model.ProductRecord;
import com.bryant.model.vo.Audits.AuditsVo;
import com.bryant.model.vo.Product.PageRequestProduct;
import com.bryant.model.vo.UserAdminVo.Ids;
import com.bryant.service.IProductRecordService;
import com.bryant.service.IProductService;
import com.bryant.utils.Result;
import org.example.utils.OSSTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/user/productRecord")
public class ProductRecordController {

    @Resource
    IProductRecordService iProductRecordService;


    /**
     * 记录表、审核表
     *
     * @param productRecord
     * @return
     */
    @Log(title = "发布商品", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public Result addProductRecord(@RequestBody ProductRecord productRecord) {
        return iProductRecordService.addProductRecord(productRecord);
    }

    /**
     * 只有审核表和商品提交记录表
     * todo 普通用户-发布商品中的审核状态
     * @return
     */
    @AuthAccess
    @PostMapping("/getAuditsList")
    public Result getRecord(@RequestBody AuditsVo auditsVo) {
        String auditsStatus = auditsVo.getSelectAuditsStatus();
        String productName = auditsVo.getSelectProductName();
        return iProductRecordService.getAuditsList(auditsStatus, productName);
    }

    /**
     * 获得记录表和审核表信息
     *
     * @return
     */
    @AuthAccess
    @GetMapping("/getAuditsAndRecord")
    public Result getProductRecordAndAudits() {
        return iProductRecordService.getProductRecordAndAudits();
    }


}
