package com.bryant.controller.UserAdmin;


import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.bryant.annotation.AuthAccess;
import com.bryant.annotation.Log;
import com.bryant.enums.BusinessType;
import com.bryant.model.User;
import com.bryant.model.vo.Audits.ProductAuditsAndRecordAndUserInfo;
import com.bryant.model.vo.PageRequest;
import com.bryant.model.vo.UserAdminVo.AdminAddUser;
import com.bryant.model.vo.UserAdminVo.IdsDTO;
import com.bryant.model.vo.UserAdminVo.UserExp;
import com.bryant.service.IUserAdminService;
import com.bryant.utils.PubMethods;
import com.bryant.utils.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

@Api(tags = "管理员接口")
@RestController
@RequestMapping("/userAdmin")
public class UserAdminController {

    @Resource
    IUserAdminService iUserAdminService;

    /**
     * 生成数据库文档,放行
     */
    @ApiOperation(value = "生成数据库文档")
    @AuthAccess
    @GetMapping("/genMysqlDoc")
    public void generationMysqlDoc() {
        PubMethods.documentGeneration();
    }

    @GetMapping("/list/page")
    public Result listUserByPage(PageRequest pageRequest) {
        return iUserAdminService.listUserByPage(pageRequest);
    }

    /**
     * 删除下拉列表行(也可以选择一个删除的)
     *
     * @param idsDTO
     * @return
     */

    @Log(title = "用户管理", businessType = BusinessType.DELETE)
    @PostMapping("/user/isDeleteById")
    public Result updateUserIsDeleteById(@RequestBody IdsDTO idsDTO) {
        return iUserAdminService.updateUserIsDeleteById(idsDTO);
    }

    /**
     * 锁定行
     *
     * @param idsDTO
     * @return
     */
    @Log(title = "用户管理", businessType = BusinessType.LOCK)
    @PostMapping("/user/isStatusById")
    public Result updateUserIsStatusById(@RequestBody IdsDTO idsDTO) {
        return iUserAdminService.updateUserIsStatusById(idsDTO);
    }

    /**
     * 添加用户,头像是前端默认传递过来的头像
     * todo 头像其实也可以放在后端的static目录下，然后存入路径到数据库,前端访问这个路径就可以了,但是要放行这个地址
     *
     * @param adminAddUser
     * @param resultMessage
     * @return
     */

    @Log(title = "用户管理", businessType = BusinessType.INSERT)
    @PostMapping("/addUser")
    public Result addUser(@Valid @RequestBody AdminAddUser adminAddUser, BindingResult resultMessage) {
        return iUserAdminService.addUser(adminAddUser, resultMessage);
    }

    @GetMapping("/getOneUser/{id}")
    public Result getOneUser(@PathVariable("id") String id) {
        return iUserAdminService.getOneUser(id);
    }

    @Log(title = "用户管理", businessType = BusinessType.UPDATE)
    @PutMapping("/updateUser")
    public Result updateUser(@RequestBody User user) {
        return iUserAdminService.updateUser(user);
    }

    /**
     * 导出接口 没有导出密码 导出是get请求
     */
    @Log(title = "导出", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public void export(HttpServletResponse response) throws Exception {
        List<User> list = iUserAdminService.list();
        List<UserExp> userExpsList = new ArrayList<>();
        for (User user : list) {
            UserExp userExp = new UserExp();
            BeanUtils.copyProperties(user, userExp);
            userExpsList.add(userExp);
        }

        ExcelWriter writer = ExcelUtil.getWriter(true);

        // 一次性写出list内的对象到excel，使用默认样式，强制输出标题
        writer.write(userExpsList, true);

        // 设置浏览器响应的格式
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        String fileName = URLEncoder.encode("用户信息", "UTF-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName + ".xlsx");

        ServletOutputStream out = response.getOutputStream();
        writer.flush(out, true);
        out.close();
        writer.close();

    }

    /**
     * excel 导入
     *
     * @param file
     * @throws Exception
     */

    @Log(title = "导入", businessType = BusinessType.IMPORT)
    @PostMapping("/importExcel")
    public Result imp(MultipartFile file) throws Exception {
        InputStream inputStream = file.getInputStream();
        ExcelReader reader = ExcelUtil.getReader(inputStream);
        List<User> list = reader.readAll(User.class);
        boolean b = iUserAdminService.saveBatch(list);
        return Result.success();
        //userService.saveBatch(list);
    }


    /**
     * 管理员商品审核
     *
     * @param status      审核状态
     * @param productName 产品名称
     * @param currentUser 上传者
     * @return
     */
    @AuthAccess
    @PostMapping("/getAuditsInfoList/{status}")
    public Result getAuditsInfoList(@PathVariable("status") String status,
                                    @RequestParam(required = false) String productName,
                                    @RequestParam(required = false) String currentUser) {

        return iUserAdminService.getAuditsInfoList(status, productName, currentUser);

    }

    /**
     * 管理员审核商品-是否通过
     *
     * @return
     */
    @AuthAccess
    @PostMapping("/postAuditsInfo/{isSuccess}")
    public Result postAuditsInfo(@PathVariable("isSuccess") String isSuccess,
                                 @RequestBody ProductAuditsAndRecordAndUserInfo productAuditsAndRecordAndUserInfo) {
        return iUserAdminService.postAuditsInfo(isSuccess, productAuditsAndRecordAndUserInfo);
    }


    /**
     * 获取管理员首页相关数据
     * @return
     */
    @GetMapping("/adminHome/getAdminHomeData")
    public Result getAdminHomeData() {
        return iUserAdminService.getAdminHomeData();
    }


}
