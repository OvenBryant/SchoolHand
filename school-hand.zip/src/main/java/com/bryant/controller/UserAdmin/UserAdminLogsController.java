package com.bryant.controller.UserAdmin;

import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.bryant.annotation.Log;
import com.bryant.constant.ConstantsState;
import com.bryant.enums.BusinessType;
import com.bryant.exception.ServiceException;
import com.bryant.model.Logs;
import com.bryant.model.vo.UserAdminVo.OperIdDTO;
import com.bryant.model.vo.UserAdminVo.PageRequestLog;
import com.bryant.service.IUserAdminLogsService;
import com.bryant.utils.Result;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/userAdmin")
public class UserAdminLogsController {


    @Resource
    IUserAdminLogsService iUserAdminLogsService;

    @GetMapping("/logs/list")
    public Result listLogsByPage(PageRequestLog pageRequestLog) {
        return iUserAdminLogsService.PageRequestLog(pageRequestLog);
    }

    /**
     * 删除下拉日志
     * @param operIdDTO
     * @return
     */
    @Log(title = "操作日志",businessType = BusinessType.DELETE)
    @DeleteMapping("/logs/deleteMore")
    public Result updateLogsDeleteByOperId(@RequestBody OperIdDTO operIdDTO){
        return iUserAdminLogsService.deleteMoreByOperId(operIdDTO);
    }

    /**
     * 删除所有日志
     * @return
     */
    @Log(title = "操作日志",businessType = BusinessType.CLEAN)
    @DeleteMapping("/logs/deleteAll")
    public Result updateLogsDeleteAll(){
        return iUserAdminLogsService.updateLogsDeleteAll();
    }

    /**
     * 导出接口 没有导出密码 导出是get请求
     */
//    @AuthAccess
    @Log(title = "操作日志",businessType = BusinessType.EXPORT)
    @GetMapping("/logs/export")
    public void export(HttpServletResponse response) throws Exception {
        List<Logs> list = iUserAdminLogsService.list();
        if(Objects.nonNull(list) && !list.isEmpty()){
            ExcelWriter writer = ExcelUtil.getWriter(true);
            // 一次性写出list内的对象到excel，使用默认样式，强制输出标题
            writer.write(list, true);

            // 设置浏览器响应的格式
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
            String fileName = URLEncoder.encode("日志管理", "UTF-8");
            response.setHeader("Content-Disposition", "attachment;filename=" + fileName + ".xlsx");

            ServletOutputStream out = response.getOutputStream();
            writer.flush(out, true);
            out.close();
            writer.close();
        }else{
            throw new ServiceException(ConstantsState.CODE_404,"数据不存在!");
        }


    }



}
