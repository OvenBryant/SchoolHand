package com.bryant.controller.UserAdmin;

import com.bryant.annotation.Log;
import com.bryant.enums.BusinessType;
import com.bryant.model.Notice;
import com.bryant.model.vo.UserAdminVo.Ids;
import com.bryant.model.vo.UserAdminVo.NoticeIdDTO;
import com.bryant.model.vo.UserAdminVo.PageRequestNotice;
import com.bryant.service.INoticeService;
import com.bryant.utils.Result;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@RequestMapping("/userAdmin")
public class NoticeController {


    @Resource
    INoticeService iNoticeService;

    @GetMapping("/notice/list")
    public Result listNoticePage(PageRequestNotice pageRequestNotice) {
        return iNoticeService.listNoticePage(pageRequestNotice);
    }

    /**
     * 修改当前公告
     * @param notice
     * @return
     */
    @Log(title = "通知公告",businessType = BusinessType.UPDATE)
    @PutMapping("/notice/updateCurrentNotice")
    public Result updateCurrentNotice(@RequestBody Notice notice) {
        return iNoticeService.updateCurrentNotice(notice);
    }

    /**
     * 删除公告
     * @return
     */
    @Log(title = "通知公告",businessType = BusinessType.DELETE)
    @PutMapping("/notice/deleteIds")
    public Result updateLogsDeleteByOperId(@RequestBody Ids ids){
        return iNoticeService.updateNoticeDeleteById(ids);
    }

    @Log(title = "通知公告",businessType = BusinessType.INSERT)
    @PostMapping("/notice/add")
    public Result addNotic(@RequestBody Notice notice){
        return iNoticeService.addNotice(notice);
    }


    /**
     * 查询数据库中最新的5条记录 【状态正常,没有删除】
     * @return
     */
    @GetMapping("/user/notice/getLatest")
    public Result getLatestFiveNotices(){
        return iNoticeService.getLatestFiveNotices();
    }

}
