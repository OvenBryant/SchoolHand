package com.bryant.controller;

import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.bryant.annotation.AuthAccess;
import com.bryant.annotation.Log;
import com.bryant.constant.ConstantsState;
import com.bryant.enums.BusinessType;
import com.bryant.exception.ServiceException;
import com.bryant.model.Dict;
import com.bryant.model.vo.Dict.PageRequestDict;
import com.bryant.model.vo.UserAdminVo.Ids;
import com.bryant.service.IDictService;
import com.bryant.utils.Result;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/userAdmin")
public class DictController {

    @Resource
    IDictService iDictService;

    @AuthAccess
    @GetMapping("/dict/list")
    public Result listNoticePage(PageRequestDict pageRequestDict) {
        return iDictService.listDictPage(pageRequestDict);
    }

    /**
     * 根据字典category_id获取字典名称
     * @return
     */
    @GetMapping("/getDictNameByCategoryId")
    public Result getDictNameByCategoryId(){
        return iDictService.getDictNameByCategoryId();
    }


    @Log(title = "字典管理", businessType = BusinessType.EXPORT)
    @GetMapping("/dict/exportList")
    public void exportDictList(HttpServletResponse response) throws Exception {
        List<Dict> list = iDictService.list();
        if (Objects.nonNull(list) && !list.isEmpty()) {
            ExcelWriter writer = ExcelUtil.getWriter(true);
            // 一次性写出list内的对象到excel，使用默认样式，强制输出标题
            writer.write(list, true);
            // 设置浏览器响应的格式
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
            String fileName = URLEncoder.encode("字典管理", "UTF-8");
            response.setHeader("Content-Disposition", "attachment;filename=" + fileName + ".xlsx");
            ServletOutputStream out = response.getOutputStream();
            writer.flush(out, true);
            out.close();
            writer.close();
        } else {
            throw new ServiceException(ConstantsState.CODE_404, "数据不存在!");
        }
    }


    @Log(title = "字典管理", businessType = BusinessType.DELETE)
    @PutMapping("/dict/deleteIds")
    public Result updateDictDeleteById(@RequestBody Ids ids) {
        return iDictService.updateDictDeleteById(ids);
    }

    @Log(title = "字典管理", businessType = BusinessType.INSERT)
    @PostMapping("/dict/add")
    public Result addDict(@RequestBody Dict dict) {
        return iDictService.addDict(dict);
    }

    @Log(title = "字典管理", businessType = BusinessType.UPDATE)
    @PutMapping("/dict/update")
    public Result updateDict(@RequestBody Dict dict) {
        return iDictService.updateDict(dict);
    }

}
