package com.bryant.controller;

import com.bryant.annotation.Log;
import com.bryant.enums.BusinessType;
import com.bryant.model.vo.RegisterVo;
import com.bryant.service.IRegisterService;
import com.bryant.utils.Result;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@RequestMapping("/register")
public class RegisterController {

    @Resource
    private IRegisterService iRegisterService;

    /**
     * 获取手机验证码
     * @return
     */
    @PostMapping("/getPhoneCode/{phone}")
    public Result getPhoneCode(@PathVariable("phone") String phone){
        return iRegisterService.getPhoneCode(phone);
    }


    /**
     * 注册
     * @param registerVo
     * @return
     */
    @Log(title = "注册功能",businessType = BusinessType.INSERT)
    @PostMapping("/register")
    public Result registerUser(@RequestBody RegisterVo registerVo){
        return iRegisterService.registerUser(registerVo);
    }


}
