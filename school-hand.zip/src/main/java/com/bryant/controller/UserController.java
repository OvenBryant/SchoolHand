package com.bryant.controller;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.bryant.annotation.Log;
import com.bryant.constant.ConstantsState;
import com.bryant.enums.BusinessType;
import com.bryant.exception.ServiceException;
import com.bryant.model.User;
import com.bryant.service.IUserService;
import com.bryant.utils.Result;
import org.example.utils.OSSTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.util.Random;

@RestController
@RequestMapping("/user")
public class UserController {

    @Resource
    private OSSTemplate ossTemplate;

    @Resource
    private IUserService userService;

    private static final int min = 100000;
    private static final int max = 999999;


    @PostMapping("/getCode")
    public Result getCode(){
        int i = randomNumber();
        return Result.success(i);
    }

    /**
     * 根据QQ邮箱获取验证码
     * @param email
     * @return
     */
    @PostMapping("/qqEmail/{email}")
    public Result getQQEmailCaptcha(@PathVariable("email") String email){
        return userService.getQQEmailCaptcha(email);
    }


    private int randomNumber() {
        Random random = new Random();
        return random.nextInt((max - min) + 1) + min;
    }


    /**
     * 上传头像
     * @param file
     * @return
     */

    @Log(title = "OOS-个人设置",businessType = BusinessType.INSERT)
    @PostMapping("/changeAvatar")
    public Result updateUserAvatar(@RequestParam("file") MultipartFile file) {
        long size = file.getSize() / 1024;
        if (size >= 500) {
            throw new ServiceException(ConstantsState.CODE_40000, "文件大于500kb无法导入");
        }
        String url = ossTemplate.handleAvatar(file);
        if (StringUtils.isNotBlank(url)) {
            return Result.success(url);
        } else {
            return Result.error();
        }
    }

    /**
     * 根据当前账号或者手机号查找当前用户 【查询条件满足其中之一即可】
     * @param usernameOrPhone
     * @return
     */
    @GetMapping("/getUserInfo/{usernameOrPhone}")
    public Result getCurrentUser(@PathVariable("usernameOrPhone") String usernameOrPhone){
        return userService.getCurrentUser(usernameOrPhone);
    }

    /**
     * 根据账号查看旧密码是否正确 [前端重置密码界面]
     * @param username
     * @param oldPwd
     * @return
     */
    @GetMapping("/getpwdByUsername/{username}/{oldPwd}")
    public Result getpwdByUsername(@PathVariable("username") String username,@PathVariable("oldPwd") String oldPwd){
        return userService.getpwdByUsername(username,oldPwd);
    }

    /**
     * 个人设置
     * @param username
     * @param oldPwd
     * @param newPwd
     * @param surePwd
     * @return
     */
    @Log(title = "个人设置",businessType = BusinessType.UPDATE)
    @PutMapping("/resetPwdByUsername/{username}/{oldPwd}/{newPwd}/{surePwd}")
    public Result resetPwdByUsername(@PathVariable("username") String username,
                                     @PathVariable("oldPwd") String oldPwd,
                                     @PathVariable("newPwd") String newPwd,
                                     @PathVariable("surePwd") String surePwd){
        return userService.resetPwdByUsername(username,oldPwd,newPwd,surePwd);
    }



    @Log(title = "个人设置",businessType = BusinessType.UPDATE)
    @PostMapping("/updateUserBasicInfoByUsername")
    public Result updateUserBasicInfoByUsername(@RequestBody User user){
        return userService.updateUserBasicInfoByUsername(user);
    }

    @Log(title = "个人设置",businessType = BusinessType.OTHER)
    @PostMapping("/validCurrentPhoneByUsername/{username}/{phone}")
    public Result validCurrentPhoneByUsername(@PathVariable("username") String username,@PathVariable("phone") String phone){
        return userService.validCurrentPhoneByUsername(username,phone);
    }

    @Log(title = "个人设置",businessType = BusinessType.OTHER)
    @PostMapping("/validCurrentEmailByUsername/{username}/{email}")
    public Result validCurrentEmailByUsername(@PathVariable("username") String username,@PathVariable("email") String email){
        return userService.validCurrentEmailByUsername(username,email);
    }


    @Log(title = "个人设置",businessType = BusinessType.OTHER)
    @PostMapping("/verifyPhoneFirstStep/{username}/{phone}/{captcha}")
    public Result verifyPhoneFirstStep(@PathVariable("username") String username,
                                       @PathVariable("phone") String phone,
                                       @PathVariable("captcha") String captcha){
        return userService.verifyPhoneFirstStep(username,phone,captcha);
    }

    @PostMapping("/verifyPhoneTwoStep/{username}/{oldPhone}/{newPhone}/{captcha}")
    public Result verifyPhoneTwoStep(@PathVariable("username") String username,
                                       @PathVariable("oldPhone") String oldPhone,
                                       @PathVariable("newPhone") String newPhone,
                                       @PathVariable("captcha") String captcha){
        return userService.verifyPhoneTwoStep(username,oldPhone,newPhone,captcha);

    }

    /**
     * 根据账号修改邮箱
     * @param username 账号
     * @param email  原始邮箱
     * @param captcha 原始邮箱验证码
     * @param newEmail 新的邮箱
     * @return
     */
    @Log(title = "个人设置",businessType = BusinessType.UPDATE)
    @PostMapping("/updateNewQQEmailByUsername/{username}/{email}/{captcha}/{newEmail}")
    public Result updateNewQQEmailByUsername(@PathVariable("username") String username,
                                             @PathVariable("email") String email,
                                             @PathVariable("captcha") String captcha,
                                             @PathVariable("newEmail") String newEmail){

        return userService.updateNewQQEmailByUsername(username,email,captcha,newEmail);
    }

}
