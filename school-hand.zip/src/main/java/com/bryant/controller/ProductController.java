package com.bryant.controller;

import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.bryant.annotation.AuthAccess;
import com.bryant.annotation.Log;
import com.bryant.constant.ConstantsState;
import com.bryant.enums.BusinessType;
import com.bryant.exception.ServiceException;
import com.bryant.model.Dict;
import com.bryant.model.Product;
import com.bryant.model.vo.Dict.PageRequestDict;
import com.bryant.model.vo.Product.PageRequestProduct;
import com.bryant.model.vo.UserAdminVo.Ids;
import com.bryant.service.IDictService;
import com.bryant.service.IProductService;
import com.bryant.utils.Result;
import org.example.utils.OSSTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/userAdmin")
public class ProductController {

    @Resource
    IProductService iProductService;

    @Resource
    private OSSTemplate ossTemplate;

    /**
     * 商品列表分页查询
     * @param pageRequestProduct
     * @return
     */
    @AuthAccess
    @GetMapping("/product/list")
    public Result listProductPage(PageRequestProduct pageRequestProduct) {
        return iProductService.listProductPage(pageRequestProduct);
    }

    /**
     * 商品管理删除
     * @return
     */
    @Log(title = "商品管理",businessType = BusinessType.DELETE)
    @PutMapping("/product/deleteIds")
    public Result updateProductDeleteById(@RequestBody Ids ids){
        return iProductService.updateProductDeleteById(ids);
    }

    @Log(title = "商品管理", businessType = BusinessType.UPDATE)
    @PutMapping("/product/update")
    public Result updateProduct(@RequestBody Product product) {
        return iProductService.updateProduct(product);
    }

    @Log(title = "商品管理", businessType = BusinessType.EXPORT)
    @GetMapping("/product/exportList")
    public void exportDictList(HttpServletResponse response) throws Exception {
        List<Product> list = iProductService.list();
        if (Objects.nonNull(list) && !list.isEmpty()) {
            ExcelWriter writer = ExcelUtil.getWriter(true);
            // 一次性写出list内的对象到excel，使用默认样式，强制输出标题
            writer.write(list, true);

            // 设置浏览器响应的格式
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
            String fileName = URLEncoder.encode("商品管理", "UTF-8");
            response.setHeader("Content-Disposition", "attachment;filename=" + fileName + ".xlsx");

            ServletOutputStream out = response.getOutputStream();
            writer.flush(out, true);
            out.close();
            writer.close();
        } else {
            throw new ServiceException(ConstantsState.CODE_404, "数据不存在!");
        }
    }

    @Log(title = "商品管理", businessType = BusinessType.INSERT)
    @PostMapping("/product/add")
    public Result addProduct(@RequestBody Product product) {
        return iProductService.addProduct(product);
    }


    /**
     * 上传商品图片
     * @param file
     * @return
     */

    @Log(title = "OOS-商品管理",businessType = BusinessType.INSERT)
    @PostMapping("/product/changeAvatar")
    public Result updateUserAvatar(@RequestParam("file") MultipartFile file) {
        long size = file.getSize() / 1024;
        if (size >= 500) {
            throw new ServiceException(ConstantsState.CODE_40000, "文件大于500kb无法导入");
        }
        String url = ossTemplate.handleAvatar(file);
        if (StringUtils.isNotBlank(url)) {
            return Result.success(url);
        } else {
            return Result.error();
        }
    }


}
