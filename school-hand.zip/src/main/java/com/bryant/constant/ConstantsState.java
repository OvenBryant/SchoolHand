package com.bryant.constant;

/**
 @author greatcare
 @since 2022-04-23-16:24
 @detail 常量的接口
 */
public interface ConstantsState {


    String ACCESS_TOKEN = "Access-Token";
    /**
     * 成功
     */
    String CODE_200 = "200";

    /**
     * 系统错误
     */
    String CODE_500 = "500";

    /**
     * 验证码错误
     */
    String CODE_402 = "402";

    /**
     * 权限不足
     */
    String CODE_401 = "401";

    /**
     *  参数不足 bad require
     */
    String CODE_400 = "400";


    String CODE_404= "404";


    /**
     * 其他业务异常
     */
    String CODE_600 = "600";

    String CODE_40000 = "40000";
    String CODE_40000_ERR = "请求参数错误";
    String PARAMS_ERROR="请求参数错误";
    String NOT_LOGIN_ERROR="未登录";
    String NO_AUTH_ERROR = "无权限";
    String RESET_LOGIN="验证失败,请重新登录";
    String NOT_FOUND_ERROR="请求的数据不存在";
    String FORBIDDEN_ERROR="禁止访问";
    String SYSTEM_ERROR = "系统内部异常";
    String OPERATION_ERROR = "操作失败";


    String CODE_40101 = "40101";
    String CODE_40101_ERR = "请求数据不存在";


    String CAPTCHA_KEY = "captcha";

    String JWT_KEY = "jwt";

    /*
    男性数据库编码
     */
    String TYPE_MALE = "0";
    /*
    女性数据库编码
     */
    String TYPE_FEMALE = "1";
    /*
    混合楼编码
     */
    String TYPE_MF = "2";
    /*
    可以被使用数据库编码
     */
    String ENABLE_TRUE = "1";

    /*
    不可以被使用数据库编码
     */
    String ENABLE_FALSE = "0";

    /**
     * 空状态
     */
    String STUDENT_ZERO = "0";

    /**
     * 楼宇id为0
     */
    String FLOOR_ID = "0";


    // 在售
    int 在售 = 1;
    // 下架
    int 下架 = 0;

    int 待审核 = 0;
    int 审核中 = 1;
    int 通过 = 2;
    int 未通过 = 3;
    int 已撤回 = 4;

}
