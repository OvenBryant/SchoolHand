package com.bryant.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bryant.model.User;

public interface RegisterMapper extends BaseMapper<User> {

}
