package com.bryant.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bryant.model.Product;
import com.bryant.model.ProductRecord;
import com.bryant.utils.Result;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface ProductRecordMapper extends BaseMapper<ProductRecord> {

    @Select("select * from product_audits au left join product_record re on au.id = re.id")
    List<Map<String,Object>> getProductRecordAndAudits();
}
