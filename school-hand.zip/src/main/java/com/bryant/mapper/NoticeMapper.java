package com.bryant.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bryant.model.Notice;

public interface NoticeMapper extends BaseMapper<Notice> {

}
