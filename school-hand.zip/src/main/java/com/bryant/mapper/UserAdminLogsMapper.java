package com.bryant.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bryant.model.Logs;

public interface UserAdminLogsMapper extends BaseMapper<Logs> {

}
