package com.bryant.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bryant.model.ProductCart;
import com.bryant.model.vo.ProductCart.ProductCartAndProduct;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ProductCartMapper extends BaseMapper<ProductCart> {
    List<ProductCartAndProduct> listProductCart(@Param("userId") Long userId);

    ProductCart findProductCartByUserIdAndProductId(@Param("userId") Long userId,@Param("productId") Long productId);
}
