package com.bryant.mapper;

import cn.hutool.system.UserInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bryant.model.Dict;
import com.bryant.model.Product;
import com.bryant.model.vo.Product.ProductLimit5;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface ProductMapper extends BaseMapper<Product> {

    Page<Product> getProductPage(
            Page<Product> page,
            @Param("productName") String productName,
            @Param("category") String category,
            @Param("username") String username,
            @Param("status") Integer status,
            @Param("sortField") String sortField,
            @Param("sortOrder") String sortOrder);

    Product getProduct(@Param("userId") Integer userId, @Param("productId") Integer productId);

    int updateByIdStatus(@Param("productId") Integer productId);

    @Select("SELECT count(*) FROM `product`")
    int getProductItem();

    @Select("select category,count(*) `count` from product group by category order by count(*) desc limit 5")
    List<ProductLimit5> getProductLimit();
}
