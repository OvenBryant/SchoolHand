package com.bryant.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bryant.model.User;
import com.bryant.model.vo.Audits.ProductAuditsAndRecordAndUserInfo;
import com.bryant.utils.Result;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface UserMapper extends BaseMapper<User> {

    List<ProductAuditsAndRecordAndUserInfo> getAuditsInfoList(@Param("status") String status,@Param("productName") String productName,@Param("currentUser") String currentUser);

    @Select("SELECT count(*) FROM `user` where role = 1")
    int getUserMaleCount();

    @Select("SELECT count(*) FROM `user` where role = 0")
    int getUserFemaleCount();
}
