package com.bryant.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bryant.model.Dict;
import com.bryant.model.Notice;

public interface DictMapper extends BaseMapper<Dict> {

}
