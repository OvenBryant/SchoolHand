package com.bryant.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bryant.model.User;

public interface LoginMapper extends BaseMapper<User> {

}
