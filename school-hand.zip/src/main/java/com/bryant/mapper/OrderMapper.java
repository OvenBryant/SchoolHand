package com.bryant.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bryant.model.Orders;
import com.bryant.model.vo.Orders.HistoryProductOnOrders;
import com.bryant.utils.Result;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface OrderMapper extends BaseMapper<Orders> {

    @Select("select count(*) from `orders`")
    int getOrderItem();

    @Select("select sum(total_price) from orders")
    int getOrderTotalPrice();

    List<HistoryProductOnOrders> getProductHistoryOnOrders(@Param("userId") Long userId);
}
