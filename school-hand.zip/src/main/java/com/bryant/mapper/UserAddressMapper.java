package com.bryant.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bryant.model.Orders;
import com.bryant.model.UserAddress;
import org.apache.ibatis.annotations.Param;

public interface UserAddressMapper extends BaseMapper<UserAddress> {

    int updateByUserId(@Param("id") Long id,@Param("building") Integer building,
                       @Param("floor") Integer floor, @Param("roomNumber") Integer roomNumber,@Param("fullAddress") String fullAddress);
}
