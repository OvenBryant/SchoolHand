package com.bryant.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bryant.model.ProductAudits;
import com.bryant.model.ProductRecord;
import com.bryant.model.vo.ProductRecordAndAudits;

import java.util.List;

public interface ProductAuditsMapper extends BaseMapper<ProductAudits> {

    List<ProductRecordAndAudits> getProductRecordAndAudits();
}
