package com.bryant.enums;

/**
 * 业务操作类型
 *
 * @author fastvue
 */
public enum BusinessType {


    OTHER("其他"), INSERT("新增"), UPDATE("修改"), DELETE("删除"),BATCH_DELETE("删除多行"),
    LOCK("锁定"),LOGIN("登录"),

    GRANT("授权"), EXPORT("导出"), IMPORT("导入"), FORCE("强退"), CLEAN("清空数据");

    private String value;

    public String getValue() {
        return value;
    }

    BusinessType(String value){
        this.value = value;
    }

}
