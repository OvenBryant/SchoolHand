package com.bryant.enums;

/**
 * 字典ID
 *
 * @author fastvue
 */
public enum DictCategory {

    /**
     * 商品
     */
    PRODUCT(1);

    private Integer value;

    public Integer getValue() {
        return value;
    }

    DictCategory(Integer value) {
        this.value = value;
    }
}
