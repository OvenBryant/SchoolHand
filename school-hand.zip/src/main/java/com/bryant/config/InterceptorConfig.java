package com.bryant.config;



import com.bryant.config.interceptor.JwtInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author greatcare
 * @detail
 * @since 2022-05-30-23:11
 */
@Configuration
public class InterceptorConfig implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(jwtInterceptor())
                .addPathPatterns("/**")  // 拦截所有请求，通过判断token是否合法来决定是否需要登录
                // 登录接口我使用@AuthAccess注解放行了
                .excludePathPatterns("/user/getCode"
                        ,"/register/**","/forget/**"

                        ,"/**/*.html", "/**/*.js", "/**/*.css", "/**/*.woff",
                        "/**/*.ttf","/avatar/**",
                        "/swagger-resources/**","/webjars/**","/v2/**","/swagger-ui.html/**","doc.html","/error");
    }


    @Bean
    public JwtInterceptor jwtInterceptor() {
        return new JwtInterceptor();
    }


}
