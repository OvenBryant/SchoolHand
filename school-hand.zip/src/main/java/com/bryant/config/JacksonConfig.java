package com.bryant.config;

//@Configuration
public class JacksonConfig {

//    @Bean
//    public ObjectMapper jacksonObjectMapper(Jackson2ObjectMapperBuilder builder) {
//        ObjectMapper objectMapper = builder.createXmlMapper(false).build();
//
//        //全局配置序列化返回 JSON处理
//        SimpleModule simpleModule = new SimpleModule();
//        //JSON Long => String
//        simpleModule.addSerializer(Long.class, ToStringSerializer.instance);
//        objectMapper.registerModule(simpleModule);
//        return objectMapper;
//    }
}
