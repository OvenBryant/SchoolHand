package com.bryant.phone;


import com.bryant.phone.utils.SMSTemplate;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
@Data
@ComponentScan
@ConfigurationProperties("aliyun.sms")
public class SMSConfig {

    /**
     * 服务器地址
     */
    private String regionId;

    /**
     * 访问密钥id
     */
    private String accessKeyId;

    /**
     * 密钥
     */
    private String secret;

    /**
     * 签名名称
     */
    private String SignName;

    /**
     * 模板CODE
     */
    private String TemplateCode;

    @Bean
    public SMSTemplate smsTemplate() {
        return new SMSTemplate(regionId, accessKeyId, secret,SignName,TemplateCode);
    }
}