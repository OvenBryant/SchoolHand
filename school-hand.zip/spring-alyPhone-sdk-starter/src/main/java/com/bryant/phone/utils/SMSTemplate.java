package com.bryant.phone.utils;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.aliyuncs.CommonRequest;
import com.aliyuncs.CommonResponse;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.configurationprocessor.json.JSONException;

import java.util.HashMap;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SMSTemplate {

    private String regionId;

    private String accessKeyId;

    private String secret;

    private String SignName;
    private String TemplateCode;

    /**
     * 获取手机验证码
     */
    public String GetPhoneCode(String phone, String code){
        //整合阿里云短信服务
        //设置相关参数
        DefaultProfile profile = DefaultProfile.
                getProfile(regionId,
                        accessKeyId,
                        secret);

        IAcsClient client = new DefaultAcsClient(profile);
        CommonRequest request = new CommonRequest();
        //request.setProtocol(ProtocolType.HTTPS);
        request.setMethod(MethodType.POST);
        request.setDomain("dysmsapi.aliyuncs.com");
        request.setVersion("2017-05-25");
        request.setAction("SendSms");


        //手机号
        request.putQueryParameter("PhoneNumbers", phone);
        //签名名称
        request.putQueryParameter("SignName", SignName);
        //模板code
        request.putQueryParameter("TemplateCode", TemplateCode);
        //验证码  使用json格式   {"code":"123456"}
        Map<String,Object> param = new HashMap();
        param.put("code",code);
        request.putQueryParameter("TemplateParam", JSONObject.toJSONString(param));

        //调用方法进行短信发送
        try {
            CommonResponse response = client.getCommonResponse(request);
            System.out.println("---------------------");
            System.out.println(response.getData());
            System.out.println("---------------------");
            JSONObject jsonObject = JSON.parseObject(response.getData());
            String message = jsonObject.getString("Message");
            return message;
//            if("OK".equals(message)){
//                return true;
//            }
//            return response.getHttpResponse().isSuccess();
        } catch (ClientException e) {
            e.printStackTrace();
            return "Error sending SMS :"+e.getMessage();
        } catch (Exception e){
            e.printStackTrace();
            return "An unexpected error occurred: "+e.getMessage();
        }
    }




}
