package com.bryant.email.utils;


import com.sun.mail.util.MailSSLSocketFactory;
import lombok.Data;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

@Data
public class QQEmailTemplate {

    private static Session session;
    private static String sender = "hu123tfsdase@foxmail.com";

    private static String code = "qlhpxzucgmawgfee";

    private static String receiver;

    private static String subject = "校园二手交易平台";

    /**
     * 功能文字描述：比如验证码是,找回密码..
     */
 //   private static String desc = "";

    public QQEmailTemplate(String _receiver) {
        QQEmailTemplate.receiver = _receiver;
    }

    /**
     * 发送QQ邮箱
     * @param desc 功能描述
     * @param msg  当前发送的内容
     * @throws Exception
     */
    public void sendMessage(String desc,String msg) throws Exception {
        MimeMessage mm = createMimeMessage(desc,msg);
        Transport transport = QQEmailTemplate.session.getTransport();
        //3、使用邮箱用户名和授权码连接上邮件服务器（这里其实对应的就是登录邮箱）
        transport.connect("smtp.qq.com", QQEmailTemplate.sender, QQEmailTemplate.code);
        //5、发送邮件
        transport.sendMessage(mm, mm.getAllRecipients());
        //6、关闭
        transport.close();

    }


    private MimeMessage createMimeMessage(String desc,String msg) throws Exception {
        // 准备工作  需要去邮箱  开启POP3和SMTP服务
        //1.1 创建一个配置文件保存并读取信息
        Properties properties = new Properties();
        //1.2 设置邮件服务器（这里使用了QQ邮箱）
        properties.setProperty("mail.host", "smtp.qq.com");
        //1.3 设置发送使用的协议
        properties.setProperty("mail.transport.protocol", "smtp");
        //1.4 设置用户是否需要验证
        properties.setProperty("mail.smtp.auth", "true");
        //1.5 关于QQ邮箱，还要设置SSL加密，安全连接 ，加上以下代码即可
        MailSSLSocketFactory sf = new MailSSLSocketFactory();
        sf.setTrustAllHosts(true);
        properties.put("mail.smtp.ssl.enable", "true");
        properties.put("mail.smtp.ssl.socketFactory", sf);
        properties.put("mail.smtp.ssl.protocols", "TLSv1.2");
        QQEmailTemplate.session = Session.getDefaultInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                //邮箱用户名和授权码
                return new PasswordAuthentication(QQEmailTemplate.sender, QQEmailTemplate.code);
            }
        });

        //4.1 创建用来发送邮件的对象(需要传入session)
        MimeMessage mimeMessage = new MimeMessage(QQEmailTemplate.session);
        //4.2 创建邮件发送人
        mimeMessage.setFrom(new InternetAddress(QQEmailTemplate.sender));
        //4.3 创建邮件接收人(可以同时发送给很多人（添加抄送）)
//        mimeMessage.setRecipients(Message.RecipientType.TO, new InternetAddress[]{new InternetAddress(sendFrom)});
//        for (int i = 0; i < sendFrom.length; i++) {
//            mimeMessage.setRecipients(Message.RecipientType.TO,sendFrom[i]);
//        }
        mimeMessage.setRecipients(Message.RecipientType.TO, QQEmailTemplate.receiver);
        //4.4 创建邮件主题
        mimeMessage.setSubject(QQEmailTemplate.subject);

        //4.5 创建邮件正文
        //mimeMessage.setContent("您的验证码是：" + content, "text/html;charset=UTF-8");
        mimeMessage.setContent(desc + "<br><span style='color:red;'>" + msg + "</span>",
                "text/html;charset=gbk");
        return mimeMessage;
    }
}
