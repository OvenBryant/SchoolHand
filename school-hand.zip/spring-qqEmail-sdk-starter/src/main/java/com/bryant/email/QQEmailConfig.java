package com.bryant.email;

import com.bryant.email.utils.QQEmailTemplate;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "qq.email")
@Data
@ComponentScan
public class QQEmailConfig {

    /**
     * 接收方QQ邮箱
     */
    private String Receiver;

    @Bean
    public QQEmailTemplate qqEmailTemplate(){
        return new QQEmailTemplate(Receiver);
    }

}
