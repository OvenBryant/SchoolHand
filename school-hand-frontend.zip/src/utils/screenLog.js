/* eslint-disable */
export const printANSI = () => {
  console.log('------校园二手交易平台------')
}
