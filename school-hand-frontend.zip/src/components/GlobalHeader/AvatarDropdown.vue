<template>
  <a-dropdown v-if='userInfo && userInfo.nickname' placement='bottomRight'>
    <span class='ant-pro-account-avatar'>
      <a-avatar
        v-if='this.$store.getters.headAvatar'
        size='small'
        :src='this.$store.getters.headAvatar'
        class='antd-pro-global-header-index-avatar'
      />

      <a-avatar
        v-else-if='userInfo.avatar'
        size='small'
        :src='userInfo.avatar'
        class='antd-pro-global-header-index-avatar'
      />

      <a-avatar v-else size='small' :src='defaultImg' class='antd-pro-global-header-index-avatar' />

      <span v-if="userInfo.nickname && userInfo.nickname.trim() != ''">{{ userInfo.nickname }}</span>
      <span v-else>{{ userInfo.username }}</span>
    </span>
    <template v-slot:overlay>
      <a-menu class='ant-pro-drop-down menu' :selected-keys='[]'>
<!--        <a-menu-item v-if='menu' key='center' @click='handleToCenter'>-->
<!--          <a-icon type='user' />-->
<!--          {{ $t('menu.account.center') }}-->
<!--        </a-menu-item>-->

        <a-menu-item v-if='menu' key='settings' @click='handleToSettings'>
          <a-icon type='setting' />
          <!-- 个人设置 -->
          {{ $t('menu.account.settings') }}
        </a-menu-item>

<!--        <a-menu-item v-if='menu' @click='handleToProduct'>-->
<!--          <a-icon type='setting' />-->
<!--          商品管理-->
<!--        </a-menu-item>-->

        <!-- 修改密码 -->
        <!-- <a-menu-item key="resetPwd" @click="resetPwd">
          <a-icon type="key" />
          修改密码
        </a-menu-item> -->

        <a-menu-divider v-if='menu' />
        <a-menu-item key='logout' @click='handleLogout'>
          <a-icon type='logout' />
          <!-- 退出登录 -->
          {{ $t('menu.account.logout') }}
        </a-menu-item>
      </a-menu>
    </template>
  </a-dropdown>

  <span v-else>
    <a-spin size='small' :style='{ marginLeft: 8, marginRight: 8 }' />
  </span>
</template>

<script>
import { Modal } from 'ant-design-vue'

import USER from '@/api/user'
import storage from 'store'
import { ACCESS_TOKEN } from '@/store/mutation-types'


export default {
  name: 'AvatarDropdown',
  props: {
    // currentUser: {
    //   type: Object,
    //   default: () => null,
    // },
    menu: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      // img: "https://gw.alipayobjects.com/zos/antfincdn/XAosXuNZyF/BiazfanxmamNRoxxVxka.png"
      // defaultImg: '/uploadImg.png',
      // defaultImg: require('../assets/school.png'),
      defaultImg: require('@/assets/school.png'),
      userInfo: {},
      userNickName: ''
    }
  },
  created() {
    this.getCurrentUser()
  },

  // computed: {
  //   ...mapState(['headAvatar']),
  // },

  methods: {
    getCurrentUser() {
      const currentUser = this.$cookie.get('user')
      console.log('当前用户flag: ', currentUser)
      USER.getCurrentUser(currentUser)
        .then((res) => {
          if (res.code === '200') {
            this.userInfo = res.data
            console.log('昵称: ',this.userInfo.nickname)
            console.log('头像信息: ', this.userInfo)
            // setTimeout(() => {
            //
            // }, 1500)
          } else {
            this.$notification.error({
              message: '错误',
              description: res.msg
            })
          }
        })
        .catch((err) => err)
    },
    // 个人中心
    handleToCenter() {
      this.$router.push({ path: '/account/center' })
    },

    // 修改密码
    resetPwd() {

    },

    // 个人设置
    handleToSettings() {
      this.$router.push({ path: '/userAccount/settings' })
    },

    // 我的商品
    handleToProduct(){
      this.$router.push({ path: '/MyProductTabs' })
    },
    // 退出登录
    handleLogout(e) {
      Modal.confirm({
        title: this.$t('layouts.usermenu.dialog.title'),
        content: this.$t('layouts.usermenu.dialog.content'),
        onOk: () => {
          // return new Promise((resolve, reject) => {
          //   setTimeout(Math.random() > 0.5 ? resolve : reject, 1500)
          // }).catch(() => console.log('Oops errors!'))
          // return this.$store.dispatch('Logout').then(() => {
          //   this.$router.push({ name: 'login' })
          // })
          console.log('-----确定退出-----')
          this.$store.commit('SET_TOKEN', '')
          this.$store.commit('SET_ROLE', '')
          this.$store.commit('SET_USERNAME', '')
          this.$cookie.set('pwdState', '')
          this.$cookie.set('user', '')
          storage.remove('user')

          storage.remove(ACCESS_TOKEN)

          this.$router.push({ name: 'login' })
        },
        onCancel() {
        }
      })
    }
  },
}
</script>

<!--<style lang='less' scoped>-->
<!--.ant-pro-drop-down {-->
<!--  :deep(.action) {-->
<!--    margin-right: 8px;-->
<!--  }-->

<!--  :deep(.ant-dropdown-menu-item) {-->
<!--    min-width: 160px;-->
<!--  }-->
<!--}-->
<!--</style>-->
