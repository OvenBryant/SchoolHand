<template>
  <div :class='wrpCls'>
     <span
           @click='handleFull'
           :style="{marginRight: '4px', color: isfull ? 'black' : 'initial', fontWeight: isfull ? 'bold' : 'normal'}">
    <a-icon :type="isfull ? 'fullscreen-exit' : 'fullscreen'" />
  </span>
    <avatar-dropdown :menu='showMenu' :class='prefixCls' />
    <select-lang :class='prefixCls' />
  </div>
</template>

<script>
import AvatarDropdown from './AvatarDropdown'
import SelectLang from '@/components/SelectLang'


export default {
  name: 'RightContent',
  components: {
    AvatarDropdown,
    SelectLang
  },
  props: {
    prefixCls: {
      type: String,
      default: 'ant-pro-global-header-index-action'
    },
    isMobile: {
      type: Boolean,
      default: () => false
    },
    topMenu: {
      type: Boolean,
      required: true
    },
    theme: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      showMenu: true,
      isfull: false
    }
  },
  methods: {
    // 全屏
    handleFull() {
      this.isfull = !this.isfull
      if (this.isfull) {
        document.documentElement.requestFullscreen()
      } else {
        document.exitFullscreen()
      }
    }
  },
  computed: {
    wrpCls() {
      return {
        'ant-pro-global-header-index-right': true,
        [`ant-pro-global-header-index-${this.isMobile || !this.topMenu ? 'light' : this.theme}`]: true
      }
    }
    // headAvatar() {
    //   return this.$store.getters.headAvatar
    // },
    // ...mapState(['headAvatar']),
  }

}
</script>
