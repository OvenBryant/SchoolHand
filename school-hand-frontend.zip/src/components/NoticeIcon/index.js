import NoticeIcon from './NoticeIcon'
export default NoticeIcon
