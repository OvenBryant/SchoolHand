import AvatarList from './List'
import Item from './Item'

export {
  AvatarList,
  Item as AvatarListItem
}

export default AvatarList
