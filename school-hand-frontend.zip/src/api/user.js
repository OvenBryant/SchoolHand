import request from '@/utils/request'

export default {

  /**
   *
   * @param {根据账号或者手机号查找当前用户} usernameOrPhone
   * @returns
   */
  getCurrentUser (usernameOrPhone) {
    return request({
      url: `/user/getUserInfo/${usernameOrPhone}`,
      method: 'get'
    })
  },

  /**
   * 根据当前账号查看旧密码是否正确
   * @param {当前登录的账号} username
   * @param {旧密码} oldPwd
   * @returns
   */
  getpwdByUsername (username, oldPwd) {
    return request({
      url: `/user/getpwdByUsername/${username}/${oldPwd}`,
      method: 'get'
    })
  },

  /**
   * 重置密码
   * @param {*} username
   * @param {*} oldPwd
   * @param {*} newPwd
   * @param {*} surePwd
   * @returns
   */
  resetPwdByUsername(username, oldPwd, newPwd, surePwd) {
    return request({
      url: `/user/resetPwdByUsername/${username}/${oldPwd}/${newPwd}/${surePwd}`,
      method: 'put'
    })
  },

  /**
   *
   * @param {根据用户名验证手机号是否正确} phone
   * @returns
   */
  validCurrentPhoneByUsername(username, phone) {
    return request({
      url: `/user/validCurrentPhoneByUsername/${username}/${phone}`,
      method: 'post'
    })
  },


  /**
   *
   * @param {*} username
   * @param {*} email
   */
  validCurrentEmailByUsername(username, email) {
    return request({
      url: `/user/validCurrentEmailByUsername/${username}/${email}`,
      method: 'post'
    })
  },


  /**
   *
   * @param {更新用户信息根据账号} user
   * @returns
   */
  updateUserBasicInfoByUsername(user) {
    return request({
      url: '/user/updateUserBasicInfoByUsername',
      method: 'post',
      data: user
    })
  },

  /**
   * 修改手机号的第一步 【可以直接用这个手机号验证,当然也可以加个用户名】
   *
   * @param {当前登录的账号} _username
   * @param {注册过的手机号} _phone
   * @param {手机号的验证码} _captcha
   */
  VerifyPhoneFirstStepByUsername(_username, _phone, _captcha) {
    return request({
      url: `/user/verifyPhoneFirstStep/${_username}/${_phone}/${_captcha}`,
      method: 'post'
    })
  },


  /**
   *
   * @param {当前用户} _username
   * @param {旧的手机号} _oldPhone  可以简单验证一下，判断当前账号和旧手机号是否存在,如果存在就替换新手机号
   * @param {新的手机号} _newPhone
   * @param {新手机号验证码} _captcha
   */
  VerifyPhoneTwoStepByUsername(_username, _oldPhone, _newPhone, _captcha) {
    return request({
      url: `/user/verifyPhoneTwoStep/${_username}/${_oldPhone}/${_newPhone}/${_captcha}`,
      method: 'post'
    })
  },

  /**
   *
   * @param {根据邮箱获取随机验证码} email
   * @returns
   */
  getQQEmailCaptcha(email) {
    return request({
      url: `/user/qqEmail/${email}`,
      method: 'post'
    })
  },


  /**
   *
   * @param {当前用户名} _username
   * @param {原始QQ邮箱} _email
   * @param {原始QQ邮箱验证码} _captcha
   * @param {新的QQ邮箱} _newEmail
   */
  updateNewQQEmailByUsername(_username, _email, _captcha, _newEmail) {
    return request({
      url: `/user/updateNewQQEmailByUsername/${_username}/${_email}/${_captcha}/${_newEmail}`,
      method: 'post'
    })
  }

}
