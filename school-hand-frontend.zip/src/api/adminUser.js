import request from '@/utils/request'

export const userAdmin = {
  addUser: '/userAdmin/addUser',
  updateUser: '/userAdmin/updateUser',
  exportUrl: '/userAdmin/export',
  importUrl: '/userAdmin/importExcel',
  getOneUser: '/userAdmin/getOneUser',
}


/**
 * 管理员添加用户
 * @param values
 * @returns {*}
 */
export function addUser(values) {
  return request({
    url: userAdmin.addUser,
    method: 'post',
    data: values
  })
}

/**
 * 修改用户
 * @param values
 * @returns {*}
 */
export function updateUser(values) {
  return request({
    url: userAdmin.updateUser,
    method: 'put',
    data: values
  })
}

/**
 * 根据id获取
 * @param id
 * @returns {*}
 */
export function getOneUser(id){
  return request({
    url: userAdmin.getOneUser + `/${id}`,
    method: 'get',
  })
}

export function exportExcel(url) {
  return request({
    url: url,
    method: 'get',
    responseType: 'blob'
  })
}

export function importExcel(formData) {
  return request({
    url: userAdmin.importUrl,
    method: 'post',
    data: formData
  })
}

// 获取管理员首页相关数据
export function getAdminHomeData(){
  return request({
    url: 'userAdmin/adminHome/getAdminHomeData',
    method: 'get',
  })
}