import request from '@/utils/request'

const userApi = {
  Login: '/auth/loin',
  // Login: '/getCode',
  Logout: '/auth/logout',
  ForgePassword: '/auth/forge-password',
  Register: '/auth/register',
  twoStepCode: '/auth/2step-code',
  SendSms: '/getCode',
  SendSmsErr: '/account/sms_err',
  // get my info
  UserInfo: '/user/info',
  UserMenu: '/user/nav'
}

/**
 * login func
 * parameter: {
 *     username: '',
 *     password: '',
 *     remember_me: true,
 *     captcha: '12345'
 * }
 * @param parameter
 * @returns {*}
 */

// 用户名和密码登录
export function login(parameter) {
  return request({
    url: `/login/login/${parameter.username}/${parameter.password}`,
    method: 'post'
  })
}

// 手机号+验证码登录
export function phoneLogin(values) {
  return request({
    url: `/login/phoneLogin/${values.mobile}/${values.captcha}`,
    method: 'post'
  })
}

export function getSmsCaptchaOfLogin(parameter) {

  return request({
    url: `/login/getPhoneCode/${parameter}`,
    method: 'post'
  })
}


export function getInfo() {
  return request({
    url: userApi.UserInfo,
    method: 'get',
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function getCurrentUserNav() {
  return request({
    url: userApi.UserMenu,
    method: 'get'
  })
}

export function logout() {
  return request({
    url: userApi.Logout,
    method: 'post',
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

/**
 * get user 2step code open?
 * @param parameter {*}
 */
export function get2step(parameter) {
  return request({
    url: userApi.twoStepCode,
    method: 'post',
    data: parameter
  })
}
