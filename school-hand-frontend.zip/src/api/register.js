import request from '@/utils/request'


export function getSmsCaptchaOfRegister (parameter) {
    return request({
      url:  `/register/getPhoneCode/${parameter}`,
      method: 'post',
    })
  }

  export function RegisterInfo (values) {
    return request({
      url:  `/register/register/`,
      method: 'post',
      data:values
    })
  }


  

