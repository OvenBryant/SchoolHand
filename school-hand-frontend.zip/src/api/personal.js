import request from '@/utils/request'

export function updateImg (formData) {
  return request({
    url: `user/changeAvatar`,
    method: 'post',
    data: formData
  })
}
