import request from '@/utils/request'

export const api = {
  getPageNoticeListAPI: '/userAdmin/notice/list',
  addNotice: '/userAdmin/notice/add',
  updateLogsDeleteByOperId: '/userAdmin/logs/deleteMore',
  updateLogsDeleteAll: '/userAdmin/logs/deleteAll',
  exportUrl: '/userAdmin/logs/export',
  getLatestFiveNotices: '/userAdmin/user/notice/getLatest',
  updateCurrentNotice: '/userAdmin/notice/updateCurrentNotice',
  updateNoticeDeleteById: '/userAdmin/notice/deleteIds',
}

export function updateCurrentNotice(params) {
  return request({
    url: api.updateCurrentNotice,
    method: 'put',
    data: params
  })
}

export function updateNoticeDeleteById(ids) {
  return request({
    url: api.updateNoticeDeleteById,
    method: 'put',
    data: ids
  })
}

export function getLatestFiveNotices() {
  return request({
    url: api.getLatestFiveNotices,
    method: 'get'
  })
}

export function getPageNoticeList(parameter) {
  return request({
    url: api.getPageNoticeListAPI,
    method: 'get',
    params: parameter
  })
}

export function addNotice(form) {
  return request({
    url: api.addNotice,
    method: 'post',
    data: form
  })
}

export function updateLogsDeleteByOperId(operIdMore) {
  return request({
    url: api.updateLogsDeleteByOperId,
    method: 'delete',
    data: operIdMore
  })
}

export function updateLogsDeleteAll() {
  return request({
    url: api.updateLogsDeleteAll,
    method: 'delete'
  })
}

export function exportLogs() {
  return request({
    url: api.exportUrl,
    method: 'get'
  })
}


export default api

