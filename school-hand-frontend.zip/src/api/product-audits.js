import request from '@/utils/request'

// 获取普通用户的商品审核信息
export function getAuditsList(params) {
  return request({
    url: `/user/productRecord/getAuditsList`,
    method: 'post',
    data: params
  })
}

// 管理员审核商品
export function getAuditsInfoList(status,params) {
  return request({
    url: `/userAdmin/getAuditsInfoList/${status}`,
    method: 'post',
    params: params
  })
}

// 管理员审核商品-通过
export function postAuditsInfoSuccess(isSuccess,params) {
  return request({
    url: `/userAdmin/postAuditsInfo/${isSuccess}`,
    method: 'post',
    data: params
  })
}