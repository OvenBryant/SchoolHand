import request from '@/utils/request'

export const api = {
  getlistProductPage: '/userAdmin/product/list',
  updateProductDeleteById: '/userAdmin/product/deleteIds',
  updateProduct: '/userAdmin/product/update',
  addProduct: '/userAdmin/product/add',
  updateProductImg: '/userAdmin/product/changeAvatar',

  exportProductList: '/userAdmin/product/exportList',
  addDict: '/userAdmin/dict/add',
}

// 添加商品到商品记录表中
export function addProductRecord(form) {
  return request({
    url: '/user/productRecord/add',
    method: 'post',
    data: form
  })
}

export function updateProductImg (formData) {
  return request({
    url: api.updateProductImg,
    method: 'post',
    data: formData
  })
}


export function updateProductDeleteById(ids) {
  return request({
    url: api.updateProductDeleteById,
    method: 'put',
    data: ids
  })
}

export function getlistProductPage(parameter) {
  return request({
    url: api.getlistProductPage,
    method: 'get',
    params: parameter
  })
}

export function exportDictList(){
  return request({
    url: api.exportDictList,
    method: 'get',
  })
}



export function updateProduct(form){
  return request({
    url: api.updateProduct,
    method: 'put',
    data: form
  })
}

export default api

