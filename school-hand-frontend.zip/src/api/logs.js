import request from '@/utils/request'

export const api = {
  getPageLogsListAPI: '/userAdmin/logs/list',
  updateLogsDeleteByOperId: '/userAdmin/logs/deleteMore',
  updateLogsDeleteAll: '/userAdmin/logs/deleteAll',
  exportUrl: '/userAdmin/logs/export'
}


export function getPageLogsList(parameter) {
  return request({
    url: api.getPageLogsListAPI,
    method: 'get',
    params: parameter
  })
}

export function updateLogsDeleteByOperId(operIdMore) {
  return request({
    url: api.updateLogsDeleteByOperId,
    method: 'delete',
    data: operIdMore
  })
}

export function updateLogsDeleteAll() {
  return request({
    url: api.updateLogsDeleteAll,
    method: 'delete'
  })
}

export function exportLogs() {
  return request({
    url: api.exportUrl,
    method: 'get',
  })
}


export default api

