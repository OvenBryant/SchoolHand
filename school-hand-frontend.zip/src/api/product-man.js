import request from '@/utils/request'

// 添加商品到购物车中
export function addProductCart(productId) {
  return request({
    url: `/user/productMan/productCart/add/${productId}`,
    method: 'post'
  })
}

// 获取购物车中的所有信息
export function listProductCart() {
  return request({
    url: `/user/productMan/productCart/getList`,
    method: 'get'
  })
}

// 删除购物车物品
export function deleteCartById(Id) {
  return request({
    url: `/user/productMan/productCart/delete/${Id}`,
    method: 'put'
  })
}

// 删除我的商品
export function deleteProductById(Id) {
  return request({
    url: `/user/productMan/product/delete/${Id}`,
    method: 'put'
  })
}


// 获取我的商品
export function MyProduct() {
  return request({
    url: `/user/productMan/myProduct`,
    method: 'get'
  })
}

// 获取购买历史
export function getHistory() {
  return request({
    url: `/user/productMan/getHistory`,
    method: 'get'
  })
}

// 立即购买
export function ljBuy(data) {
  return request({
    url: `/user/productMan/ljBuy`,
    method: 'post',
    data: data
  })
}

// 获取用户地址
export function getUserAddress() {
  return request({
    url: `/user/productMan/userAddress`,
    method: 'get'
  })
}