import request from '@/utils/request'

export const api = {
  getPageDictList: '/userAdmin/dict/list',
  exportDictList: '/userAdmin/dict/exportList',
  addDict: '/userAdmin/dict/add',
  updateDict: '/userAdmin/dict/update',
  updateDictDeleteById: '/userAdmin/dict/deleteIds',
  getDictNameByCategoryId: '/userAdmin/getDictNameByCategoryId'
}

export function updateDictDeleteById(ids) {
  return request({
    url: api.updateDictDeleteById,
    method: 'put',
    data: ids
  })
}

export function getPageDictList(parameter) {
  return request({
    url: api.getPageDictList,
    method: 'get',
    params: parameter
  })
}

export function exportDictList(){
  return request({
    url: api.exportDictList,
    method: 'get',
  })
}

export function addDict(form) {
  return request({
    url: api.addDict,
    method: 'post',
    data: form
  })
}

export function updateDict(form){
  return request({
    url: api.updateDict,
    method: 'put',
    data: form
  })
}

export function getDictNameByCategoryId(){
  return request({
    url: api.getDictNameByCategoryId,
    method: 'get'
  })
}
export default api

