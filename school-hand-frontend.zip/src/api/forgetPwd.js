import request from '@/utils/request'


export function validPwdEmail(phone, email) {
  return request({
    url: `/forget/findPwd/email/${phone}/${email}`,
    method: 'post'
  })
}

export function validPwdPhone(phone) {
  return request({
    url: `/forget/findPwd/phone/${phone}`,
    method: 'post'
  })
}




