import request from '@/utils/request'

export const api = {
  getlistProductPage: '/userAdmin/product/list',
  updateProductDeleteById: '/userAdmin/product/deleteIds',
  updateProduct: '/userAdmin/product/update',
  addProduct: '/userAdmin/product/add',
  updateProductImg: '/userAdmin/product/changeAvatar',

  exportProductList: '/userAdmin/product/exportList',
  addDict: '/userAdmin/dict/add',
}

export function updateProductImg (formData) {
  return request({
    url: api.updateProductImg,
    method: 'post',
    data: formData
  })
}


export function updateProductDeleteById(ids) {
  return request({
    url: api.updateProductDeleteById,
    method: 'put',
    data: ids
  })
}

export function getlistProductPage(parameter) {
  return request({
    url: api.getlistProductPage,
    method: 'get',
    params: parameter
  })
}

export function exportDictList(){
  return request({
    url: api.exportDictList,
    method: 'get',
  })
}

export function addProduct(form) {
  return request({
    url: api.addProduct,
    method: 'post',
    data: form
  })
}

export function updateProduct(form){
  return request({
    url: api.updateProduct,
    method: 'put',
    data: form
  })
}

export default api

