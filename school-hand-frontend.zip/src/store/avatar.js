// import Vue from 'vue'
// import Vuex from 'vuex'

// Vue.use(Vuex)

const avatar = {
  state: {
    headAvatar: '',
  },
  getters: {
    headAvatar: state => state.headAvatar,  
  },
  mutations: {
    setHeadAvatar(state, value) {
      state.headAvatar = value
    },
  },
  actions: {},
  modules: {},
}

export default avatar
