<template>
  <div>
    <a-card :body-style='{ padding: 0, margin: 0 }'>
      <a-card style='background-color: cadetblue;' :body-style='{padding:0,margin:0}'>
        <div style='display: flex; justify-content: center; align-items: center;'>
          <span style='font-weight: bolder; font-size: 20px; font-style: italic;'>联系管理员</span>
        </div>
      </a-card>
    </a-card>
    <div style='height: 420px;overflow-y:auto;background-color: #f0f2f5'>
      <div>
        <div :class="message.sender==='me'?'chat-message-me':'chat-message-other'"
             :style="{'padding-bottom':messages.length-1===index?'2rem':'none'}"
             v-for='(message, index) in messages'
             :key='index'>
          <!--            消息头像-->
          <div :class="message.sender==='me'?'message-me-asWhole-headPortrait':'message-other-asWhole-headPortrait'">
            <img
              :src="message.sender === 'me' ? senderAvatar : receiverAvatar"
              class='examineeFace_logo_style'>
          </div>
          <!--          消息-->
          <div :class="message.sender==='me'?'message-me-asWhole-right':'message-other-asWhole-right'">
            <!--            消息上面-->
            <div :class="message.sender==='me'?'message-me-asWhole-top':'message-other-asWhole-top'">
              <span v-if="message.sender==='me'">{{ currentGoodBuyMoreContactSell.username }}</span>
              <span v-else style='font-weight: bold'>管理员</span>
            </div>
            <!--          消息内容-->
            <div :class="message.sender==='me'?'message-me':'message-other'">
              <span v-if="message.sender==='me'"
                    style='background-color: limegreen;color: black;padding:1px '> {{ message.content }}</span>
              <span v-else style='background-color: white;padding:1px;color: black'> {{ message.content }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <a-input-search
      placeholder='安Enter发送'
      enter-button='发 送'
      size='large'
      @search='handleSearch'
      @keyup.enter.native='handleSearch'
    />
  </div>
</template>

<script>
import storage from 'store'

export default {
  name: 'ContactAdmin',
  data() {
    return {
      currentGoodBuyMoreContactSell: {},
      messages: [
        { sender: 'me', content: '您好,我想咨询一下关于产品使用的问题。' },
        { sender: 'other', content: '您好，请问您具体遇到了什么问题？我会尽力为您解答。' },
        { sender: 'me', content: '我刚刚购买了一款智能手环，但是不太会设置，能指导下吗？' },
        { sender: 'other', content: '不好意思哈,这边您可以先跟商家联系一下试试看' },
        { sender: 'other', content: '这边只提供交易渠道,不提供这些服务的' },
        { sender: 'me', content: '好的，谢谢了！' },
        { sender: 'other', content: '🌹' },
        { sender: 'other', content: '不客气，很高兴能帮助到您。祝您生活愉快，有问题随时联系！' }
      ],
      senderAvatar: require('@/assets/i.png'),
      receiverAvatar: require('@/assets/iconLogo.png')
    }
  },
  mounted() {
    this.currentGoodBuyMoreContactSell = storage.get('currentGoodBuyMoreContactSell') ? storage.get('currentGoodBuyMoreContactSell') : this.$route.params.item
    // this.receiverAvatar = this.currentGoodBuyMoreContactSell.image[0].url
  },
  methods: {
    handleSearch(value) {
      console.log(value)
    },
    getMessageClass(message, index) {
      return index === message.length - 1
        ? 'chat-message-me chat-message-last'
        : 'chat-message-me'
    },
    getMessageAvatarClass(message) {
      return message.sender === 'me'
        ? 'message-me-asWhole-headPortrait'
        : 'message-other-asWhole-headPortrait'
    },
    getAvatarPath() {
      return require('@/assets/goodsIcon.png')
    },
    getMessageContentClass(message) {
      return message.sender === 'me'
        ? 'message-me-asWhole-right'
        : 'message-other-asWhole-right'
    },
    getMessageTopClass(message) {
      return message.sender === 'me'
        ? 'message-me-asWhole-top'
        : 'message-other-asWhole-top'
    },
    getMessageTextClass(message) {
      return message.sender === 'me' ? 'message-me' : 'message-other'
    }
  }
}
</script>

<style scoped>
.chat-message-other {
  /*background-color: red;*/
  display: flex;
  padding-left: 1rem;
  padding-top: 1rem;
}

.chat-message-me {
  /*background-color: red;*/
  display: flex;
  padding-right: 1rem;
  padding-top: 1rem;
  flex-direction: row-reverse; /* 将子div的顺序反转 */

}

.message-me-asWhole-headPortrait {
  padding: 3px;
}

.message-other-asWhole-headPortrait {
  padding: 3px;
}

.message-me-asWhole-right {
  display: flex;
  flex-direction: column; /* 设置子元素垂直排列 */
  margin-left: 0.1rem;
}

.message-other-asWhole-right {
  display: flex;
  flex-direction: column; /* 设置子元素垂直排列 */
  margin-left: 0.1rem;
}

.message-me-asWhole-top {
  padding: 3px;
  /* font-size: 12px; */
  font-family: 微软雅黑;
  padding: 3px;
  color: rgba(134, 144, 156, 1);
  text-align: right;
}

.message-other-asWhole-top {
  padding: 3px;
  /* font-size: 12px; */
  font-family: 微软雅黑;
  padding: 3px;
  color: rgba(134, 144, 156, 1);
}

.message-me {
  background-color: rgba(242, 243, 245, 1);
  max-width: 300px;
  word-wrap: break-word; /* 处理英文单词换行 */
  word-break: break-all; /* 处理中文换行 */
  display: inline-block; /*将div元素转换为行内块元素*/
  width: auto; /* 宽度根据文本宽度自动调正*/
  padding: 6px 12px;
  border-radius: 4px;
}

.message-other {
  background-color: rgba(242, 243, 245, 1);
  max-width: 300px;
  word-wrap: break-word; /* 处理英文单词换行 */
  word-break: break-all; /* 处理中文换行 */
  display: inline-block; /*将div元素转换为行内块元素*/
  width: auto; /* 宽度根据文本宽度自动调正*/
  padding: 6px 12px;
  border-radius: 4px;
}

.examineeFace_logo_style {
  width: 30px;
}

</style>