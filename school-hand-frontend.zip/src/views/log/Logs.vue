<template>
  <page-header-wrapper>
    <a-card :bordered='false'>
      <div class='table-page-search-wrapper'>
        <a-form layout='inline'>
          <a-row :gutter='48'>
            <a-col :md='6' :sm='6'>
              <a-form-item label='系统模块'>
                <a-input v-model='queryParam.title' placeholder='请输入系统模块' @change='showChange()' allowClear />
              </a-form-item>
            </a-col>
            <a-col :md='6' :sm='6'>
              <a-form-item label='操作人员'>
                <a-input v-model='queryParam.operName' placeholder='请输入操作人员' @change='showChange()' allowClear />
              </a-form-item>
            </a-col>
            <a-col :md='5' :sm='5'>
              <a-form-item label='类型'>
                <a-select v-model='queryParam.businessType' placeholder='操作类型'
                          allowClear
                          @change='showChange()'>
                  <a-select-option v-for='(option, index) in businessType' :key='index' :value='option.value'>
                    {{ option.label }}
                  </a-select-option>
                </a-select>
              </a-form-item>
            </a-col>
            <a-col :md='4' :sm='4'>
              <a-form-item label='状态'>
                <a-select v-model='queryParam.status' placeholder='操作类型' allowClear
                          @change='showChange()'>
                  <a-select-option v-for="(value, index) in ['成功','失败']" :key='index' :value='value' :label=value>
                    {{ value }}
                  </a-select-option>
                </a-select>
              </a-form-item>
            </a-col>
          </a-row>

          <a-row>
            <a-col :md='8' :sm='8'>
              <a-form-item label='操作时间'>
                <a-range-picker
                  :ranges="{ Today: [moment(), moment()], 'This Month': [moment(), moment().endOf('month')] }"
                  v-model='dateIntervalMoment'
                  @change='showChange()'
                  allowClear
                  format='YYYY-MM-DD'>
                  <template slot='dateRender' slot-scope='current'>
                    <div class='ant-calendar-date' :style='getCurrentStyle(current)'>
                      {{ current.date() }}
                    </div>
                  </template>
                </a-range-picker>
              </a-form-item>
            </a-col>

            <a-col :md='8' :sm='8'>
              <a-button type='primary' style='margin-left:6px' @click='$refs.table.refresh(true)'>查询</a-button>
              <a-button style='margin-left: 8px'
                        @click='() => (this.queryParam = {},this.dateIntervalMoment=[],$refs.table.refresh(true))'>重置
              </a-button>
            </a-col>
          </a-row>

          <a-row style='margin-bottom: 20px'>

            <a-popconfirm
              ok-text='是的'
              cancel-text='不用了'
              @confirm='ConfirmDelete'
              @cancel='CancelDelete'>
              <template slot='title'>
                <p>此操作不可逆,确定要清空数据吗?</p>
                <p>删除日志编号为: {{ this.selectedDeleteOperId }}</p>
              </template>
              <a-button type='danger' icon='delete' v-if='selectedRowKeys.length>0'>删除</a-button>
            </a-popconfirm>

            <a-popconfirm
              ok-text='是的'
              cancel-text='不用了'
              @confirm='ConfirmDeleteAll'
              @cancel='CancelDeleteAll'>
              <template slot='title'>
                <p>此操作不可逆,确定要清空数据吗?</p>
              </template>
              <a-button icon='delete' style='margin:0 10px;background-color:#FFEDED;color:#FF4949'>清空</a-button>
            </a-popconfirm>

            <a-button type='dashed' icon='upload' @click='exportLogs'>导出</a-button>
          </a-row>

        </a-form>
      </div>

      <a-modal v-model='open' title='操作日志详细' width='700px'>
        <a-form :model='form' :label-col='{ span: 6 }' size='small'>
          <a-row>
            <a-col :span='12'>
              <a-form-item label='操作模块：' :label-width='labelWidth' label-align='left'>
                {{ form.title }} / {{ form.businessType }}
              </a-form-item>
              <a-form-item label='登录信息：' :label-width='labelWidth' label-align='left'>
                {{ form.operName }} / {{ form.operIp }}
              </a-form-item>
            </a-col>
            <a-col :span='12'>
              <a-form-item label='请求地址：' :label-width='labelWidth' label-align='left'>
                {{ form.operUrl }}
              </a-form-item>
              <a-form-item label='请求方式：' :label-width='labelWidth' label-align='left'>
                {{ form.requestMethod }}
              </a-form-item>
            </a-col>
          </a-row>
          <a-row>
            <a-col :span='24'>
              <a-form-item label='操作方法：' :label-width='labelWidth' label-align='left'>
                <span style='text-align: left'>{{ form.method }}</span>
              </a-form-item>
            </a-col>
          </a-row>
          <a-row>
            <a-col :span='24'>
              <a-form-item label='请求参数：' :label-width='labelWidth' label-align='left'>
                {{ form.operParam }}
              </a-form-item>
            </a-col>
            <a-col :span='24'>
              <a-form-item label='返回参数：' :label-width='labelWidth' label-align='left'>
                {{ form.jsonResult }}
              </a-form-item>
            </a-col>
            <a-col :span='12'>
              <a-form-item label='操作状态：' :label-width='labelWidth' label-align='left'>
                <div v-if='form.status === 0'>正常</div>
                <div v-else-if='form.status === 1'>失败</div>
              </a-form-item>
            </a-col>
            <a-col :span='12'>
              <a-form-item label='操作时间：' :label-width='labelWidth' label-align='left'>
                {{ form.operTime }}
              </a-form-item>
            </a-col>
            <a-col :span='24'>
              <a-form-item label='异常信息：' v-if='form.status === 1' :label-width='labelWidth' label-align='left'>
                {{ form.errorMsg }}
              </a-form-item>
            </a-col>
          </a-row>
        </a-form>
        <div slot='footer'>
          <a-button @click='open = false'>关 闭</a-button>
        </div>
      </a-modal>



      <s-table
        ref='table'
        size='default'
        rowKey='operId'
        :columns='columns'
        :data='loadData'
        :alert='true'
        :rowSelection='rowSelection'
        showPagination='auto'
      >

        <span slot='businessType' slot-scope='text'>
      <a-tag :color='getBusinessTypeColor(text)'>
        {{ text }}
      </a-tag>
    </span>
        <span slot='status' slot-scope='text'>
      <a-tag :color="text=== 0 ? 'blue':'red'">
        {{ text === 1 ? '失败' : '成功' }}
        </a-tag>
    </span>
        <span slot='action' slot-scope='text, record'>
     <a @click='handleDetail(record)'>
           <a-icon type='eye' />详细
            </a>
    </span>

      </s-table>
    </a-card>
  </page-header-wrapper>
</template>

<script>
import moment from 'moment'
import { getPageLogsList, updateLogsDeleteByOperId, updateLogsDeleteAll, api } from '@/api/logs'
import notification from 'ant-design-vue/lib/notification'
import request from '@/utils/request'
import { STable } from '@/components'
import { updateUserIsDeleteById } from '@/api/manage'
import storage from 'store'
import { ACCESS_TOKEN } from '@/store/mutation-types'

const columns = [
  {
    title: '日志编号',
    width: 130,
    align: 'center',
    dataIndex: 'operId'
  },
  {
    title: '系统模块',
    dataIndex: 'title'
  },
  {
    title: '操作类型',
    dataIndex: 'businessType',
    width: 90,
    scopedSlots: { customRender: 'businessType' }
  },
  {
    title: '请求方式',
    width: 90,
    align: 'center',
    dataIndex: 'requestMethod'
  },
  {
    title: '操作人员',
    dataIndex: 'operName'
  },
  {
    title: '操作地址',
    dataIndex: 'operIp'
  },
  {
    title: '操作状态',
    dataIndex: 'status',
    scopedSlots: { customRender: 'status' }
  },
  {
    title: '操作日期',
    dataIndex: 'operTime',
    width: 180,
    sorter: true,
    align: 'center'
  },
  {
    title: '操作',
    dataIndex: 'action',
    width: '150px',
    scopedSlots: { customRender: 'action' }
  }
]

export default {
  name: 'Logs',
  components: {
    STable
  },

  data() {
    this.columns = columns
    return {
      open: false,
      form: {},
      labelWidth: '100px', // 你可以根据需要调整宽度
      businessType: [
        { value: '新增', label: '新增' },
        { value: '修改', label: '修改' },
        { value: '删除', label: '删除' },
        { value: '锁定', label: '锁定' },
        { value: '登录', label: '登录' },
        { value: '导入', label: '导入' },
        { value: '强退', label: '强退' }
        // 添加其他操作类型
      ],
      // create model
      visible: false,
      confirmLoading: false,
      mdl: null,
      // 高级搜索 展开/关闭
      advanced: false,
      // 查询参数
      dateIntervalMoment: [], // 开始日期和结束日期
      queryParam: {
        title: undefined,
        operName: undefined,
        businessType: undefined,
        status: undefined,
        startOperTime: undefined,
        stopOperTime: undefined
        // sortField: 'oper_time', // 默认的排序字段
        // sortOrder: 'descend' // 默认的排序方式
      },
      selectedDeleteOperId: [],
      dropdownVisible: false, // 下拉框菜单的收起与展开
      deleteFlag: false,
      restoreFlag: false,
      lockFlag: false,
      unlockFlag: false,
      popConfirm: false,
      popText: '', // 气泡对话框显示内容

      loadData: (parameter) => {
        console.log('参数: ', parameter)
        this.verifyDate()
        const requestParameters = Object.assign({}, parameter, this.queryParam)
        console.log('loadData request parameters:', requestParameters)

        return new Promise((resolve, reject) => {
          getPageLogsList(requestParameters)
            .then((res) => {
              console.log('日志表格数据: ', res)
              resolve(res.data)
            })
            .catch((error) => {
              console.error('Error fetching data:', error)
              reject(error)
            })
        })
      },

      selectedRowKeys: [],
      selectedRows: []
    }
  },
  created() {
  },
  computed: {
    rowSelection() {
      return {
        selectedRowKeys: this.selectedRowKeys,
        onChange: this.onSelectChange
      }
    }
  },
  methods: {
    moment,
    getBusinessTypeColor(value) {
      // 根据操作类型返回相应的颜色
      switch (value) {
        case '新增':
        case '修改':
          return 'purple' // 设置新增操作类型的颜色
        case '删除':
        case '删除多行':
          return 'red'
        case '导出':
        case '导入':
          return 'orange'
        case '登录':
        case '注册':
          return 'green'
        default:
          return 'cyan' // 默认颜色
      }
    },
    // 点击详细
    handleDetail(record) {
      console.log('单条详细日志: ', record)
      this.form = { ...record }
      this.open = true
    },
    verifyDate() {
      if (this.dateIntervalMoment[0] && this.dateIntervalMoment[0].isValid() && this.dateIntervalMoment[1] && this.dateIntervalMoment[1].isValid()) {
        this.queryParam.startOperTime = this.dateIntervalMoment[0].format('YYYY-MM-DD')
        this.queryParam.stopOperTime = this.dateIntervalMoment[1].format('YYYY-MM-DD')
      } else {
        this.queryParam.startOperTime = ''
        this.queryParam.stopOperTime = ''
      }
    },

    ConfirmDeleteAll() {
      console.log('删除数据库中所有的日志,软删除')
      updateLogsDeleteAll().then(res => {
        if (res.code === '200') {
          this.$message.success('删除成功')
          this.$refs.table.refresh()
        } else {
          this.$message.error('删除失败')
        }
      })
    },
    CancelDeleteAll() {
    },

    ConfirmDelete() {
      const id = this.selectedRows.map(row => row.operId)
      updateLogsDeleteByOperId({ operId: id }).then(res => {
        if (res.code === '200') {
          this.$message.success('删除成功')
          this.$refs.table.clearSelected()
          this.$refs.table.refresh()
        } else {
          this.$message.error('删除失败')
        }
      })
    },
    CancelDelete() {

    },
    getCurrentStyle(current, today) {
      const style = {}
      if (current.date() === 1) {
        style.border = '1px solid #1890ff'
        style.borderRadius = '50%'
      }
      return style
    },

    importUser() {
      // 触发文件输入元素点击事件
      this.$refs.fileInput.click()
    }
    ,
    handleFileChange(event) {
      // 处理文件选择的逻辑
      const file = event.target.files[0]
      if (file) {
        // 执行文件上传或解析逻辑
        this.uploadFile(file)
      }
    }
    ,
    uploadFile(file) {
      const formData = new FormData()
      formData.append('file', file)
      console.log('当前文件: ', file)
      importExcel(formData).then(res => {
        if (res.code === '200') {
          notification.success({
            message: '操作提示',
            description: '导入成功!'
          })
          // 刷新表格
          this.$refs.table.refresh()
        } else {
          notification.error({
            message: '操作提示',
            description: '导入失败!'
          })
        }
        // 清空文件输入元素的值
        this.$refs.fileInput.value = null
      })
    }
    ,
    // ...
    // 导出excel表,如果当前没有数据,就不导出
    exportLogs() {
      getPageLogsList(this.queryParam)
        .then((res) => {
          if (res.data.records.length > 0) {
            const token = storage.get(ACCESS_TOKEN)
            // const url = request.defaults.baseURL + api.exportUrl + '?Access-Token=' + token
            const url = request.defaults.baseURL + api.exportUrl + '?' + ACCESS_TOKEN + '=' + token
            window.open(url)
          } else {
            this.$message.error('当前没有需要导出的数据')
          }
        })
        .catch((error) => {
          console.error('Error fetching data:', error)
        })
    }
    ,
    handleAdd() {
      // this.mdl = null
      // this.visible = true
      this.$router.push({ name: 'userAdminAddUser' })
    }
    ,
    handleEdit(record) {
      console.log(record)
      // this.visible = true
      // this.mdl = { ...record }
      this.$router.push({ name: 'userAdminEditUser', params: { oneUserInfo: record.id } })
      // this.$router.push({ name: 'userAdminEditUser', params: { oneUserInfo: JSON.stringify(record) } })
    }
    ,
    // 删除
    handleDel(record) {
      let selectIdArr = []
      if (!isNaN(record.id)) {
        selectIdArr = [parseInt(record.id)]
      } else {
        selectIdArr = []
      }
      updateUserIsDeleteById({ ids: selectIdArr, extraParam: 1 }).then(res => {
        if (res.code === '200') {
          notification.success({
            message: '操作提示',
            description: '删除成功!'
          })
          // 刷新表格
          this.$refs.table.refresh()
        } else {
          notification.error({
            message: '操作提示',
            description: '删除失败!'
          })
        }
      })
    }
    ,
    handleOk() {
      const form = this.$refs.createModal.form
      this.confirmLoading = true
      form.validateFields((errors, values) => {
        if (!errors) {
          console.log('values', values)
          if (values.id > 0) {
            // 修改 e.g.
            new Promise((resolve, reject) => {
              setTimeout(() => {
                resolve()
              }, 1000)
            }).then((res) => {
              this.visible = false
              this.confirmLoading = false
              // 重置表单数据
              form.resetFields()
              // 刷新表格
              this.$refs.table.refresh()

              this.$message.info('修改成功')
            })
          } else {
            // 新增
            new Promise((resolve, reject) => {
              setTimeout(() => {
                resolve()
              }, 1000)
            }).then((res) => {
              this.visible = false
              this.confirmLoading = false
              // 重置表单数据
              form.resetFields()
              // 刷新表格
              this.$refs.table.refresh()

              this.$message.info('新增成功')
            })
          }
        } else {
          this.confirmLoading = false
        }
      })
    }
    ,
    handleCancel() {
      this.visible = false

      const form = this.$refs.createModal.form
      form.resetFields() // 清理表单数据（可不做）
    }
    ,
    handleSub(record) {
      if (record.status !== 0) {
        this.$message.info(`${record.no} 订阅成功`)
      } else {
        this.$message.error(`${record.no} 订阅失败，规则已关闭`)
      }
    },
    onSelectChange(selectedRowKeys, selectedRows) {
      this.selectedRowKeys = []
      this.selectedRows = []
      this.selectedRowKeys = selectedRowKeys
      this.selectedRows = selectedRows
      this.selectedDeleteOperId = this.selectedRows.map(row => row.operId)
      console.log('onSelectChange: 执行了')
    },
    toggleAdvanced() {
      this.advanced = !this.advanced
    }
    ,
    resetSearchForm() {
      this.queryParam = {
        date: moment(new Date())
      }
    }
    ,
    // 昵称 输入框内容变化时的回调
    showChange() {
      this.$refs.table.refresh(true)
    }
  }
}
</script>
<style scoped>
.ant-tag {
  height: 28px;
  line-height: 26px;
}

</style>
