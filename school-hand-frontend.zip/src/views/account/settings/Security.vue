<template>
  <div>
    <div>
      <a-list itemLayout="horizontal" :dataSource="computedData">
        <a-list-item slot="renderItem" slot-scope="item, index" :key="index">
          <a-list-item-meta>
            <a slot="title">{{ item.title }}</a>
            <span slot="description">
              <span class="security-list-description">{{ item.description }}</span>
              <span v-if="item.value"></span>
              <span class="security-list-value">{{ item.value }}</span>
            </span>
          </a-list-item-meta>
          <template v-if="item.actions">
            <a slot="actions" @click="item.actions.callback">{{ item.actions.title }}</a>
          </template>
        </a-list-item>
      </a-list>
    </div>

    <div>
      <!-- 重置密码对话框 -->
      <reset-pwd ref="refResetPwd" @notify="show"></reset-pwd>
    </div>

    <!-- 密保手机 -->
    <div>
      <reset-phone ref="refResetPhone" @notify="showNewPhone"></reset-phone>
    </div>

    <!-- QQ邮箱 -->
    <div>
      <reset-email ref="refResetEmail" @notify="showNewEmail"></reset-email>
    </div>
  </div>
</template>

<script>
import ResetPwd from './ResetPwd'
import ResetPhone from './ResetPhone'
import ResetEmail from './ResetEmail'

import USER from '@/api/user'

export default {
  components: {
    ResetPwd,
    ResetPhone,
    ResetEmail,
  },
  data() {
    return {
      currentUser: '',
      pwdState: '',
      newPhone: '',
      newEmail: '',
      userInfo: {},
    }
  },
  mounted() {
    this.getCurrentLoginUserInfo() // 获取当前登录的用户信息
    this.pwdState = this.$cookie.get('pwdState') // 获取密码强度
    // (this.newPhone = this.$cookie.get('newPhone')) // 新的手机号
    // 也可以在注册页面的时候就设置这个手机号通过cookies
  },
  computed: {
    computedData() {
      return [
        {
          // 账号密码
          title: this.$t('account.settings.security.password'),
          // description: this.$t('account.settings.security.password-description'),
          description: '当前密码',
          // value: '强',
          value: this.$t(this.pwdState),
          // value:this.$t('user.password.strength.short'),
          actions: {
            title: this.$t('account.settings.security.modify'),
            callback: () => {
              this.$refs.refResetPwd.showModal(this.currentUser) //传递登录的用户账号或者手机号
              // 第一步从cookies中获取user,然后传递当前账号,之后都是都是第一步来获取的，所以
              // 必须从第一步开始
            },
          },
        },
        {
          title: this.$t('account.settings.security.phone'),
          description: this.$t('account.settings.security.phone-description'),
          value: this.newPhone,
          actions: {
            title: this.$t('account.settings.security.modify'),
            callback: () => {
              // console.log('重置手机号回调: ',this.userInfo)
              this.$refs.refResetPhone.showModal(this.userInfo.phone, this.userInfo.username) // 显示重置手机号对话框
            },
          },
        },
        // 密保问题
        // {
        //   title: this.$t('account.settings.security.question'),
        //   description: this.$t('account.settings.security.question-description'),
        //   value: '',
        //   actions: {
        //     title: this.$t('account.settings.security.set'),
        //     callback: () => {
        //       this.$message.error('This is a message of error')
        //     },
        //   },
        // },
        {
          // title: this.$t('account.settings.security.email'),
          title: 'QQ邮箱',
          description: this.$t('account.settings.security.email-description'),
          value: this.newEmail,
          actions: {
            title: this.$t('account.settings.security.modify'),
            callback: () => {
              this.newEmail
              // this.$refs.refResetEmail.showModal(this.userInfo.email, this.userInfo.username)
              this.$refs.refResetEmail.showModal(this.newEmail, this.userInfo.username)

              // this.$message.warning('This is message of warning')
            },
          },
        },
        // {
        //   title: this.$t('account.settings.security.mfa'),
        //   description: this.$t('account.settings.security.mfa-description'),
        //   value: '',
        //   actions: {
        //     title: this.$t('account.settings.security.bind'),
        //     callback: () => {
        //       this.$message.info('This is a normal message')
        //     },
        //   },
        // },
      ]
    },
  },
  methods: {
    getCurrentLoginUserInfo() {
      this.currentUser = this.$cookie.get('user') // 手机号或者账号
      USER.getCurrentUser(this.currentUser)
        .then((res) => {
          if (res.code === '200') {
            // setTimeout(() => {
            this.userInfo = res.data
            // console.log('当前用户信息: ', res)
            this.getMaskPhone(res.data.phone)
            this.formatEmail(res.data.email)
            // }, 1500)
          } else {
            this.$notification.error({
              message: '错误',
              description: res.msg,
            })
          }
        })
        .catch((err) => err)
    },
    show(message) {
      // console.log('更新啦: ', message)
      this.pwdState = this.$cookie.get('pwdState') // 获取密码强度
    },
    showNewPhone(phone) {
      // console.log('更新啦: ', phone)
      this.newPhone = this.$cookie.get('newPhone') // 新的手机号
    },
    showNewEmail(email) {
      // console.log('更新啦: ', email)
      this.newEmail = this.$cookie.get('newEmail') // 新的手机号
    },

    getMaskPhone(phone) {
      if (phone === undefined || typeof phone !== 'string') {
        console.error('Invalid phone number provided')
        return
      }
      const _phone = phone.toString()
      this.newPhone = _phone.substr(0, 3) + '****' + _phone.substr(7)
      // console.log('当前手机号: ', this.newPhone)
    },

    formatEmail(email) {
      const prefix = email.slice(0, 3) // 提取前缀
      const suffix = email.slice(email.indexOf('@') + 1) // 提取后缀
      // const domain = suffix.slice(0, suffix.indexOf('.')) // 提取域名部分（例如 'qq'）
      const hiddenPart = '****' // 中间隐藏部分

      // 创建新的格式化邮箱地址  306****@qq.com
      const formattedEmail = prefix + hiddenPart + '@' + suffix
      this.newEmail = formattedEmail
    },
  },
}
</script>

<style scoped>
</style>
