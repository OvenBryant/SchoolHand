<template>
  <a-modal
    title='修改头像'
    :visible='visible'
    :maskClosable='false'
    :confirmLoading='confirmLoading'
    :width='800'
    :footer='null'
    @cancel='cancelHandel'
  >
    <a-row>
      <a-col :xs='24' :md='12' :style="{ height: '350px' }">
        <vue-cropper
          ref='cropper'
          :img='options.img'
          :info='true'
          :autoCrop='options.autoCrop'
          :autoCropWidth='options.autoCropWidth'
          :autoCropHeight='options.autoCropHeight'
          :fixedBox='options.fixedBox'
          @realTime='realTime'
        >
        </vue-cropper>
      </a-col>
      <a-col :xs='24' :md='12' :style="{ height: '350px' }">
        <div class='avatar-upload-preview'>
          <img :src='previews.url' :style='previews.img' />
        </div>
      </a-col>
    </a-row>
    <br />
    <a-row>
      <a-col :lg='2' :md='2'>
        <a-upload name='file' :beforeUpload='beforeUpload' :showUploadList='false'>
          <a-button icon='upload'>选择图片</a-button>
        </a-upload>
      </a-col>
      <a-col :lg='{ span: 1, offset: 2 }' :md='2'>
        <a-button icon='plus' @click='changeScale(1)' />
      </a-col>
      <a-col :lg='{ span: 1, offset: 1 }' :md='2'>
        <a-button icon='minus' @click='changeScale(-1)' />
      </a-col>
      <a-col :lg='{ span: 1, offset: 1 }' :md='2'>
        <a-button icon='undo' @click='rotateLeft' />
      </a-col>
      <a-col :lg='{ span: 1, offset: 1 }' :md='2'>
        <a-button icon='redo' @click='rotateRight' />
      </a-col>
      <a-col :lg='{ span: 2, offset: 6 }' :md='2'>
        <a-button type='primary' @click='finish'>保存</a-button>
      </a-col>
    </a-row>
  </a-modal>

</template>
<script>
import { updateImg } from '@/api/personal'

export default {
  data() {
    return {
      visible: false,
      id: null,
      confirmLoading: false,
      fileList: [],
      uploading: false,
      options: {
        // img: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
        img: '',
        autoCrop: true,
        autoCropWidth: 200,
        autoCropHeight: 200,
        fixedBox: true
      },
      previews: {},
      imgFileValue: '', // 当前图片文件
      caijianImg: ''

    }
  },
  mounted() {
  },
  methods: {

    // 打开上传图片窗口
    edit(id) {
      console.log('随机数: ', id)
      this.visible = true
      this.id = id
      /* 获取原始头像 */
    },
    close() {
      this.id = null
      this.visible = false
    },
    cancelHandel(e) {
      this.close()
    },
    changeScale(num) {
      num = num || 1
      this.$refs.cropper.changeScale(num)
    },
    rotateLeft() {
      this.$refs.cropper.rotateLeft()
    },
    rotateRight() {
      this.$refs.cropper.rotateRight()
    },

    // 选择图片
    beforeUpload(file) {
      this.imgFileValue = file
      console.log('beforeUpload文件: ', file)
      const reader = new FileReader()
      // 把Array Buffer转化为blob 如果是base64不需要
      // 转化为base64
      reader.readAsDataURL(file)
      reader.onload = () => {
        this.options.img = reader.result
      }
      // 转化为blob
      // reader.readAsArrayBuffer(file)

      return false
    },
    // 将 base64 转换为 Blob 对象的函数
    // 将 base64 转换为 Blob 对象的函数
    dataURLtoBlob(dataURL) {
      const arr = dataURL.split(',')
      const mime = arr[0].match(/:(.*?);/)[1]
      const bstr = atob(arr[1])
      let n = bstr.length
      let u8arr = new Uint8Array(n)
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n)
      }
      return new Blob([u8arr], { type: mime })
    },

    // 确定上传图片(保存按钮)
    finish() {
      if (this.imgFileValue) {
        // 裁剪图片的base64
        this.$refs.cropper.getCropData((data) => {
          // 将 base64 转换为 Blob 对象
          const blob = this.dataURLtoBlob(data)

          // 创建 File 对象
          const file = new File([blob], 'show.png', { type: blob.type })

          let formData = new FormData()
          formData.append('file', file)
          updateImg(formData)
            .then((res) => {
              if (res.code === '200') {
                this.close()
                this.$emit('ok', res.data)
                this.$message.success('上传成功')
                console.log('上传图片url: ', res.data)
              }
            })
            .catch((err) => err)
        })
      } else {
        this.$message.error('当前头像未选择!')
      }
    },

    okHandel() {
      const vm = this
      vm.confirmLoading = true
      setTimeout(() => {
        vm.confirmLoading = false
        vm.close()
        vm.$message.success('上传头像成功')
      }, 2000)
    },

    realTime(data) {
      this.previews = data
    }
  }
}
</script>

<style lang='less' scoped>
.avatar-upload-preview {
  position: absolute;
  top: 50%;
  transform: translate(50%, -50%);
  width: 180px;
  height: 180px;
  border-radius: 50%;
  box-shadow: 0 0 4px #ccc;
  overflow: hidden;

  img {
    width: 100%;
    height: 100%;
  }
}
</style>
