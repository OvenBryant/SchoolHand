<template>
  <a-modal
    v-model="visible"
    title="重置密码"
    @ok="handleOk"
    @cancel="handleCancel"
    @visible-change="handleVisibleChange"
    :footer="[
      {
        text: '确定',
        onOk: handleOk,
      },
      {
        text: '关闭',
        onCancel: handleCancel,
      },
    ]"
    :closable="false"
    :draggable="true"
    :mask-closable="false"
  >
    <a-form :form="form" ref="resetForm">
      <a-form-item label="登录名称" prop="username" :rules="[ { required: true, message: '请输入登录名称', trigger: 'blur' } ]">
        <a-input v-model="formData.username" />
      </a-form-item>
      <a-form-item label="旧密码" prop="oldPassword" :rules="[ { required: true, message: '请输入旧密码', trigger: 'blur' } ]">
        <a-input type="password" v-model="formData.oldPassword" />
      </a-form-item>
      <a-form-item label="新密码" prop="newPassword" :rules="[ { required: true, message: '请输入新密码', trigger: 'blur' } ]">
        <a-input type="password" v-model="formData.newPassword" />
      </a-form-item>
      <a-form-item label="确认密码" prop="confirmPassword" :rules="[ { required: true, message: '请确认新密码', trigger: 'blur' } ]">
        <a-input type="password" v-model="formData.confirmPassword" />
      </a-form-item>
    </a-form>
    <div slot="footer">
      <a-button key="back" @click="handleCancel">
        关闭
      </a-button>
      <a-button key="submit" type="primary" @click="handleOk">
        确定
      </a-button>
    </div>
  </a-modal>
</template>

<script>
import { Modal, Form, Input, Button } from 'ant-design-vue';

export default {
  components: {
    'a-modal': Modal,
    'a-form': Form,
    'a-form-item': Form.Item,
    'a-input': Input,
    'a-button': Button,
  },
  props: {
    visible: Boolean,
  },
  data() {
    return {
      form: this.$form.createForm(this),
      formData: {
        username: '',
        oldPassword: '',
        newPassword: '',
        confirmPassword: '',
      },
    };
  },
  methods: {
    handleOk() {
      alert('确定')
      this.form.validateFields((err, values) => {
        if (!err) {
          // 处理确定按钮点击事件
          console.log('确定按钮点击');
          // 在这里可以发送重置密码的请求等操作
        }
      });
    },
    handleCancel() {
      // 处理关闭按钮点击事件
      console.log('关闭按钮点击');
    },
    handleVisibleChange(visible) {
      if (!visible) {
        // 处理对话框关闭时的事件
        console.log('对话框关闭');
        // 清空表单数据
        this.form.resetFields();
      }
    },
  },
};
</script>

<style scoped>
/* 这里可以添加样式 */
</style>
