<template>
  <div>
    <a-modal title="重置手机号" :visible="visible" :maskClosable="false" style="width: 1300px" @cancel="handleCancel">
      <template slot="footer">
        <a-button @click="handleCancel">关闭</a-button>
      </template>

      <a-spin :spinning="isSpinning" size="large" tip="正在更新手机号...">
        <div>
          <a-steps progress-dot :current="currentStep">
            <a-step title="第一步" description="验证手机号" />
            <a-step title="第二步" description="新的手机号" />
            <a-step title="第三步" description="完成" />
          </a-steps>
        </div>

        <!-- 第一步 -->
        <div v-if="currentStep === 0" style="margin-top: 20px">
          <p style="color: black">手机号码验证</p>
          <p style="color: black">
            请填写完整的手机号 <span style="color: red">{{ currentPhone }}</span> 以验证身份
          </p>
          <a-form :form="firstForm">
            <a-form-item>
              <a-input
                size="large"
                style="width: 300px; border: none; background-color: #faf6f5"
                placeholder="请输入完整的手机号"
                v-decorator="[
                  'phone',
                  {
                    rules: [
                      { required: true, message: '', pattern: /^1[3456789]\d{9}$/ },
                      { validator: this.handlePhoneCheck },
                    ],
                    validateTrigger: ['change', 'blur'],
                  },
                ]"
              >
                <a-select slot="addonBefore" size="large" defaultValue="+86">
                  <a-select-option value="+86">+86</a-select-option>
                  <a-select-option value="+87">+87</a-select-option>
                </a-select>
              </a-input>
            </a-form-item>
            <a-form-item>
              <div style="display: flex; align-items: center">
                <a-input
                  size="large"
                  v-model="firstStepCaptcha"
                  style="width: 200px; border: none; background-color: #faf6f5; margin-right: 8px"
                  placeholder="请输入短信验证码"
                ></a-input>
                <a-button @click="firstSendCode" :style="firstBtnSendCodeColor" :disabled="isDisabledFirstSendCode">{{
                  firstBtnSendCode
                }}</a-button>
              </div>
            </a-form-item>
            <a-form-item>
              <a-button type="primary" @click="firstBtnNextStep" style="width: 180px; border-radius: 10px"
                >下一步</a-button
              >
            </a-form-item>
          </a-form>
        </div>

        <!-- 第二步 -->

        <div v-if="currentStep === 1" style="margin-top: 20px">
          <div>
            <p style="color: black">新的手机号</p>
            <a-form :form="twoForm">
              <a-form-item>
                <a-input
                  size="large"
                  style="width: 300px; border: none; background-color: #faf6f5"
                  placeholder="请输入新的手机号"
                  v-decorator="[
                    'phone2',
                    {
                      rules: [
                        { required: true, message: '', pattern: /^1[3456789]\d{9}$/ },
                        { validator: this.handlePhoneCheck2 },
                      ],
                      validateTrigger: ['change', 'blur'],
                    },
                  ]"
                >
                </a-input>
              </a-form-item>
              <a-form-item>
                <div style="display: flex; align-items: center">
                  <a-input
                    size="large"
                    style="width: 200px; border: none; background-color: #faf6f5; margin-right: 8px"
                    placeholder="请输入短信验证码"
                    v-model="twoStepCaptcha"
                  ></a-input>
                  <a-button @click="twoSendCode" :style="twoBtnSendCodeColor" :disabled="isDisabledTwoSendCode">{{
                    twoBtnSendCode
                  }}</a-button>
                </div>
              </a-form-item>
              <a-form-item>
                <a-button type="primary" @click="twoBtnNextStep" style="width: 180px; border-radius: 10px"
                  >下一步</a-button
                >
              </a-form-item>
            </a-form>
          </div>
        </div>

        <div v-if="currentStep === 2" style="margin-top: 20px">
          <a-result title="更换手机号完成">
            <template #icon>
              <a-icon type="smile" theme="twoTone" />
            </template>
          </a-result>
        </div>
      </a-spin>
    </a-modal>
  </div>
</template>
<script>
import USER from '@/api/user'
import { getSmsCaptchaOfRegister } from '@/api/register'

export default {
  data() {
    return {
      visible: false,
      confirmLoading: false,
      currentPhone: '',
      currentUsername: '',
      firstForm: this.$form.createForm(this),
      twoForm: this.$form.createForm(this),
      threeForm: this.$form.createForm(this),
      currentStep: 0, // 当前进度条为0
      firstStepCaptcha: '', // 第一步验证码
      twoStepCaptcha: '', // 第二步验证码
      stepStyle: {
        marginBottom: '60px',
        boxShadow: '0px -1px 0 0 #e8e8e8 inset',
      },
      firstBtnSendCodeColor: {
        border: 'none',
        color: '#69befe',
        fontSize: '18px',
      },
      firstBtnSendCodeColor3: {
        border: 'none',
        color: '#69befe',
        fontSize: '18px',
      },
      firstBtnSendCodeColor2: {
        border: 'none',
        color: '#D1D1D1',
        fontSize: '18px',
      },
      twoBtnSendCodeColor: {
        border: 'none',
        color: '#69befe',
        fontSize: '18px',
      },
      twoBtnSendCodeColor2: {
        border: 'none',
        color: '#D1D1D1',
        fontSize: '18px',
      },
      twoBtnSendCodeColor3: {
        border: 'none',
        color: '#69befe',
        fontSize: '18px',
      },

      countdown: 0, // 倒计时
      setIntervalIdTimer: 60, // 设置倒计时时间 60s
      intervalId: null,

      firstBtnSendCode: '发送验证码', // 第一步
      isDisabledFirstSendCode: false,
      firstPhoneState: false, // 手机号标志位,验证手机号是否正确，如果正确就可以点击验证码

      twoPhoneState: false,
      twoBtnSendCode: '发送验证码', // 第一步
      isDisabledTwoSendCode: false,

      firstStepOldPhone: '', // 第一步的手机号码
      isSpinning: false,
    }
  },
  methods: {
    // 打开重置手机号对话框
    showModal(_phone, _username) {
      this.visible = true
      this.firstForm.resetFields() // 清空表单数据
      this.firstStepCaptcha='',
      this.twoStepCaptcha = ''
      if (!_phone) {
        _phone = '1234567890X'
      }
      const phoneString = _phone.toString()
      // 它使用substr函数来截取手机号的前三位、中间四位和后四位，并将它们重新组合成一个新的字符串
      // 156****5919
      this.currentPhone = phoneString.substr(0, 3) + '****' + phoneString.substr(7)
      this.currentUsername = _username
    },
    // 第一步发送验证码
    firstSendCode() {
      if (this.firstPhoneState) {
        this.startCountDown(this.setIntervalIdTimer) // 开始倒计时
        this.getCaptcha() // 获取验证码
      } else {
        this.firstForm.validateFields(['phone'], (errors, values) => {
          if (errors) {
            // 处理验证失败的情况
            console.error('手机号验证失败', errors)
          } else {
            // 处理验证成功的情况
            console.log('手机号验证成功', values)
            // 执行发送验证码的逻辑或其他操作
          }
        })
      }
    },
    getCaptcha() {
      const hide = this.$message.loading('验证码发送中..', 0)
      getSmsCaptchaOfRegister(this.firstForm.getFieldValue('phone'))
        .then((res) => {
          console.log(res)
          setTimeout(hide, 2500)
          if (res.code === '200') {
            this.$notification['success']({
              message: '提示',
              description: '验证码获取成功，您的验证码为：' + res.data,
              duration: 8,
            })
          } else {
            this.$notification['error']({
              message: '提示',
              description: '验证码获取失败, ' + res.msg,
              duration: 8,
            })
          }
        })
        .catch((err) => {
          setTimeout(hide, 1)
        })
    },
    getCaptcha2() {
      const hide = this.$message.loading('验证码发送中..', 0)
      getSmsCaptchaOfRegister(this.twoForm.getFieldValue('phone2'))
        .then((res) => {
          console.log(res)
          setTimeout(hide, 2500)
          if (res.code === '200') {
            this.$notification['success']({
              message: '提示',
              description: '验证码获取成功，您的验证码为：' + res.data,
              duration: 8,
            })
          } else {
            this.$notification['error']({
              message: '提示',
              description: '验证码获取失败, ' + res.msg,
              duration: 8,
            })
          }
        })
        .catch((err) => {
          setTimeout(hide, 1)
        })
    },
    // 第二步发送验证码
    twoSendCode() {
      if (this.twoPhoneState) {
        // 流程就是这样子的,但是阿里云手机号登录验证,需要授权指定的手机号才能使用
        this.startCountDown2(this.setIntervalIdTimer) // 开始倒计时
        this.getCaptcha2() // 获取验证码
      } else {
        this.twoForm.validateFields(['phone2'], (errors, values) => {
          if (errors) {
            // 处理验证失败的情况
            console.error('手机号验证失败', errors)
          } else {
            // 处理验证成功的情况
            console.log('手机号验证成功', values)
            // 执行发送验证码的逻辑或其他操作
          }
        })
      }
    },

    // 倒计时
    startCountDown(duration) {
      this.countdown = duration
      this.intervalId = setInterval(() => {
        this.countdown--
        this.firstBtnSendCodeStyle('重新发送' + this.countdown + 's', this.firstBtnSendCodeColor2, true, false)
        if (this.countdown <= 0) {
          this.firstBtnSendCodeStyle('发送验证码', this.firstBtnSendCodeColor3, false, true)
        }
      }, 1000)
    },
    // 倒计时
    startCountDown2(duration) {
      this.countdown = duration
      this.intervalId = setInterval(() => {
        this.countdown--
        this.twoBtnSendCodeStyle('重新发送' + this.countdown + 's', this.twoBtnSendCodeColor2, true, false)
        if (this.countdown <= 0) {
          this.twoBtnSendCodeStyle('发送验证码', this.twoBtnSendCodeColor3, false, true)
        }
      }, 1000)
    },
    // 点击第一次的下一步按钮
    firstBtnNextStep() {
      // 主动取消定时器
      if(this.intervalId!=null){
        clearInterval(this.intervalId)
      }

      if (this.firstPhoneState) {
        if (!this.firstStepCaptcha) {
          this.$message.error('验证码不能为空')
          return
        }
        const _phone = this.firstForm.getFieldValue('phone')
        USER.VerifyPhoneFirstStepByUsername(this.currentUsername, _phone, this.firstStepCaptcha)
          .then((res) => {
            if (res.code === '200') {
              // 进度条+1
              // 1 验证当前手机号和验证码是否合法
              // 关闭定时器
              this.firstStepOldPhone = _phone
              this.currentStep = 1
              this.firstBtnSendCodeStyle('发送验证码', this.firstBtnSendCodeColor3, false, true)
            } else {
              this.$message.error(res.msg)
            }
          })
          .catch((err) => err)
      } else {
        this.firstForm.validateFields(['phone'], (errors, values) => {
          if (errors) {
            // 处理验证失败的情况
            console.error('手机号验证失败', errors)
          } else {
            // 处理验证成功的情况
            console.log('手机号验证成功', values)
            // 执行发送验证码的逻辑或其他操作
          }
        })
      }
    },
    // 点击第二次的下一步按钮
    // twoBtnNextStep() {
    //   this.isSpinning = true
    //   setTimeout(() => {
    //     this.isSpinning = false;
    //     this.currentStep = 2
    //   }, 2000)

    //   setTimeout(() => {
    //    this.visible = false
    //   }, 3000)
    // },
    twoBtnNextStep() {
      // 1 验证当前手机号和验证码是否合法
      // 2 进度条+1
      if (this.twoPhoneState) {
        if (!this.twoStepCaptcha) {
          this.$message.error('验证码不能为空')
          return
        }
        const _oldPhone = this.firstStepOldPhone
        const _newPhone = this.twoForm.getFieldValue('phone2')
        // 更新手机号
        USER.VerifyPhoneTwoStepByUsername(this.currentUsername, _oldPhone, _newPhone, this.twoStepCaptcha)
          .then((res) => {
            if (res.code === '200') {

              const newPhoneNotify = _newPhone.toString().substr(0,3)+"****"+_newPhone.toString().substr(7);
              this.$cookie.set('newPhone',newPhoneNotify);
              this.$emit('notify','手机号更新啦')

              this.isSpinning = true
              setTimeout(() => {
                this.isSpinning = false
                this.currentStep = 2
              }, 2000)
              setTimeout(() => {
                this.visible = false
                this.currentStep = 0;  // 步骤条置位0
              }, 3000)
              // setTimeout(() => {
              //   this.currentStep = 2
              //   this.twoBtnSendCodeStyle('发送验证码', this.twoBtnSendCodeColor3, false, true)
              //   this.visible = false
              // }, 4000)
            } else {
              this.$message.error(res.msg)
            }
          })
          .catch((err) => err)
      } else {
        this.twoForm.validateFields(['phone2'], (errors, values) => {
          if (errors) {
            // 处理验证失败的情况
            console.error('手机号验证失败', errors)
          } else {
            // 处理验证成功的情况
            console.log('手机号验证成功', values)
            // 执行发送验证码的逻辑或其他操作
          }
        })
      }
    },

    /** 第一次 发送验证码按钮
     * _text 显示文本
     * _style 发送验证码按钮显示样式
     * _isDisabled 按钮是否可点击
     * _isInterval 定时器是否可用
     */
    firstBtnSendCodeStyle(_text, _style, _isDisabled, _isInterval) {
      if (_isInterval) {            
        clearInterval(this.intervalId)
        this.intervalId = null;
      }
      this.firstBtnSendCode = _text
      ;(this.firstBtnSendCodeColor = _style), (this.isDisabledFirstSendCode = _isDisabled)
    },
    twoBtnSendCodeStyle(_text, _style, _isDisabled, _isInterval) {
      if (_isInterval) {
        clearInterval(this.intervalId)
        this.intervalId = null;
      }
      this.twoBtnSendCode = _text
      ;(this.twoBtnSendCodeColor = _style), (this.isDisabledTwoSendCode = _isDisabled)
    },

    handleOk(e) {
      this.confirmLoading = true
      setTimeout(() => {
        this.visible = false
        this.confirmLoading = false
      }, 2000)
    },
    handleCancel(e) {
      this.visible = false
    },
    handlePhoneCheck(rule, value, callback) {
      if (!/^1[3456789]\d{9}$/.test(value)) {
        callback(new Error('请输入正确的手机号码'))
      } else {
        this.validCurrentPhone(rule, value, callback)
      }
    },
    handlePhoneCheck2(rule, value, callback) {
      if (!/^1[3456789]\d{9}$/.test(value)) {
        callback(new Error('请输入正确的手机号码'))
      } else {
        this.validCurrentPhone2(rule, value, callback)
      }
    },
    validCurrentPhone(rule, value, callback) {
      const inputPhone = this.firstForm.getFieldValue('phone')
      USER.validCurrentPhoneByUsername(this.currentUsername, inputPhone)
        .then((res) => {
          if (res.code === '200') {
            this.firstPhoneState = true // 验证手机号标志位
            callback()
          } else {
            this.firstPhoneState = false // 验证手机号标志位
            callback(new Error('手机号验证错误,请重试'))
          }
        })
        .catch((err) => {
          this.firstPhoneState = false // 验证手机号标志位
          console.log('请求失败: ', err)
        })
    },

    // 第二步验证手机号的时候,是新的手机号,只需要校验新的手机号是否正确就行
    validCurrentPhone2(rule, value, callback) {
      const _oldPhone = this.firstStepOldPhone
      // const inputPhone = this.twoForm.getFieldValue('phone2')
      // 验证第一步手机号
      USER.validCurrentPhoneByUsername(this.currentUsername, _oldPhone)
        .then((res) => {
          if (res.code === '200') {
            this.twoPhoneState = true // 验证手机号标志位
            callback()
          } else {
            this.twoPhoneState = false // 验证手机号标志位
            callback(new Error('请完成第一步手机号验证'))
          }
        })
        .catch((err) => {
          this.twoPhoneState = false // 验证手机号标志位
          console.log('请求失败: ', err)
        }).finally(s=>{
           console.log('第二步手机号状态: ',this.twoPhoneState)
        })
    },
  },
}
</script>
<style scoped>
</style>
