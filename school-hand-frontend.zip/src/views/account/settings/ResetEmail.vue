<template>
  <div>
    <a-modal
      title="重置QQ邮箱"
      :visible="visible"
      :maskClosable="false"
      style="width: 1300px"
      @cancel="handleCancel"
      @ok="handleOk"
    >
      <div style="margin-top: 20px">
        <p style="color: black">QQ邮箱验证</p>
        <p style="color: black">
          请填写完整的QQ邮箱 <span style="color: red">{{ currentEmail }}</span> 以验证身份
        </p>
        <a-form :form="form">
          <a-form-item>
            <a-input
              size="large"
              style="width: 300px; border: none; background-color: #faf6f5"
              placeholder="请输入完整的QQ邮箱"
              v-decorator="[
                'email',
                {
                  rules: [
                    { required: true, message: '', pattern: /^[a-zA-Z0-9_-]+@qq.com$/ },
                    { validator: this.handleEmailCheck },
                  ],
                  validateTrigger: ['change', 'blur'],
                },
              ]"
            >
            </a-input>
          </a-form-item>
          <a-form-item>
            <div style="display: flex; align-items: center">
              <a-input
                size="large"
                v-model="QQEmailCaptcha"
                style="width: 200px; border: none; background-color: #faf6f5; margin-right: 8px"
                placeholder="请输入QQ邮箱验证码"
              ></a-input>
              <a-button @click="firstSendCode" :style="firstBtnSendCodeColor" :disabled="isDisabledFirstSendCode">{{
                firstBtnSendCode
              }}</a-button>
            </div>
          </a-form-item>
          <a-form-item>
            <a-input
              size="large"
              style="width: 300px; border: none; background-color: #faf6f5"
              placeholder="请输入需要更改的QQ邮箱"
              v-decorator="[
                'newEmail',
                {
                  rules: [
                    { required: true, message: '', pattern: /^[a-zA-Z0-9_-]+@qq.com$/ },
                    { validator: this.handleNewEmailCheck },
                  ],
                  validateTrigger: ['change', 'blur'],
                },
              ]"
            >
            </a-input>
          </a-form-item>
        </a-form>
      </div>
    </a-modal>
  </div>
</template>
<script>
import USER from '@/api/user'

export default {
  data() {
    return {
      visible: false,
      confirmLoading: false,
      currentEmail: '',
      QQEmailCaptcha: '',
      currentUsername: '',
      form: this.$form.createForm(this),
      firstStepCaptcha: '', // 第一步验证码
      stepStyle: {
        marginBottom: '60px',
        boxShadow: '0px -1px 0 0 #e8e8e8 inset',
      },
      firstBtnSendCodeColor: {
        border: 'none',
        color: '#69befe',
        fontSize: '18px',
      },
      firstBtnSendCodeColor3: {
        border: 'none',
        color: '#69befe',
        fontSize: '18px',
      },
      firstBtnSendCodeColor2: {
        border: 'none',
        color: '#D1D1D1',
        fontSize: '18px',
      },

      countdown: 0, // 倒计时
      setIntervalIdTimer: 60, // 设置倒计时时间 60s
      intervalId: null,

      firstBtnSendCode: '发送验证码', // 第一步
      isDisabledFirstSendCode: false,
      ValidQQEmailState: false, // 手机号标志位,验证手机号是否正确，如果正确就可以点击验证码
      ValidNewQQEmailState: false,
    }
  },
  methods: {
    // 打开重置手机号对话框
    showModal(email, _username) {
      this.visible = true
      this.form.resetFields() // 清空表单数据
      this.QQEmailCaptcha = ''
       this.firstBtnSendCodeStyle('发送验证码', this.firstBtnSendCodeColor3, false, true)

      this.currentEmail = this.formatEmail(email)
      // this.currentEmail = this.formatEmail(email)
      this.currentUsername = _username
    },
    formatEmail(email) {
      const prefix = email.slice(0, 3) // 提取前缀
      const suffix = email.slice(email.indexOf('@') + 1) // 提取后缀
      // const domain = suffix.slice(0, suffix.indexOf('.')) // 提取域名部分（例如 'qq'）
      const hiddenPart = '****' // 中间隐藏部分

      // 创建新的格式化邮箱地址  306****@qq.com
      const formattedEmail = prefix + hiddenPart + '@'+suffix

      return formattedEmail // 返回格式化后的邮箱地址
    },
    // 第一步发送验证码
    firstSendCode() {
      // this.ValidQQEmailState 表示当前邮箱是正确的
      if (this.ValidQQEmailState) {
        this.startCountDown(this.setIntervalIdTimer) // 开始倒计时
        this.getCaptcha() // 获取验证码
      } else {
        this.form.validateFields(['email'], (errors, values) => {
          if (errors) {
            // 处理验证失败的情况
            // console.error('QQ邮箱验证失败', errors)
          } else {
            // 处理验证成功的情况
            // console.log('QQ邮箱验证成功', values)
            // 执行发送验证码的逻辑或其他操作
          }
        })
      }
    },
    getCaptcha() {
      const hide = this.$message.loading('验证码发送中..', 0)
      // 可以传递账号,账号和邮箱校验一下，也可以不传递账号，因为验证邮箱的时候，已经校验过了
      USER.getQQEmailCaptcha(this.form.getFieldValue('email'))
        .then((res) => {
          setTimeout(hide, 2500)
          if (res.code === '200') {
            this.$notification['success']({
              message: '提示',
              description: '验证码获取成功，您的验证码为：' + res.data,
              duration: 8,
            })
          } else {
            this.$notification['error']({
              message: '提示',
              description: '验证码获取失败, ' + res.msg,
              duration: 8,
            })
          }
        })
        .catch((err) => {
          setTimeout(hide, 1)
        })
    },

    // 倒计时
    startCountDown(duration) {
      this.countdown = duration
      this.intervalId = setInterval(() => {
        this.countdown--
        this.firstBtnSendCodeStyle('重新发送' + this.countdown + 's', this.firstBtnSendCodeColor2, true, false)
        if (this.countdown <= 0) {
          this.firstBtnSendCodeStyle('发送验证码', this.firstBtnSendCodeColor3, false, true)
        }
      }, 1000)
    },

    /** 第一次 发送验证码按钮
     * _text 显示文本
     * _style 发送验证码按钮显示样式
     * _isDisabled 按钮是否可点击
     * _isInterval 定时器是否可用
     */
    firstBtnSendCodeStyle(_text, _style, _isDisabled, _isInterval) {
      if (_isInterval) {
        clearInterval(this.intervalId)
        this.intervalId = null
      }
      this.firstBtnSendCode = _text
      ;(this.firstBtnSendCodeColor = _style), (this.isDisabledFirstSendCode = _isDisabled)
    },

    // 邮箱确定
    handleOk(e) {
      //   this.confirmLoading = true
      //   setTimeout(() => {
      //     this.visible = false
      //     this.confirmLoading = false
      //   }, 2000)

      const username = this.currentUsername
      const email = this.form.getFieldValue('email')
      const captcha = this.QQEmailCaptcha
      const newEmail = this.form.getFieldValue('newEmail')

      if (!username || !email || !captcha || !newEmail) {
        this.$message.error('一个或多个字段为空或未定义!')
        return
      }

      if (!this.ValidQQEmailState) {
        this.form.validateFields(['email'], (errors, values) => {
          if (errors) {
            // 处理验证失败的情况
            // console.error('QQ邮箱验证失败', errors)
          } else {
            // 处理验证成功的情况
            // console.log('QQ邮箱验证成功', values)
            // 执行发送验证码的逻辑或其他操作
          }
        })
        return
      }
      if (!this.ValidNewQQEmailState) {
        this.form.validateFields(['newEmail'], (errors, values) => {
          if (errors) {
            // 处理验证失败的情况
            // console.error('QQ邮箱验证失败', errors)
          } else {
            // 处理验证成功的情况
            // console.log('QQ邮箱验证成功', values)
            // 执行发送验证码的逻辑或其他操作
          }
        })
        return
      }

      USER.updateNewQQEmailByUsername(username, email, captcha, newEmail)
        .then((res) => {
          if (res.code === '200') {
            this.visible = false

            this.$cookie.set('newEmail',this.formatEmail(this.form.getFieldValue('newEmail')));
            this.$emit('notify','邮箱更新啦')
            
          } else {
            this.$message.error(res.msg)
          }
        })
        .catch((err) => err)
    },

    handleCancel(e) {
      this.visible = false
    },

    handleEmailCheck(rule, value, callback) {
      if (!/^[a-zA-Z0-9_-]+@qq.com$/.test(value)) {
        callback(new Error('请输入正确的QQ邮箱地址'))
      } else {
        this.validCurrentEmail(rule, value, callback)
      }
    },
    handleNewEmailCheck(rule, value, callback) {
      if (!/^[a-zA-Z0-9_-]+@qq.com$/.test(value)) {
        this.ValidNewQQEmailState = false
        callback(new Error('请输入正确的QQ邮箱地址'))
      } else {
        this.ValidNewQQEmailState = true
        callback()
      }
    },

    validCurrentEmail(rule, value, callback) {
      const inputEmail = this.form.getFieldValue('email')
      USER.validCurrentEmailByUsername(this.currentUsername, inputEmail)
        .then((res) => {
          if (res.code === '200') {
            this.ValidQQEmailState = true // 验证手机号标志位
            callback()
          } else {
            this.ValidQQEmailState = false // 验证手机号标志位
            callback(new Error('QQ邮箱验证错误,请从新输入'))
          }
        })
        .catch((err) => {
          this.ValidQQEmailState = false // 验证手机号标志位
        })
    },
  },
}
</script>
<style scoped>
</style>
