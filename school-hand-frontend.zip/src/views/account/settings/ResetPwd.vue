<template>
  <div>
    <a-modal
      title="重置密码"
      v-model="visible"
      :confirm-loading="confirmLoading"
      cancelText="关闭"
      :maskClosable="false"
      @ok="handleOk"
      @cancel="handleCancel"
    >
      <a-form :form="form" ref="resetForm">
        <a-form-item label="登录名称:" prop="username" :label-col="{ span: 5 }">
          <a-input v-model="formData.username" style="width: 300px" disabled>
            <a-icon slot="prefix" type="user" />
            <a-tooltip slot="suffix" title="当前登录账号">
              <a-icon type="info-circle" style="color: rgba(0, 0, 0, 0.45)" />
            </a-tooltip>
          </a-input>
        </a-form-item>
        <a-form-item label="旧密码" :label-col="{ span: 5 }">
          <a-input-password
            v-decorator="[
              'oldPassword',
              {
                rules: [{ required: true, message: '' }, { validator: this.handleOldPassword }],
                validateTrigger: ['change', 'blur'],
              },
            ]"
            style="width: 300px"
          >
          </a-input-password>
        </a-form-item>

        <!-- <a-form-item label="新密码" prop="newPassword" :label-col="{ span: 5 }">
          <a-input type="password" v-model="formData.newPassword" style="width: 300px" />
        </a-form-item> -->

        <a-popover
          placement="rightTop"
          :trigger="['focus']"
          :getPopupContainer="(trigger) => trigger.parentElement"
          v-model="state.passwordLevelChecked"
        >
          <template slot="content">
            <div :style="{ width: '240px' }">
              <div :class="['user-register', passwordLevelClass]">{{ $t(passwordLevelName) }}</div>
              <a-progress :percent="state.percent" :showInfo="false" :strokeColor="passwordLevelColor" />
              <div style="margin-top: 10px">
                <span>{{ $t('user.register.password.popover-message') }} </span>
              </div>
            </div>
          </template>

          <a-form-item label="新密码" :label-col="{ span: 5 }">
            <a-input-password
              size="large"
              style="width: 300px"
              @click="handlePasswordInputClick"
              v-decorator="[
                'password',
                {
                  rules: [
                    { required: true, message: $t('user.password.required') },
                    { validator: this.handlePasswordLevel },
                  ],
                  validateTrigger: ['change', 'blur'],
                },
              ]"
            ></a-input-password>
          </a-form-item>
        </a-popover>

        <a-form-item label="确认密码" :label-col="{ span: 5 }">
          <a-input-password
            size="large"
            style="width: 300px"
            v-decorator="[
              'password2',
              {
                rules: [
                  { required: true, message: $t('user.password.required') },
                  { validator: this.handlePasswordCheck },
                ],
                validateTrigger: ['change', 'blur'],
              },
            ]"
          ></a-input-password>
        </a-form-item>

        <!-- <a-form-item label="确认密码" prop="confirmPassword" :label-col="{ span: 5 }">
          <a-input type="password" v-model="formData.confirmPassword" style="width: 300px">
            <a-tooltip slot="suffix" title="请再次输入您的密码">
              <a-icon type="info-circle" style="color: rgba(0, 0, 0, 0.45)" />
            </a-tooltip>
          </a-input>
        </a-form-item> -->
      </a-form>
      <!-- <a-button @click="getPwd">获取密码强度</a-button> -->
    </a-modal>
  </div>
</template>
<script>
import { scorePassword } from '@/utils/util'
import USER from '@/api/user'

const levelNames = {
  0: 'user.password.strength.short',
  1: 'user.password.strength.low',
  2: 'user.password.strength.medium',
  3: 'user.password.strength.strong',
}
const levelClass = {
  0: 'error',
  1: 'error',
  2: 'warning',
  3: 'success',
}
const levelColor = {
  0: '#ff0000',
  1: '#ff0000',
  2: '#ff7e05',
  3: '#52c41a',
}

export default {
  data() {
    return {
      visible: false,
      confirmLoading: false,
      form: this.$form.createForm(this),
      formData: {
        username: '', // 当前账号
      },
      state: {
        time: 60,
        level: 0,
        smsSendBtn: false,
        passwordLevel: 0,
        passwordLevelChecked: false,
        percent: 10,
        progressColor: '#FF0000',
      },
      flag: false,
    }
  },
  computed: {
    passwordLevelClass() {
      return levelClass[this.state.passwordLevel]
    },
    passwordLevelName() {
      return levelNames[this.state.passwordLevel]
    },
    passwordLevelColor() {
      return levelColor[this.state.passwordLevel]
    },
  },
  watch: {
    'state.passwordLevel'(val) {
      console.log(val)
    },
  },
  methods: {
    // 获取密码强度,这样得从后端传递过来密码,密码不能传递的,所以..
    getPwd() {
      this.handlePasswordLevelStr('Aadmin12')
      console.log('密码强度: ', this.passwordLevelName)
    },

    // 获取密码强度
    handlePasswordLevelStr(value) {
      if (!value) {
        alert('不能为空')
      }
      console.log('密码强度 ; ', scorePassword(value))
      if (value.length >= 6) {
        if (scorePassword(value) >= 30) {
          this.state.level = 1
        }
        if (scorePassword(value) >= 60) {
          this.state.level = 2
        }
        if (scorePassword(value) >= 80) {
          this.state.level = 3
        }
      } else {
        this.state.level = 0
      }
      this.state.passwordLevel = this.state.level
      this.state.percent = this.state.level * 33
    },

    handleOldPassword(rule, value, callback) {
      if (!value) {
        callback(new Error('请输入原始密码!'))
      } else {
        this.oldPwdVaild(rule, value, callback)
      }
    },

 // 旧密码
    oldPwdVaild(rule, value, callback) {
      // console.log('输入值: ',this.form.getFieldValue('oldPassword'))
      // console.log('value: ',value)
      if (value) {
        USER.getpwdByUsername(this.formData.username, value)
          .then((res) => {
            if (res.code === '200') {
              this.flag = true
              callback()
            } else {
              callback(new Error('原始密码错误!'))
            }
          })
          .catch((err) => err)
      } else {     
        callback(new Error('请输入原始密码!'))
      }
    },

    handlePasswordLevel(rule, value, callback) {
      if (!value) {
        return callback()
      }
      console.log('scorePassword ; ', scorePassword(value))
      if (value.length >= 6) {
        if (scorePassword(value) >= 30) {
          this.state.level = 1
        }
        if (scorePassword(value) >= 60) {
          this.state.level = 2
        }
        if (scorePassword(value) >= 80) {
          this.state.level = 3
        }
      } else {
        this.state.level = 0
        callback(new Error(this.$t('user.password.strength.msg')))
      }
      this.state.passwordLevel = this.state.level
      this.state.percent = this.state.level * 33

      callback()
    },

    handlePasswordCheck(rule, value, callback) {
      const password = this.form.getFieldValue('password')
      // console.log('value', value)
      if (value === undefined) {
        callback(new Error(this.$t('user.password.required')))
      }
      if (value && password && value.trim() !== password.trim()) {
        callback(new Error(this.$t('user.password.twice.msg')))
      }
      callback()
    },

    handlePhoneCheck(rule, value, callback) {
      console.log('handlePhoneCheck, rule:', rule)
      console.log('handlePhoneCheck, value', value)
      console.log('handlePhoneCheck, callback', callback)

      callback()
    },

    handlePasswordInputClick() {
      if (!this.isMobile) {
        this.state.passwordLevelChecked = true
        return
      }
      this.state.passwordLevelChecked = false
    },

    // 打开重置密码对话框
    showModal(_usernameOrPhone) {
      this.visible = true
      this.formData.username = _usernameOrPhone
      this.form.resetFields() // 清空表单数据
      this.state.passwordLevelChecked = false // 密码强度对话框
    },
    closeModal() {
      this.visible = false
    },
    // getCurrentUser(_username){
    //   console.log('传递过来的账号是: ',_username)
    // },

    // 确定按钮
    handleOk(e) {
      const username = this.formData.username
      const oldPwd = this.form.getFieldValue('oldPassword')
      const newPwd = this.form.getFieldValue('password')
      const surePwd = this.form.getFieldValue('password2')

      if (this.flag) {
        USER.resetPwdByUsername(username, oldPwd, newPwd, surePwd).then((res) => {
          if (res.code === '200') {
            this.visible = false
            this.$cookie.set('pwdState', this.passwordLevelName)
            // 通知一下父组件,不然不知道这个密码强度状态
            this.$emit('notify', '密码强度更新啦')
            this.$message.success('重置密码成功!')
          } else {
            this.$message.error('重置密码失败')
          }
        })
      } else {
        this.$message.error('原始密码有误!')
      }

      // this.confirmLoading = true
      // setTimeout(() => {
      //   this.visible = false
      //   this.confirmLoading = false
      // }, 2000)
    },

    // 关闭按钮
    handleCancel(e) {
      // console.log('点击取消按钮')
      this.visible = false
    },
  },
}
</script>

<style lang="less">
.user-register {
  &.error {
    color: #ff0000;
  }

  &.warning {
    color: #ff7e05;
  }

  &.success {
    color: #52c41a;
  }
}

.user-layout-register {
  .ant-input-group-addon:first-child {
    background-color: #fff;
  }
}
</style>
<style lang="less" scoped>
.user-layout-register {
  & > h3 {
    font-size: 16px;
    margin-bottom: 20px;
  }

  .getCaptcha {
    display: block;
    width: 100%;
    height: 40px;
  }

  .register-button {
    width: 50%;
  }

  .login {
    float: right;
    line-height: 40px;
  }
}
</style>

