<template>
  <div class='account-settings-info-view'>
    <a-row :gutter='16' type='flex' justify='center'>
      <a-col :order='isMobile ? 2 : 1' :md='24' :lg='16'>
        <a-form layout='vertical'>
          <a-form-item :label="$t('account.settings.basic.nickname')">
            <a-input
              :placeholder="$t('account.settings.basic.nickname-message')"
              :disabled='isDisabled'
              v-model='userInfo.nickname'
            />
          </a-form-item>

          <a-form-item label='性别'>
            <a-radio-group default-value='1' button-style='solid' :disabled='isDisabled' v-model='userInfo.sex'>
              <a-radio-button value='1'> 男</a-radio-button>
              <a-radio-button value='0'> 女</a-radio-button>
            </a-radio-group>
          </a-form-item>

          <a-form-item :label="$t('account.settings.basic.profile')">
            <a-textarea
              :disabled='isDisabled'
              rows='4'
              :placeholder="$t('account.settings.basic.profile-message')"
              v-model='userInfo.persProfile'
            />
          </a-form-item>

          <a-form-item>
            <!-- <a-button style="margin-right: 50px" @click="editBasicInfo">编辑基本信息</a-button> -->
            <!-- <div class="main" data-text="编辑基本信息" style="--c:#ff4757"></div> -->

            <div class='main' @click='editBasicInfo' data-text='编辑基本信息' style='--c: #1e90ff'></div>

            <a-button
              style='margin-left: 200px; margin-bottom: 100px; position: relative; top: -30px'
              type='primary'
              @click='updateBasicInfo'
            >{{ $t('account.settings.basic.update') }}
            </a-button
            >
          </a-form-item>
        </a-form>
      </a-col>
      <a-col :order='1' :md='24' :lg='8' :style="{ minHeight: '180px' }">
        <div class='ant-upload-preview' @click='$refs.modal.edit(Math.random())'>
          <a-icon type='cloud-upload-o' class='upload-icon' />
          <div class='mask'>
            <a-icon type='plus' />
          </div>
          <img v-if='userInfo.avatar' :src='userInfo.avatar' />
          <img v-else :src='option.img' alt='默认头像' />
        </div>
      </a-col>
    </a-row>

    <avatar-modal ref='modal' @ok='setavatar' />
  </div>
</template>

<script>
import AvatarModal from './AvatarModal'
import { baseMixin } from '@/store/app-mixin'

import USER from '@/api/user'

export default {
  mixins: [baseMixin],
  components: {
    AvatarModal
  },
  data() {
    return {
      num: Math.random(),
      sexValue: '1', // 默认性别是 男
      nicknameValue: '', // 昵称
      persProfileValue: '', // 个人简介

      // cropper
      preview: {},
      option: {
        // img: require('@/assets/school.png'),
        img: require('@/assets/school.png'),
        info: true,
        size: 1,
        outputType: 'jpeg',
        canScale: false,
        autoCrop: true,
        // 只有自动截图开启 宽度高度才生效
        autoCropWidth: 180,
        autoCropHeight: 180,
        fixedBox: true,
        // 开启宽度和高度比例
        fixed: true,
        fixedNumber: [1, 1]
      },

      isDisabled: true,
      userInfo: {} // 用户信息
    }
  },

  mounted() {
    this.getCurrentLoginUserInfo() // 获取当前登录的用户信息
    console.log('vuex中的令牌状态: ', this.$store.state.user.token)
  },

  methods: {
    getCurrentLoginUserInfo() {
      const currentUser = this.$cookie.get('user')
      USER.getCurrentUser(currentUser)
        .then((res) => {
          if (res.code === '200') {
            setTimeout(() => {
              console.log('用户信息：', res)
              this.userInfo = res.data
              this.$store.commit('SET_ROLE', res.data.role)
              // 登录成功之后，主页面设置角色
            }, 1500)
          } else {
            this.$notification.error({
              message: '错误',
              description: res.msg
            })
          }
        })
        .catch((err) => err)
    },
    setavatar(url) {
      // this.option.img = url
      this.userInfo.avatar = url
    },
    // 编辑基本信息
    editBasicInfo() {
      this.isDisabled = false
    },
    // 更新基本信息
    updateBasicInfo() {
      if (!this.userInfo.nickname.length > 0) {
        this.$message.error('昵称不能为空')
        return;
      }
      USER.updateUserBasicInfoByUsername(this.userInfo)
        .then((res) => {
          if (res.code === '200') {
            // 更换右上角头像,当修改成功之后，就修改头像
            this.$store.commit('setHeadAvatar', this.userInfo.avatar)
            this.isDisabled = true

            this.$notification.success({
              message: '更新成功',
              description: `您的基本信息已更新成功`
            })
          } else {
            this.$notification.error({
              message: '更新失败',
              description: `更新基本信息有误!`
            })
          }
        })
        .catch((err) => err)
    }
  }
}
</script>

<style lang='less' scoped>
.avatar-upload-wrapper {
  height: 200px;
  width: 100%;
}

.ant-upload-preview {
  position: relative;
  margin: 0 auto;
  width: 100%;
  max-width: 180px;
  border-radius: 50%;
  box-shadow: 0 0 4px #ccc;

  .upload-icon {
    position: absolute;
    top: 0;
    right: 10px;
    font-size: 1.4rem;
    padding: 0.5rem;
    background: rgba(222, 221, 221, 0.7);
    border-radius: 50%;
    border: 1px solid rgba(0, 0, 0, 0.2);
  }

  .mask {
    opacity: 0;
    position: absolute;
    background: rgba(0, 0, 0, 0.4);
    cursor: pointer;
    transition: opacity 0.4s;

    &:hover {
      opacity: 1;
    }

    i {
      font-size: 2rem;
      position: absolute;
      top: 50%;
      left: 50%;
      margin-left: -1rem;
      margin-top: -1rem;
      color: #d6d6d6;
    }
  }

  img,
  .mask {
    width: 100%;
    max-width: 180px;
    height: 100%;
    border-radius: 50%;
    overflow: hidden;
  }
}

.main {
  position: relative;
  width: 116px;
  height: 32px;
  background: #1890ff;
  margin-right: 20px;
  display: flex;
  flex: 1 0 auto;
  justify-content: center;
  align-items: center;
  overflow: hidden;
  border-radius: 5px;
  transition: 1s linear;
}

.main::before {
  content: '';
  width: 300px;
  height: 60px;
  background: var(--c);
  position: absolute;
  animation: roll 4s linear infinite;
  filter: blur(5px);
  transition: 1s linear;
}

.main::after {
  width: 111px;
  height: 27px;
  content: attr(data-text);
  position: absolute;
  color: rgba(0, 0, 0, 0.65);
  font-size: 14px;
  text-align: center;
  line-height: 29px;
  background: #fff;
  text-transform: uppercase;
  font-family: Arial, Helvetica, sans-serif;
  // border-radius: 5px;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  transition: 1s linear;
}

@keyframes roll {
  100% {
    transform: rotate(360deg);
    filter: blur(5px) hue-rotate(360deg);
  }
}

.main:hover {
  box-shadow: 0 0 5px var(--c), 0 0 10px var(--c), 0 0 20px var(--c);
  background: var(--c);
}

.main:hover::before {
  height: 500px;
  width: 500px;
  animation-play-state: paused;
  filter: hue-rotate(0);
}

.main:hover::after {
  background: var(--c);
  color: white;
}
</style>
