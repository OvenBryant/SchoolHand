<template>
  <div>
    <a-card hoverable style="width: 100%">
      <a-card-meta title="校园二手交易平台" :description="descText">
        <img slot='avatar' src='@/assets/iconLogo.png'/>
      </a-card-meta>
    </a-card>
    <a-divider />

    <a-card :body-style='{ padding: 0, margin: 0 }' style='width: 400px;'>
      <div slot='title'>
        <span style='font-weight: bold;'>公告栏</span>
        <img style='margin-left: 5px' src='@/assets/icons/userHomeNoticeIcon.svg' />
      </div>
      <a-collapse :activeKey='activeKey' accordion expandIconPosition='right' :bordered='false' style='margin-top:2px'>
        <a-collapse-panel v-for='(item, index) in dataSourceNotice' :key='index'
                          :style="{ backgroundColor: 'white', width: '100%' }">
          <template slot='header'>
            {{ item.title }}
            <span style='margin-left: 5px'>{{ item.createTime }}</span>
          </template>
          <div v-html='renderMarkdown(item.content)' style='margin-left: 20px;'></div>
          <!--/*          <p style='margin-left: 20px;font-weight: bold'>{{ item.content }}</p>*/-->
        </a-collapse-panel>
      </a-collapse>
    </a-card>
  </div>
</template>
<script>

import { getLatestFiveNotices } from '@/api/notice'
import markdown from '@/api/markdown-it.min'

export default {
  data() {
    return {
      descText: '欢迎来到我们的校园二手交易平台！这里是一个充满惊喜的购物天堂，您可以轻松找到各类便宜又实惠的二手物品，无论是学习资料、生活用品还是潮流配饰，应有尽有。我们致力于为您提供一个便捷、安全的交易环境，让您在享受购物乐趣的同时，也能体验到物超所值的满足感。\n' +
        '\n' +
        '同时，如果您有闲置的物品想要出售，这里也是您的最佳选择。只需简单几步，您就可以将物品上传到平台，让其他用户发现它的价值。我们鼓励大家积极分享自己的闲置物品，不仅能让它们发挥新的作用，还能为环保出一份力。\n' +
        '\n' +
        '在这里，交易变得简单而愉快，每一次的买卖都是一次新的相遇和分享。快来加入我们吧，让二手交易成为校园生活的一部分，共同打造一个绿色、和谐的校园二手交易生态圈！',
      text: `hello world `,
      activeKey: ['0'],
      dataSourceNotice: [{
        title: '无公告',
        content: '无内容',
        createTime: ''
      }],
      md: new markdown() // 创建 markdown-it 实例
    }
  },
  created() {
    getLatestFiveNotices().then(res => {
      if (res.code === '200') {
        console.log('公告: ',res)
        this.dataSourceNotice = res.data
      } else {

        //this.$message.error('获取公告异常')
      }
    })
  },
  methods: {
    // 渲染 Markdown 内容为 HTML
    renderMarkdown(content) {
      return this.md.render(content)
    }
  }
}
</script>
<style scoped>

</style>
