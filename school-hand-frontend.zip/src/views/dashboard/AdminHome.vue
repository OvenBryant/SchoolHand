<template>
  <div>
    <a-row :gutter='5'>
      <a-col :span='8'>
        <a-card hoverable style='width: 300px;background-color: #F96868;'>
          <a-card-meta title='总金额' :description='formattedTotalPrice'>
            <img
              slot='avatar'
              src='@/assets/dashboardIcon/moeny.png'
            />
          </a-card-meta>
        </a-card>
      </a-col>
      <a-col :span='8'>
        <a-card hoverable style='width: 300px;background-color: #FC8D2B;'>
          <a-card-meta title='交易数量' :description='formattedOrderCount'>
            <img
              slot='avatar'
              src='@/assets/dashboardIcon/count.png'
            />
          </a-card-meta>
        </a-card>
      </a-col>
      <a-col :span='8'>
        <a-card hoverable style='width: 300px; background-color: #926DDE'>
          <a-card-meta title='物品总数' :description='formattedProductCount'>
            <img
              slot='avatar'
              src='@/assets/dashboardIcon/goods.png'
            />
          </a-card-meta>
        </a-card>
      </a-col>
      <a-col :span='8' style='margin-top: 20px'>
        <a-card hoverable style='width: 300px;background-color: #33CABB;'>
          <a-card-meta title='管理员用户总数' :description='formattedMale'>
            <img
              slot='avatar'
              src='@/assets/dashboardIcon/admin.png'
            />
          </a-card-meta>
        </a-card>
      </a-col>
      <a-col :span='8' style='margin-top: 20px'>
        <a-card hoverable style='width: 300px; background-color: #15C377;'>
          <a-card-meta title='普通用户总数' :description='formattedFemale'>
            <img
              slot='avatar'
              src='@/assets/dashboardIcon/user.png'
            />
          </a-card-meta>
        </a-card>
      </a-col>
    </a-row>
    <a-divider />
    <a-row :gutter='24'>
      <!--      <a-col :span='12'>-->
      <!--        <a-card style='height: 400px'>-->
      <!--          <h2>统计商品类别个数，分别是统计前5的商品个数，比如电子产品。这里后端可以使用一个定时器任务</h2>-->
      <!--          <h3>1. 轮询：前端定时向后端发送请求，获取最新数据并更新页面。这可以通过setInterval在Vue组件的mounted生命周期钩子中实现。但请注意，这种方法可能会导致不必要的请求和服务器压力。</h3>-->
      <!--          <h3>2. WebSocket：使用WebSocket建立长连接，后端可以在数据改变时主动向前端推送消息。前端接收到消息后，更新Vue的data，视图将自动更新。这种方式更实时，且减少了不必要的请求。</h3>-->
      <!--          <h3>3. Vuex + 后端发布/订阅：如果你的应用使用了Vuex作为状态管理库，可以结合后端的发布/订阅机制。后端在数据改变时发布消息，前端订阅这些消息，并在接收到消息时通过Vuex的mutation或action更新状态。Vue组件可以响应这些状态的变化，自动更新视图。</h3>-->
      <!--        </a-card>-->
      <!--      </a-col>-->
      <a-col :span='12'>
        <div ref='chartContainer' style='width: 600px; height: 400px;'></div>
      </a-col>
    </a-row>
  </div>
</template>

<script>

import * as echarts from '@/api/echarts'
import { getAdminHomeData } from '@/api/adminUser'


export default {
  name: 'AdminHome',
  data() {
    return {
      homeData: {
        female: 0,
        male: 0,
        orderCount: 0,
        productCount: 0,
        totalPrice: 0,
        productLimit5: []
      }
    }
  },
  mounted() {
    this.getHomeData()
  },
  computed: {
    formattedTotalPrice() {
      return `￥ ${this.homeData.totalPrice.toFixed(2)}`
    },
    formattedFemale() {
      return `${this.homeData.female}`
    },
    formattedMale() {
      return `${this.homeData.male}`
    },
    formattedOrderCount() {
      return `${this.homeData.orderCount}`
    },
    formattedProductCount() {
      return `${this.homeData.productCount}`
    }
  },
  methods: {
    getHomeData() {
      getAdminHomeData().then(res => {
        this.homeData = res.data

        this.renderChart()

      })
    },
    renderChart() {
      const chartContainer = this.$refs.chartContainer
      const myChart = echarts.init(chartContainer)

      let xValue = []
      let barData = []
      for (let i = 0; i < this.homeData.productLimit5.length; i++) {
        xValue.push(this.homeData.productLimit5[i].category)
        barData.push(this.homeData.productLimit5[i].count)
      }

      const option = {
        title: {
          text: '综合物品汇总分析'
        },
        tooltip: {},
        xAxis: {
          data: xValue,
          boundaryGap: false
        },
        yAxis: {
          min: 0,
          max: 18,
          interval: 3
        },
        series: [
          {
            type: 'line',
            data: barData,
            label: {
              show: true,
              position: 'top',
              formatter: '{c}'
            },
            itemStyle: {
              color: '#1890FF' // 每个柱子不同的颜色
            },
            lineStyle: {
              color: '#15C377' // 设置线的颜色为绿色
            }
          }
        ],
        toolbox: {
          feature: {
            magicType: {
              show: true,
              type: ['line', 'bar']
            },
            restore: {
              title: '还原'
            },
            saveAsImage: {
              title: '保存为图片',
              lang: ['右键另存为图片']
            }
          }
        }
      }
      myChart.setOption(option)
      // // 监听图表类型切换事件
      // myChart.on('magicTypeChanged', params => {
      //   if (params.currentType[0] === 'pie') {
      //   myChart.setOption(option2)
      //   console.error(params)
      // })
    }
  }
}
</script>

<style scoped>
::v-deep .ant-card-meta-title {
  color: white;
  font-size: 20px;
  margin-left: 10px;
}

::v-deep .ant-card-meta-description {
  color: white;
  font-size: 20px;
  margin-left: 10px;
}

.col-with-padding {
  /*padding: 0 20px; !* 添加左右内边距，数值可以根据需要调整 *!*/
}
</style>
