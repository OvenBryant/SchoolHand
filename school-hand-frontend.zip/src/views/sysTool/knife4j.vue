<template>
  <div>
  </div>
</template>

<script>
import request from '@/utils/request'

export default {
  name: 'knife4j',
  created() {
    window.open(`${request.defaults.baseURL}/doc.html#/home`, '_blank', '')
  }
}
</script>

<style scoped>

</style>