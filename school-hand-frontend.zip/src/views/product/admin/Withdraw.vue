<template>
  <div>
    <a-table
      v-if='resultData.length > 0 '
      :columns='columns'
      :data-source='resultData'
      :rowKey='record=> record.userId'
      style='margin-top: 15px'>
       <span slot='image' slot-scope='text'>
             <div style='display: flex;align-items: center;justify-content: center'>
               <a-avatar v-for='(imageObj, index) in text' :key='index' :src='imageObj.url' />
            </div>
        </span>
      <span style='color:red;font-weight: bold' slot='username' slot-scope='text'>
        {{ text }}
      </span>
      <span slot='auditStatus' slot-scope='text'>
        <!-- 根据 text 的值动态决定显示哪个图标 -->
        <template v-if='text === "2"'>
          <a-icon type='check-circle' theme='twoTone' two-tone-color='#52c41a' /> 通过
        </template>
        <template v-else-if='text === "3"'>
          <img src='@/assets/gantanhao.png' /> 未通过
        </template>
        <template v-else-if='text === "0"'>
            <img src='@/assets/auditing.png' style='width: 25px;height: 25px' />待审核
        </template>
        <template v-else-if='text === "4"'>
          <a-icon type='check-circle' theme='twoTone' two-tone-color='#52c41a' /> 已撤回
        </template>
        <template v-else>
            <a-icon type='check-circle' theme='twoTone' two-tone-color='#52c41a' /> 已撤回
        </template>
      </span>

      <span slot='action' slot-scope='text,record'>
         <a>详情</a>
      </span>
    </a-table>
    <a-result v-else title='空'/>
  </div>
</template>

<script>

const columns = [
  {
    title: '商品图片',
    dataIndex: 'image',
    width: 120,
    align: 'center',
    scopedSlots: { customRender: 'image' }
  },
  {
    title: '产品名称',
    dataIndex: 'productName',
    width: 120
  },
  {
    title: '商品类别',
    dataIndex: 'category',
    width: 120
  },
  {
    title: '上传者',
    dataIndex: 'username',
    scopedSlots: { customRender: 'username' },
    width: 120
  },
  {
    title: '审核状态',
    dataIndex: 'auditStatus',
    width: 120,
    scopedSlots: { customRender: 'auditStatus' }
  },
  {
    title: '上传时间',
    dataIndex: 'productCreateTime',
    width: 180,
    align: 'center'
  },
  {
    title: '操作',
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  props: {
    resultData: Array
  },
  name: 'PendingReview',
  data() {
    return {
      columns,
      auditsVo: {
        selectProductName: '',
        selectAuditsStatus: ''
      },
      selectedRowKeys: [],
      recordList: []
    }
  },
  methods: {}
}
</script>

<style scoped>

</style>