<template>
  <div>
    <div style='margin-bottom: 15px'>
      产品名称：
      <a-input placeholder='产品名称' v-model='uploadParams.productName'
               style='width: 180px;margin-left: 5px;margin-right: 15px'
               allowClear @change='selectInputShow()' />
      上传者：
      <a-input placeholder='上传者' v-model='uploadParams.currentUser' style='width: 150px;margin-left: 5px'
               allowClear @change='selectInputShow()' />
    </div>
    <a-tabs :default-active-key='activeTabKey' v-model='activeTabKey' @change='tabsChangeClick'>
      <a-tab-pane key='0'>
      <span slot='tab'>
       <img src='@/assets/auditing.png' />
        待审核
      </span>
        <PendingReview :resultData='resultData' />
      </a-tab-pane>
      <a-tab-pane key='2'>
      <span slot='tab'>
       <img src='@/assets/success.png' />
        通过
      </span>
        <Success :resultData='resultData' />
      </a-tab-pane>
      <a-tab-pane key='3'>
      <span slot='tab'>
       <img src='@/assets/error.png' />
        未通过
      </span>
        <Error :resultData='resultData' />
      </a-tab-pane>
      <!--      <a-tab-pane key='4'>-->
      <!--      <span slot='tab'>-->
      <!--       <img src='@/assets/withdraw.png' />-->
      <!--        已撤回-->
      <!--      </span>-->
      <!--        <Withdraw :resultData='resultData' />-->
      <!--      </a-tab-pane>-->
    </a-tabs>
  </div>
</template>

<script>
import PendingReview from '@/views/product/admin/PendingReview'
import Success from '@/views/product/admin/Success'
import Error from '@/views/product/admin/Error'
import Withdraw from '@/views/product/admin/Withdraw'
import { getAuditsInfoList } from '@/api/product-audits'

export default {
  components: {
    PendingReview, Success, Error, Withdraw
  },
  name: 'UserSellTabs',
  data() {
    return {
      activeTabKey: '0',
      uploadParams: {
        productName: '',
        currentUser: ''
      },
      resultData: []
    }
  },
  created() {
    const tabIdData = this.$route.query.tabId ? this.$route.query.tabId : '0'
    this.activeTabKey = tabIdData
    this.getData(tabIdData)
  },
  methods: {
    getData(status) {
      getAuditsInfoList(status, this.uploadParams).then(res => {
        if (res.code === '200') {
          this.resultData = res.data
        }
      }).catch(err => {
        console.log(err)
      })
    },
    handleTabChange(newTabKey) {
      this.activeTabKey = newTabKey
    },
    tabsChangeClick(activeKey) {
      this.getData(activeKey)
    },
    selectInputShow() {
      this.getData(this.activeTabKey)
    }
  }
}
</script>

<style scoped>

</style>