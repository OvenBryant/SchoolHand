<template>
  <a-card :bordered='false'>
    <a-form layout='inline'>
      <a-row>
        <a-col :span='24'>
          <a-form-item label='商品名称' style='font-weight: bold'>
            <a-input type='text' style='width:200px;' v-model='queryParams.productName'
                     placeholder='请输入商品分类名称' allowClear @change='showChange()' />
          </a-form-item>
          <a-form-item label='商品类别' style='font-weight: bold;margin-left: 20px'>
            <a-select v-model='queryParams.category' placeholder='类别' style='width:130px;' allowClear
                      @change='showChange()'>
              <a-select-option
                v-for='(value,index) in dictCategoryName'
                :key='index'
                :label=value
                :value=value>
                {{ value }}
              </a-select-option>
            </a-select>
          </a-form-item>
          <a-form-item label='状态' style='font-weight: bold;margin-left: 20px'>
            <a-select v-model='queryParams.status' placeholder='状态' style='width:130px;' allowClear
                      @change='showChange()'>
              <a-select-option
                v-for='(value,index) in statusOptions'
                :key='index'
                :label=value.label
                :value=value.value>
                {{ value.label }}
              </a-select-option>
            </a-select>
          </a-form-item>
          <a-form-item label='上传者' style='font-weight: bold;margin-left: 20px'>
            <a-input v-model='queryParams.username' placeholder='请输入上传者' allowClear
                     style='width:200px;border-radius: 10px' @change='showChange()' />

            <a-button icon='reload' type='danger' @click='()=>(this.queryParams={},$refs.table.refresh(true))'
                      style='margin-left:15px'>重置
            </a-button>
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>

    <a-button class='btnAdd' type='primary' icon='plus' @click="$router.push({name: 'userAdminProductAddProduct'})">添
      加
    </a-button>
    <a-button class='btnUpdate' :disabled='selectedRowKeys.length!==1' icon='edit' @click='handleUpdateDict2'>修 改
    </a-button>


    <a-popconfirm
      :visible.sync='isVisible'
      ok-text='确定'
      cancel-text='取消'
      @confirm='deleteRow'
      @cancel='cancelDelPop'>
      <template slot='title'>
        <p>是否确认删除编号为 {{ selectedProductName }} 的数据项?</p>
      </template>
      <a-button class='btnDelete' @click='isVisible=true' :disabled='!selectedRowKeys.length > 0 ' icon='delete'>删 除
      </a-button>
    </a-popconfirm>

    <a-button style='margin-left: 20px' type='dashed' icon='upload' @click='exportLogs'>导出</a-button>


    <s-table
      ref='table'
      size='default'
      rowKey='id'
      :columns='columns'
      :data='loadData'
      :alert='true'
      :rowSelection='rowSelection'
      showPagination='auto'
    >
        <span slot='image' slot-scope='text'>
             <div style='display: flex;align-items: center;justify-content: center'>
               <a-avatar v-for='(imageObj, index) in text' :key='index' :src='imageObj.url' />
            </div>
        </span>
      <span slot='originalPrice' slot-scope='text'>
          <span>￥{{ text }}</span>
      </span>
      <span slot='salePrice' slot-scope='text'>
          <span>￥{{ text }}</span>
      </span>
      <span slot='status' slot-scope='text'>
      <a-tag style='padding: 4px 9px' :color="text=== 1 ? '#87d068':'#f50'">
        {{ text === 1 ? '在 售' : '下 架' }}
        </a-tag>
    </span>
      <span style='color:red;font-weight: bold' slot='username' slot-scope='text'>
        {{ text }}
      </span>
      <span slot='action' slot-scope='text, record'>
          <template>
            <a @click='handleUpdateCurrentDict(record)'>
            <a-icon type='edit' />修改
            </a>
            <a-divider type='vertical' />
             <a @click='record.showConfirm = true'>
              <a-icon type='delete' />删除
            </a>
          <a-divider type='vertical' />
               <a @click='handleMoreProduct(record)'>
            <a-icon type='double-right' />更多
            </a>
             <a-popconfirm
               :title="'是否确认删除编号为【 ' + record.productName + ' 】的数据项?'"
               :visible.sync='record.showConfirm'
               placement='top'
               ok-text='确定'
               cancel-text='取消'
               @confirm='handleDel(record)'
               @cancel='record.showConfirm = false'
             >
            </a-popconfirm>
          </template>
      </span>
    </s-table>

    <a-modal title='添加字典类型' :visible.sync='visibleDictModel' width='780px' :destroy-on-close='true'
             @cancel='cancelDictModal'>
      <a-form :form='form' :label-col='{ span: 5 }' :wrapper-col='{ span: 12 }'>
        <a-form-item label='字典名称'>
          <a-input
            v-decorator="['name', { rules: [{ required: true, message: '请输入字典名称' }] }]"
          />
        </a-form-item>
        <a-form-item label='字典类型'>
          <a-input
            v-decorator="['categoryId', { rules: [{ required: true, message: '请输入字典类型' }],
               initialValue: 1}]"
          />
        </a-form-item>
      </a-form>
      <div slot='footer' class='dialog-footer'>
        <a-button type='primary' @click='addDictData'>确 定</a-button>
        <a-button @click='cancelDictModal'>取 消</a-button>
      </div>
    </a-modal>

    <a-modal title='修改商品信息' :visible.sync='visibleUpdateDictModel' width='780px' :destroy-on-close='true'
             @cancel='cancelUpdateDictModal'>
      <a-form :form='form' :label-col='{ span: 5 }' :wrapper-col='{ span: 12 }'>
        <a-form-item label='id'>
          <a-input disabled
                   v-decorator="['id', { rules: [{ required: true, message: '不能修改id' }]}]"
          />
        </a-form-item>
        <a-form-item label='商品名称'>
          <a-input
            v-decorator="['productName', { rules: [{ required: true, message: '请输入商品名称' }] }]"
          />
        </a-form-item>
        <a-form-item label='商品类别'>
          <a-select placeholder='类别' style='width:130px;'
                    v-decorator="['category', { rules: [{ required: true, message: '请输入商品类别名称' }] }]"
                    allowClear>
            <a-select-option
              v-for='(value,index) in dictCategoryName'
              :key='index'
              :label=value
              :value=value>
              {{ value }}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label='原价'>
          <span>￥</span>
          <a-input-number id='inputNumber' :min='1' :max='10000'
                          v-decorator="['originalPrice', { rules: [{ required: true, message: '请输入原价' }] }]" />
        </a-form-item>
        <a-form-item label='售价'>
          <span>￥</span>
          <a-input-number id='inputNumber' :min='1' :max='10000'
                          v-decorator="['salePrice', { rules: [{ required: true, message: '请输入售价' }] }]" />
        </a-form-item>
        <a-form-item label='商品个数'>
          <a-input-number id='inputNumber' :min='1' :max='10000'
                          v-decorator="['quantity', { rules: [{ required: true, message: '请输入商品个数' }] }]" />
        </a-form-item>
        <a-form-item label='状态'>
          <a-select placeholder='请选择' style='width:130px;'
                    v-decorator="['status', { rules: [{ required: true, message: '请选择状态' }] }]" allowClear>
            <a-select-option
              v-for='(value,index) in statusOptions'
              :key='index'
              :label=value.label
              :value=value.value>
              {{ value.label }}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label='商品描述'>
          <a-textarea
            v-decorator="['description', { rules: [{ required: true, message: '请输入商品描述' }] }]"
          />
        </a-form-item>
      </a-form>
      <div slot='footer' class='dialog-footer'>
        <a-button type='primary' @click='updateProductData'>确 定</a-button>
        <a-button @click='cancelUpdateDictModal'>取 消</a-button>
      </div>
    </a-modal>

  </a-card>
</template>

<script>


import { getlistProductPage, updateProduct, updateProductDeleteById, api } from '@/api/product'

import { getDictNameByCategoryId } from '@/api/dict'


import { STable } from '@/components'

import notification from 'ant-design-vue/lib/notification'
import storage from 'store'
import { ACCESS_TOKEN } from '@/store/mutation-types'
import request from '@/utils/request'

const columns = [
  {
    title: '商品图片',
    dataIndex: 'image',
    width: 100,
    align: 'center',
    scopedSlots: { customRender: 'image' }
  },
  {
    title: '商品名称',
    width: 120,
    align: 'center',
    dataIndex: 'productName'
  },
  {
    title: '商品类别',
    width: 120,
    align: 'center',
    dataIndex: 'category'
  },
  {
    title: '原价',
    align: 'center',
    dataIndex: 'originalPrice',
    scopedSlots: { customRender: 'originalPrice' }
  },
  {
    title: '售价',
    align: 'center',
    dataIndex: 'salePrice',
    scopedSlots: { customRender: 'salePrice' }
  },
  {
    title: '个数',
    align: 'center',
    dataIndex: 'quantity'
  },
  {
    title: '状态',
    dataIndex: 'status',
    width: 80,
    align: 'center',
    scopedSlots: { customRender: 'status' }
  },
  {
    title: '上传者',
    align: 'center',
    dataIndex: 'username',
    scopedSlots: { customRender: 'username' }
  },
  {
    title: '上架日期',
    dataIndex: 'createTime',
    width: 180,
    sorter: true,
    align: 'center'
  },
  // {
  //   title: '更新时间',
  //   dataIndex: 'updateTime',
  //   width: 180,
  //   sorter: true,
  //   align: 'center'
  // },
  {
    title: '操作',
    dataIndex: 'action',
    align: 'center',
    width: '200px',
    scopedSlots: { customRender: 'action' }
  }
]

export default {
  name: 'List',
  components: {
    STable
  },
  data() {
    this.columns = columns
    return {
      form: this.$form.createForm(this, { name: 'coordinated' }),
      visibleDictModel: false,
      visibleUpdateDictModel: false,
      selectedRowKeys: [],
      selectedRows: [],
      selectedDeleteId: [],
      selectedProductName: [],
      check: false,
      delPop: false,
      isVisible: false,
      queryParams: {
        productName: undefined,
        category: undefined,
        username: undefined,
        status: undefined
      },
      statusOptions: [
        { label: '在售', value: 1 },
        { label: '下架', value: 2 }
      ],
      dictCategoryName: [],
      modalNotice: {
        status: 0,
        title: '',
        content: '',
        id: 0
      },
      visibleNoticeModel: false,
      visibleUpdateNoticeModel: false,
      loadData: (parameter) => {
        const requestParameters = Object.assign({}, parameter, this.queryParams)
        console.log('商品列表参数: ', requestParameters)
        return new Promise((resolve, reject) => {
          getlistProductPage(requestParameters)
            .then((res) => {
              console.log(res.data.records)
              resolve(res.data)
            })
            .catch((error) => {
              reject(error)
            })
        })
      }
    }
  },
  computed: {
    rowSelection() {
      return {
        selectedRowKeys: this.selectedRowKeys,
        onChange: this.onSelectChange
      }
    }
  },
  created() {
    getDictNameByCategoryId().then(res => {
      if (res.code === '200') {
        this.dictCategoryName = res.data
      } else {
        this.$message.error('获取字典类型错误!')
      }
    })
  },
  methods: {
    getStauts(status) {
      return status === 1 ? '在售' : '下架'
    },
    getStauts2(text) {
      return text === '在售' ? 1 : 2
    },
    // 昵称 输入框内容变化时的回调
    showChange() {
      this.$refs.table.refresh(true)
    },
    // 更多商品
    handleMoreProduct(record) {
      // 点击查看商品详情
      // this.$router.push({ name: 'userAdminEditUser', params: { userId: 123 } });

      storage.set('currentProductMore', record, new Date().getTime() + 7 * 24 * 60 * 60 * 1000)
      // this.$router.push({ name: 'userAdminProductMore', params: { productMore: record } })
      this.$router.push({ name: 'userAdminProductMore' })
    },
    handleDel(record) {
      let selectIdArr = []
      if (!isNaN(record.id)) {
        selectIdArr = [parseInt(record.id)]
      } else {
        selectIdArr = []
      }
      updateProductDeleteById({ ids: selectIdArr }).then(res => {
        if (res.code === '200') {
          notification.success({
            message: '操作提示',
            description: '删除成功!'
          })
          this.selectedRowKeys = []
          this.selectedRows = []
          // 刷新表格
          this.$refs.table.clearSelected()
          this.$refs.table.refresh(true)
        } else {
          notification.error({
            message: '操作提示',
            description: res.msg
          })
        }
        record.showConfirm = false
      })
    },
    deleteRow() {
      const rowIds = this.selectedRows.map(row => row.id)
      updateProductDeleteById({ ids: rowIds }).then(res => {
        if (res.code === '200') {
          this.$message.success('删除成功')
          this.isVisible = false
          // 刷新表格
          this.selectedRowKeys = []
          this.selectedRows = []
          this.$refs.table.clearSelected()
          this.$refs.table.refresh(true)
        } else {
          this.isVisible = false
          this.$message.error(res.msg)
        }
      })
    },

    cancelDelPop() {
      this.isVisible = false
    },
    onSelectChange(selectedRowKeys, selectedRows) {
      this.selectedRowKeys = []
      this.selectedRows = []
      this.selectedRowKeys = selectedRowKeys
      this.selectedRows = selectedRows
      this.selectedProductName = this.selectedRows.map(row => row.productName)
    },
    // 显示对话框
    addNotice() {
      this.modalNotice = {}
      this.visibleNoticeModel = true
    },
    // 导出excel表,如果当前没有数据,就不导出
    exportLogs() {
      getlistProductPage(this.queryParams).then((res) => {
        if (res.data.records.length > 0) {
          const token = storage.get(ACCESS_TOKEN)
          const url = request.defaults.baseURL + api.exportProductList + '?' + ACCESS_TOKEN + '=' + token
          window.open(url)
        } else {
          this.$message.error('当前没有需要导出的数据')
        }
      })
        .catch((error) => {
          console.error('Error fetching data:', error)
        })
    },
    // 显示添加字典对话框
    visibleAddDictModal() {
      this.visibleDictModel = true
    },
    addDictData() {
      this.form.validateFields((err, values) => {
        if (!err) {
          // addDict(values).then(res => {
          //   if (res.code === '200') {
          //     this.$message.success('添加字典成功')
          //     this.cancelDictModal()
          //     this.$refs.table.refresh(true)
          //   } else {
          //     this.$message.error(res.msg)
          //   }
          // })
        }
      })
    },
    // 表格上方的修改
    handleUpdateDict2() {
      this.visibleUpdateDictModel = true
      this.$nextTick(() => {
        this.form.setFieldsValue({
          id: this.selectedRows[0].id,
          productName: this.selectedRows[0].productName,
          category: this.selectedRows[0].category,
          originalPrice: this.selectedRows[0].originalPrice,
          salePrice: this.selectedRows[0].salePrice,
          quantity: this.selectedRows[0].quantity,
          status: this.selectedRows[0].status,
          description: this.selectedRows[0].description
        })
      })
    },
    // 修改当前字典
    updateProductData() {
      this.form.validateFields((err, values) => {
        if (!err) {
          updateProduct(values).then(res => {
            if (res.code === '200') {
              this.$message.success('修改商品信息成功')
              this.selectedRowKeys = []
              this.selectedRows = []
              this.$refs.table.clearSelected()
              this.cancelUpdateDictModal()
              this.$refs.table.refresh(true)
            } else {
              this.$message.error(res.msg)
            }
          })
        }
      })
      // this.visibleUpdateDictModel = true
    },
    // 修改当前字典
    handleUpdateCurrentDict(record) {
      this.visibleUpdateDictModel = true
      this.$nextTick(() => {
        this.form.setFieldsValue({
          id: record.id,
          productName: record.productName,
          category: record.category,
          originalPrice: record.originalPrice,
          salePrice: record.salePrice,
          quantity: record.quantity,
          status: record.status,
          description: record.description
        })
      })
    },
    // 不显示添加字典对话框
    cancelDictModal() {
      this.visibleDictModel = false
    },
    cancelUpdateDictModal() {
      this.visibleUpdateDictModel = false
    }
  }
}
</script>
<style scoped>
.btnDelete {
  background-color: #FFEDED;
  color: #FF4949;
  border: none;
}

.btnDelete:hover {
  background-color: #FF4949;
  color: white;
}

.btnUpdate {
  margin: 20px 20px;
  background-color: #E7FAF0;
  color: #57CE66;
  border: none;
  transition: background-color 0.3s ease; /* 添加过渡效果，使背景色变化更加平滑 */
}

.btnUpdate:hover {
  background-color: #13CE66;
  color: white;
}

.btnAdd {
  background-color: #E8F4FF;
  color: #1890FF;
  border: none;
}

.btnAdd:hover {
  background-color: #1890FF;
  color: white;
}
</style>
