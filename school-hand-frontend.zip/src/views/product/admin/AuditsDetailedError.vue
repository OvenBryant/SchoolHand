<template>
  <div>
    <a-descriptions title='商品信息'>
      <a-descriptions-item span='3'>
        <div style='display: flex;gap: 20px; flex-wrap: nowrap'>
          <img style='width: 100px;height: 100px' v-for='(imageObj,index) in auditsDetailed.image' :key='index'
               :src='imageObj.url' />
        </div>
      </a-descriptions-item>
      <a-descriptions-item label='商品名称'>
        {{ auditsDetailed.productName }}
      </a-descriptions-item>
      <a-descriptions-item label='商品类型'>
        {{ auditsDetailed.category }}
      </a-descriptions-item>
      <a-descriptions-item label='个数'>
        {{ auditsDetailed.quantity }}
      </a-descriptions-item>
      <a-descriptions-item label='原价'>
        ￥{{ auditsDetailed.originalPrice }}
      </a-descriptions-item>
      <a-descriptions-item label='售价'>
        ￥{{ auditsDetailed.salePrice }}
      </a-descriptions-item>
      <a-descriptions-item label='商品描述'>
        {{ auditsDetailed.description }}
      </a-descriptions-item>
      <a-descriptions-item label='上传时间'>
        {{ auditsDetailed.productCreateTime }}
      </a-descriptions-item>
    </a-descriptions>
    <a-descriptions title='用户信息' style='margin-top:5px'>
      <a-descriptions-item label='昵称'>
        {{ auditsDetailed.nickname }}
      </a-descriptions-item>
      <a-descriptions-item label='账号'>
        {{ auditsDetailed.username }}
      </a-descriptions-item>
      <a-descriptions-item label='性别'>
        {{ auditsDetailed.sex === 1 ? '男' : '女' }}
      </a-descriptions-item>
      <a-descriptions-item label='邮箱'>
        {{ auditsDetailed.email }}
      </a-descriptions-item>
      <a-descriptions-item label='手机号'>
        {{ auditsDetailed.phone }}
      </a-descriptions-item>
      <a-descriptions-item label='注册时间'>
        {{ auditsDetailed.userCreateTime }}
      </a-descriptions-item>
    </a-descriptions>
    <a-descriptions title='未通过原因' style='margin-top:5px'>
      <a-descriptions-item label='原因'>
        {{ auditsDetailed.auditRemark }}
      </a-descriptions-item>
      <a-descriptions-item label='审核时间'>
        {{ auditsDetailed.auditTime }}
      </a-descriptions-item>
    </a-descriptions>
    <div style='margin-top: 25px'>
      <a-descriptions title='操作' />
      <a-button @click='backPendingReview'>返 回</a-button>
    </div>
  </div>
</template>

<script>
import storage from 'store'

export default {
  name: 'AuditsDetailed',
  data() {
    return {
      errorInput: '',
      auditsDetailed: {}
    }
  },
  created() {
    this.auditsDetailed = storage.get('userAdminProductAuditsDetailed') ? storage.get('userAdminProductAuditsDetailed') : null
  },
  methods: {
    backPendingReview() {
      this.$router.push({ name: 'userAdminProductAdminAuditsTabs', query: { tabId: '3' } })
    }
  }
}
</script>

<style scoped>

</style>