<template>
  <a-card>
    <a-form :form='form' @submit='handleSubmit' :label-col='{span:6}' :wrapper-col='{span:12}'>
      <a-form-item label='商品图片'>
        <div class='clearfix'>
          <a-upload
            :customRequest='customRequest'
            :beforeUpload='beforeUpload'
            list-type='picture-card'
            :file-list='fileList'
            @preview='handlePreview'
            @change='handleChange'
          >
            <div v-if='fileList.length < 2'>
              <a-icon type='plus' />
              <div class='ant-upload-text'>
                Logo
              </div>
            </div>
          </a-upload>
          <a-modal :visible='previewVisible' :footer='null' @cancel='handleCancel'>
            <img alt='example' style='width: 100%' :src='previewImage' />
          </a-modal>
        </div>
      </a-form-item>
      <a-form-item label='商品名称：'>
        <a-input
          v-decorator="[
                'productName',
            {
             rules: [
                { required: true, message: '商品名称不能为空'},
                  ],
                  validateTrigger: 'change',
                  initialValue:productForm.productName,
                },
              ]"
          placeholder='请输入商品名称'
        >
        </a-input>
      </a-form-item>
      <a-form-item label='商品类别：'>
        <a-select placeholder='类别' style='width:130px;'
                  v-decorator="['category', { rules: [{ required: true, message: '请输入商品类别名称' }] }]"
                  allowClear>
          <a-select-option
            v-for='(value,index) in dictCategoryName'
            :key='index'
            :label=value
            :value=value>
            {{ value }}
          </a-select-option>
        </a-select>
      </a-form-item>
      <a-form-item label='状态：'>
        <a-radio-group
          v-decorator="[
                'status',
            {
             rules: [
                { required: true, message:'状态不能为空' },
                  ],
                  validateTrigger: 'change',
                  initialValue:productForm.status,
                },
              ]">
          <a-radio value='1'>在售</a-radio>
          <a-radio value='2'>下架</a-radio>
        </a-radio-group>
      </a-form-item>
      <a-form-item label='商品数量：'>
        <a-input-number id='inputNumber' :min='1' :max='1000' :step='1'
                        v-decorator="['quantity', { rules: [{ required: true, message: '请输入商品数量' }],initialValue:productForm.quantity }]" />
      </a-form-item>
      <a-form-item label='商品原价：'>
        <span>￥</span>
        <a-input-number id='inputNumber' :min='1' :max='1000'
                        v-decorator="['originalPrice', { rules: [{ required: true, message: '请输入商品原价' }],initialValue:productForm.originalPrice }]" />
      </a-form-item>
      <a-form-item label='商品售价：'>
        <span>￥</span>
        <a-input-number id='inputNumber' :min='1' :max='1000'
                        v-decorator="['salePrice', { rules: [{ required: true, message: '请输入商品售价' }], initialValue:productForm.salePrice}]" />
      </a-form-item>
      <a-form-item label='商品描述'>
        <a-input
          type='textarea'
          :rows='4'
          v-decorator="[
                'description',
            {
             rules: [
                { required: true, message: '商品描述不能为空' },
                  ],
                  validateTrigger: 'change',
                  initialValue:productForm.description,
                },
              ]"
          placeholder='请输入商品描述'
        />
      </a-form-item>
      <a-form-item style='margin: 50px auto;display: flex;justify-content: center'>
        <div class='main' @click='handleSubmit' data-text='添 加' style='--c: #409EFF' />
        <div class='main' @click='handleReset' data-text='重 置'
             style='--c: #67C23A;position: relative;top:-32px;left:150px' />
        <div class='main' @click='goProductList' data-text='去商品列表'
             style='--c: #3A67C2;position: relative;bottom:64px;left:300px' />
      </a-form-item>
    </a-form>

    <avatar-modal ref='modal' @ok='setavatar' />

  </a-card>
</template>

<script>

function getBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = () => resolve(reader.result)
    reader.onerror = error => reject(error)
  })
}
import { getDictNameByCategoryId } from '@/api/dict'
import { addProduct,updateProductImg } from '@/api/product'

import AvatarModal from '@/views/product/AvatarModal'

export default {
  name: 'AddProduct',
  components: {
    AvatarModal
  },
  data() {
    return {
      previewVisible: false,
      previewImage: '',
      fileData: {},
      databaseImages: [],
      fileList: [],
      form: this.$form.createForm(this),
      formLayout: 'horizontal',
      dictCategoryName: [],
      img: require('@/assets/productIcon.png'),
      productForm: {
        productName: '',
        description: '',
        image: '',
        category: '',
        quantity: 1,
        originalPrice: 1,
        salePrice: 1,
        status: '1'
      }
    }
  },
  created() {
    getDictNameByCategoryId().then(res => {
      if (res.code === '200') {
        this.dictCategoryName = res.data
      } else {
        this.$message.error('获取字典类型错误!')
      }
    })
  },
  methods: { handleCancel() {
      this.previewVisible = false
    },
    async handlePreview(file) {
      if (!file.url && !file.preview) {
        file.preview = await getBase64(file.originFileObj)
      }
      this.previewImage = file.url || file.preview
      this.previewVisible = true
    },
    // 该方法当上传列表新增上传和删除上传项都会执行，我们可以通过状态来获取最新的fileList内容，其中状/态有loading,removed,done
    handleChange(data) {
      console.log('fileList: ', this.fileList)
      if (data.file.status === 'removed') {
        this.fileList = data.fileList
      }
    },
    customRequest(file) {
      const formData = new FormData()
      formData.append('file', file.file)
      updateProductImg(formData).then(res => {
        this.fileList.push({
          uid: this.fileList.length + 1,
          name: file.file.name,
          status: 'done',
          url: res.data
        })
      })
    },
    // 上传头像前校验
    beforeUpload(file) {
      const isJpgOrPng =
        file.type === 'image/jpeg' ||
        file.type === 'image/jpg' ||
        file.type === 'image/png'
      if (!isJpgOrPng) {
        this.$message.error('只能上传jpg/png格式的图片')
      }
      // const isLt2M = file.size / 1024 / 1024 < 2
      // if (!isLt2M) {
      //   this.$message.error('图片不得大于2MB!')
      // }
      return isJpgOrPng
    },
    setavatar(url) {
      // this.option.img = url
      this.productForm.image = url
    },
    handleReset() {
      this.form.resetFields()
      this.productForm = {}
    },
    handleSubmit(e) {
      e.preventDefault()
      this.form.validateFields((errors, values) => {
        if (!errors) {
          if (this.fileList.length < 1) {
            this.$message.error('请选择商品图片')
            return
          }
          const imagesJson = this.fileList.map(item => ({ url: item.url }))
          values.image = imagesJson
          console.log(values)
          addProduct(values).then(res => {
            if (res.code === '200') {
              this.$notification.info({ message: '操作提示', description: '新增商品成功!' })
              this.$router.push({ name: 'userAdminProductList' })
            } else {
              this.$notification.error({
                message: '操作提示',
                description: res.msg
              })
            }
          })
        }
      })
    },
    goProductList() {
      this.$router.push({ name: 'userAdminProductList' })
    }
  }
}
</script>

<style scoped>
/* 样式可以根据需要进行调整 */
.a-form-item-label {
  text-align: right;
}

.main {
  position: relative;
  width: 116px;
  height: 32px;
  background: #1890ff;
  margin-right: 20px;
  display: flex;
  flex: 1 0 auto;
  justify-content: center;
  align-items: center;
  overflow: hidden;
  border-radius: 5px;
  transition: 1s linear;
}

.main::before {
  content: '';
  width: 300px;
  height: 60px;
  background: var(--c);
  position: absolute;
  animation: roll 4s linear infinite;
  filter: blur(5px);
  transition: 1s linear;
}

.main::after {
  width: 111px;
  height: 27px;
  content: attr(data-text);
  position: absolute;
  color: rgba(0, 0, 0, 0.65);
  font-size: 14px;
  text-align: center;
  line-height: 29px;
  background: #fff;
  text-transform: uppercase;
  font-family: Arial, Helvetica, sans-serif;
  /*border-radius: 5px;*/
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  transition: 1s linear;
}

@keyframes roll {
  100% {
    transform: rotate(360deg);
    filter: blur(5px) hue-rotate(360deg);
  }
}

.main:hover {
  box-shadow: 0 0 2px var(--c);
  background: var(--c);
}

.main:hover::before {
  height: 500px;
  width: 500px;
  animation-play-state: paused;
  filter: hue-rotate(0);
}

.main:hover::after {
  background: var(--c);
  color: white;
}
</style>
