<template>
  <div>
    <a-descriptions title='商品信息'>
      <a-descriptions-item span='3'>
        <div style='display: flex;gap: 20px; flex-wrap: nowrap'>
          <img style='width: 100px;height: 100px' v-for='(imageObj,index) in auditsDetailed.image' :key='index'
               :src='imageObj.url' />
        </div>
      </a-descriptions-item>
      <a-descriptions-item label='商品名称'>
        {{ auditsDetailed.productName }}
      </a-descriptions-item>
      <a-descriptions-item label='商品类型'>
        {{ auditsDetailed.category }}
      </a-descriptions-item>
      <a-descriptions-item label='个数'>
        {{ auditsDetailed.quantity }}
      </a-descriptions-item>
      <a-descriptions-item label='原价'>
        ￥{{ auditsDetailed.originalPrice }}
      </a-descriptions-item>
      <a-descriptions-item label='售价'>
        ￥{{ auditsDetailed.salePrice }}
      </a-descriptions-item>
      <a-descriptions-item label='商品描述'>
        {{ auditsDetailed.description }}
      </a-descriptions-item>
      <a-descriptions-item label='上传时间'>
        {{ auditsDetailed.productCreateTime }}
      </a-descriptions-item>
    </a-descriptions>
    <a-descriptions title='用户信息' style='margin-top:5px'>
      <a-descriptions-item label='昵称'>
        {{ auditsDetailed.nickname }}
      </a-descriptions-item>
      <a-descriptions-item label='账号'>
        {{ auditsDetailed.username }}
      </a-descriptions-item>
      <a-descriptions-item label='性别'>
        {{ auditsDetailed.sex === 1 ? '男' : '女' }}
      </a-descriptions-item>
      <a-descriptions-item label='邮箱'>
        {{ auditsDetailed.email }}
      </a-descriptions-item>
      <a-descriptions-item label='手机号'>
        {{ auditsDetailed.phone }}
      </a-descriptions-item>
      <a-descriptions-item label='注册时间'>
        {{ auditsDetailed.userCreateTime }}
      </a-descriptions-item>
    </a-descriptions>
    <div style='margin-top: 25px'>
      <a-descriptions title='操作' />
      <a-button @click='backPendingReview'>返 回</a-button>

      <a-popconfirm
        title='是否通过这条商品?'
        ok-text='确定'
        cancel-text='取消'
        @confirm='successPop'
        @cancel='cancelPop'>
        <a-button type='primary' style='margin-left: 10px'>通 过</a-button>
      </a-popconfirm>

      <a-button type='danger' @click='notSuccess' style='margin-left: 10px'>不 通 过</a-button>
      <a-input placeholder='请输入不通过的理由' v-model='errorInput' style='width: 800px;margin-left: 10px'></a-input>
    </div>
  </div>
</template>

<script>
import storage from 'store'
import { postAuditsInfoSuccess } from '@/api/product-audits'

export default {
  name: 'AuditsDetailed',
  data() {
    return {
      errorInput: '',
      auditsDetailed: {}
    }
  },
  created() {
    this.auditsDetailed = storage.get('userAdminProductAuditsDetailed') ? storage.get('userAdminProductAuditsDetailed') : null
  },
  methods: {
    cancelPop() {
    },
    successPop() {
      postAuditsInfoSuccess('1', this.auditsDetailed).then(res => {
        if (res.code === '200') {
          this.backPendingReview()
        } else {
          this.$message.error('系统出错')
        }
      })
    },
    backPendingReview() {
      this.$router.push({ name: 'userAdminProductAdminAuditsTabs' })
    },
    notSuccess() {
      if (this.errorInput.trim() !== '') {
        this.auditsDetailed.auditRemark = this.errorInput
        postAuditsInfoSuccess('0', this.auditsDetailed).then(res => {
          if (res.code === '200') {
            this.backPendingReview()
          } else {
            this.$message.error('系统出错')
          }
        })
      } else {
        this.$notification.error({
          message: '错误提示',
          description: '请输入不通过的原因'
        })
      }
    }
  }
}
</script>

<style scoped>

</style>