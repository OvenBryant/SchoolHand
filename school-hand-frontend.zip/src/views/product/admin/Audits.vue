<template>
  <div>
    <a-select
      show-search
      placeholder='选择审核状态'
      option-filter-prop='children'
      style='width: 160px;margin-left: 5px'
      :filter-option='filterOption'
      @change='handleChangeState'
      allowClear
    >
      <a-select-option value='全部'>
        全部
      </a-select-option>
      <a-select-option value='审核中'>
        审核中
      </a-select-option>
      <a-select-option value='通过'>
        通过
      </a-select-option>
      <a-select-option value='未通过'>
        未通过
      </a-select-option>
      <a-select-option value='已撤回'>
        已撤回
      </a-select-option>
    </a-select>
    <a-input placeholder='产品名称' v-model='auditsVo.selectProductName' style='width: 200px;margin-left: 5px'
             @change='handleChangeProductName' allowClear />

    <a-table
      :row-selection='{ selectedRowKeys: selectedRowKeys, onChange: onSelectChange }'
      :columns='columns'
      :data-source='recordList'
      :rowKey='record=> record.id'
      style='margin-top: 15px'>
      <span slot='auditStatus' slot-scope='text'>
        <!-- 根据 text 的值动态决定显示哪个图标 -->
        <template v-if='text === 2'>
          <a-icon type='check-circle' theme='twoTone' two-tone-color='#52c41a' /> 通过
        </template>
        <template v-else-if='text === 3'>
          <img src='@/assets/gantanhao.png' /> 未通过
        </template>
        <template v-else-if='text === 1'>
         <a-icon type='loading' /> 审核中
        </template>
        <template v-else-if='text === 4'>
          <a-icon type='check-circle' theme='twoTone' two-tone-color='#52c41a' /> 已撤回
        </template>
        <template v-else>
          待审核
        </template>
      </span>

      <span slot='action' slot-scope='text,record'>
         <a>详情</a>
      <a-divider type='vertical' />
      <a
        v-if='record.auditStatus === 0 || record.auditStatus === 1 || record.auditStatus === 2 || record.auditStatus === 4'>修改</a>
      <a v-else>查看原因并修改</a>
      <a-divider type='vertical' />
      <a>删除</a>
      </span>
    </a-table>
    <div style='margin-top: -50px'>
      <a-button type='primary' :disabled='!hasSelected'>
        删除
      </a-button>
    </div>
  </div>
</template>

<script>
import { getAuditsList } from '@/api/product-audits'

const columns = [
  {
    title: '产品名称',
    dataIndex: 'productName'
  },
  {
    title: '商品类别',
    dataIndex: 'category'
  },
  {
    title: '审核状态',
    dataIndex: 'auditStatus',
    scopedSlots: { customRender: 'auditStatus' }
  },
  {
    title: '创建时间',
    dataIndex: 'createTime',
    width: 180,
    align: 'center'
  },
  {
    title: '操作',
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  name: 'UserAuditingStatus',
  data() {
    return {
      columns,
      auditsVo: {
        selectProductName: '',
        selectAuditsStatus: ''
      },
      selectedRowKeys: [],
      recordList: []
    }
  },
  created() {
    this.getList()
  },
  computed: {
    hasSelected() {
      return this.selectedRowKeys.length > 0
    }
  },
  methods: {
    getList() {
      getAuditsList(this.auditsVo).then(res => {
        if (res.code === '200') {
          this.recordList = res.data
          console.log('recordList: ', res.data)
        } else {
          this.$message.error('当前审核信息异常')
        }
      })
    },
    handleChangeState(value) {
      this.auditsVo.selectAuditsStatus = value
      this.getList()
    },
    handleChangeProductName() {
      this.getList()
    },
    filterOption(input, option) {
      return (
        option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0
      )
    },
    onSelectChange(selectedRowKeys) {
      console.log('selectedRowKeys changed: ', selectedRowKeys)
      this.selectedRowKeys = selectedRowKeys
    },
    // 上传物品
    uploadGoods() {
      this.$emit('change-tab', '1')
      // 触发自定义事件并传递要激活的标签页的 key
      // this.$router.push({ name: 'userAdminProductAdd' })
    }
  }
}
</script>

<style scoped>

</style>