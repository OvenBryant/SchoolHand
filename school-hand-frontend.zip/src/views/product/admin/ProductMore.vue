<template>
  <div style='width: 1000px'>
    <a-descriptions title='商品详细信息' bordered columnCount='1'>
      <a-descriptions-item label='图片' span='3'>
        <div style='display: flex;gap: 20px; flex-wrap: nowrap'>
          <img style='width: 100px;height: 100px' v-for='(imageObj,index) in productMore.image' :key='index' :src='imageObj.url' />
        </div>
      </a-descriptions-item>
      <a-descriptions-item label='商品名称' span='1'>
        {{ productMore.productName }}
      </a-descriptions-item>
      <a-descriptions-item label='商品类别' span='1'>
        {{ productMore.category }}
      </a-descriptions-item>
      <a-descriptions-item label='原价' span='1'>
        ￥{{ productMore.originalPrice }}
      </a-descriptions-item>
      <a-descriptions-item label='售价' span='1'>
        ￥{{ productMore.salePrice }}
      </a-descriptions-item>
      <a-descriptions-item label='商品个数' span='1'>
        {{ productMore.quantity }}
      </a-descriptions-item>
      <a-descriptions-item label='状态' span='1'>
        {{ getStauts(productMore.status) }}
      </a-descriptions-item>
      <a-descriptions-item label='上架时间' span='2'>
        {{ productMore.createTime }}
      </a-descriptions-item>
      <a-descriptions-item label='更新时间' span='2'>
        {{ productMore.updateTime }}
      </a-descriptions-item>
      <a-descriptions-item label='商品描述' span='3'>
        {{ productMore.description }}
      </a-descriptions-item>
      <a-descriptions-item label='上传者' span='1'>
        {{ productMore.username }}
      </a-descriptions-item>
      <a-descriptions-item label='用户昵称' span='1'>
        {{ productMore.nickname }}
      </a-descriptions-item>
      <a-descriptions-item label='性别' span='1'>
        {{ getGender(productMore.sex) }}
      </a-descriptions-item>
      <a-descriptions-item label='邮箱' span='1'>
        {{ productMore.email }}
      </a-descriptions-item>
      <a-descriptions-item label='手机号' span='1'>
        {{ productMore.phone }}
      </a-descriptions-item>
    </a-descriptions>
    <div style='text-align: center;margin-top: 30px;'>
      <a-button type='primary' style='width: 200px' @click="$router.push('/userAdminProduct/list')">返 回</a-button>
    </div>
  </div>
</template>

<script>
import storage from 'store'

export default {
  name: 'ProductMore',
  data() {
    return {
      productMore: {}
    }
  },
  created() {
    this.productMore = storage.get('currentProductMore') ? storage.get('currentProductMore') : null
    // console.log(this.$route.params.productMore)
    // console.log('商品详细信息')
    // this.productMore = this.$route.params.productMore;
  },
  methods: {
    getGender(sex) {
      // 根据性别数字返回对应的文字
      return sex === '0' ? '女' : '男'
    },
    getStauts(status) {
      return status === 1 ? '在售' : '下架'
    }
  }
}
</script>

<style scoped>


</style>