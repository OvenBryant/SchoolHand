<template>
  <div>
    <a-descriptions title='商品信息'>
      <a-descriptions-item span='3'>
        <div style='display: flex;gap: 20px; flex-wrap: nowrap'>
          <img style='width: 100px;height: 100px' v-for='(imageObj,index) in auditsDetailed.image' :key='index'
               :src='imageObj.url' />
        </div>
      </a-descriptions-item>
      <a-descriptions-item label='商品名称'>
        {{ auditsDetailed.productName }}
      </a-descriptions-item>
      <a-descriptions-item label='商品类型'>
        {{ auditsDetailed.category }}
      </a-descriptions-item>
      <a-descriptions-item label='个数'>
        {{ auditsDetailed.quantity }}
      </a-descriptions-item>
      <a-descriptions-item label='原价'>
        ￥{{ auditsDetailed.originalPrice }}
      </a-descriptions-item>
      <a-descriptions-item label='售价'>
        ￥{{ auditsDetailed.salePrice }}
      </a-descriptions-item>
      <a-descriptions-item label='商品描述'>
        {{ auditsDetailed.description }}
      </a-descriptions-item>
      <a-descriptions-item label='上传时间'>
        {{ auditsDetailed.createTime }}
      </a-descriptions-item>
    </a-descriptions>
    <div style='margin-top: 25px'>
      <a-descriptions title='操作' />
      <a-button @click='backPendingReview'>返 回</a-button>
    </div>
  </div>
</template>

<script>
import storage from 'store'

export default {
  name: 'UserPubProductAuditsDetailed',
  data() {
    return {
      errorInput: '',
      auditsDetailed: {}
    }
  },
  created() {
    this.auditsDetailed = storage.get('userPubProductAuditsDetailed') ? storage.get('userPubProductAuditsDetailed') : null
  },
  methods: {
    backPendingReview() {
       this.$router.push({ name: 'userAdminProductAdd', query: { tabId: '2' } })
    },
  }
}
</script>

<style scoped>

</style>
