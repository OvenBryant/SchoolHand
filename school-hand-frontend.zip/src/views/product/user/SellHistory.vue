<template>
  <div>
    <a-card :body-style='{ padding: 0, margin: 0 }' style='margin-top: 10px' v-for='item in listProduct' :key='item.id'>
      <a-row>
        <a-col :span='3'>
          <img :src='item.image[0].url' style='width: 100px;height: 100px'>
        </a-col>
        <a-col :span='21'>
          <a-row style='margin-top: 5px'>
            名称：<span style='margin-right: 10px;color: green'>{{ item.productName }}</span>
            价格: <span style='color: red;margin-right: 10px'>￥{{ item.salePrice }}</span>
            原价: <span style='color: red;text-decoration: line-through'>￥{{ item.originalPrice }}</span>
          </a-row>
          <a-row>
            <span class='ellipsis'>{{ item.description }}</span>
          </a-row>
          <a-row>
            <span>购买日期：{{ item.createTime }}</span>
          </a-row>
        </a-col>
      </a-row>
    </a-card>
  </div>
</template>

<script>

import { getHistory } from '@/api/product-man'

export default {
  name: 'SellHistory',
  data() {
    return {
      listProduct: []
    }
  },
  mounted() {
    this.listData()
  },
  methods: {
    listData() {
      getHistory().then(res => {
        this.listProduct = res.data
      }).catch(err => {
        console.log(err)
      })
    },
    deleteRow(id) {

    },
    cancelDelPop() {

    }
  }
}
</script>

<style scoped>
.ellipsis {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  color: #9B9B9B;
  -webkit-box-orient: vertical;
  overflow: hidden;
  font-size: 12px;
  text-overflow: ellipsis;
  line-height: 1.5;
  height: 3em;
  margin-top: 7px;
}
</style>