<template>
  <a-tabs :default-active-key='activeTabKey' v-model='activeTabKey'>
    <a-tab-pane key='1'>
      <span slot='tab'>
        <img src='@/assets/myProductIcon.png' />
        我的商品
      </span>
      <MyProduct />
    </a-tab-pane>
    <a-tab-pane key='2'>
      <span slot='tab'>
       <img src='@/assets/history.png' />
        购买历史
      </span>
      <SellHistory/>
    </a-tab-pane>
    <a-tab-pane key='3'>
      <span slot='tab'>
       <img src='@/assets/cart.png' />
        购物车
      </span>
      <ShoppingCart2/>
    </a-tab-pane>
  </a-tabs>
</template>

<script>

import MyProduct from '@/views/product/user/MyProduct'
import ShoppingCart2 from '@/views/product/user/ShoppingCart2'
import SellHistory from '@/views/product/user/SellHistory'

export default {
  components: {
    MyProduct, ShoppingCart2, SellHistory
  },
  name: 'MyProductTabs',
  data() {
    return {
      activeTabKey: '1'
    }
  },
  computed: {
    computedActiveTabKey() {
      return this.activeTabKey
    }
  },
  methods:{
    handleTabChange(newTabKey) {
      // console.log('newTabKey: ',newTabKey)
      this.activeTabKey = newTabKey
    }
  }
}
</script>

<style scoped>

</style>