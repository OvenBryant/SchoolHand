<template>
  <div>
    <a-button type='primary' @click='uploadGoods'>上传物品</a-button>
    <a-select
      show-search
      placeholder='选择审核状态'
      option-filter-prop='children'
      style='width: 160px;margin-left: 5px'
      :filter-option='filterOption'
      @change='handleChangeState'
      allowClear
    >
      <a-select-option value='全部'>
        全部
      </a-select-option>
      <a-select-option value='待审核'>
        待审核
      </a-select-option>
      <a-select-option value='通过'>
        通过
      </a-select-option>
      <a-select-option value='未通过'>
        未通过
      </a-select-option>
    </a-select>
    <a-input placeholder='产品名称' v-model='auditsVo.selectProductName' style='width: 200px;margin-left: 5px'
             @change='handleChangeProductName' allowClear />

    <a-table
      v-if='recordList.length > 0 '
      :row-selection='{ selectedRowKeys: selectedRowKeys, onChange: onSelectChange }'
      :columns='columns'
      :data-source='recordList'
      :rowKey='record=> record.id'
      style='margin-top: 15px'>
      <span slot='auditStatus' slot-scope='text'>
        <!-- 根据 text 的值动态决定显示哪个图标 -->
        <template v-if='text === 2'>
          <a-icon type='check-circle' theme='twoTone' two-tone-color='#52c41a' /> 通过
        </template>
        <template v-else-if='text === 3'>
          <img src='@/assets/gantanhao.png' /> 未通过
        </template>
        <template v-else-if='text === 4'>
          <a-icon type='check-circle' theme='twoTone' two-tone-color='#52c41a' /> 已撤回
        </template>
        <template v-else>
          <img src='@/assets/auditing.png' style='width: 25px;height: 25px' />待审核
        </template>
      </span>

      <span slot='action' slot-scope='text,record'>
         <a style='margin-right: 20px' @click='userAuditsDetailed(record)'>详情</a>
        <!--      <a-divider type='vertical' />-->
      <a @click='updateAudits(record)' v-if='record.auditStatus === 1 || record.auditStatus === 2 || record.auditStatus === 4'>修改</a>
      <a v-if='record.auditStatus === 3' @click='updateError(record)'>查看原因并修改</a>
        <!--      <a-divider type='vertical' />-->
         <a-popconfirm
           title='删除后不能恢复!'
           ok-text='确定'
           cancel-text='取消'
           @confirm='successPop'
           @cancel='cancelPop'>
              <a v-if='record.auditStatus!==0' style='margin-left: 20px'>删除</a>
      </a-popconfirm>
      </span>
    </a-table>

    <a-result v-else title='空' />
    <div style='margin-top: -50px'>
      <a-button type='primary' :disabled='!hasSelected'>
        删除
      </a-button>
    </div>
  </div>
</template>

<script>
import { getAuditsList } from '@/api/product-audits'
import storage from 'store'

const columns = [
  {
    title: '产品名称',
    dataIndex: 'productName'
  },
  {
    title: '商品类别',
    dataIndex: 'category'
  },
  {
    title: '审核状态',
    dataIndex: 'auditStatus',
    scopedSlots: { customRender: 'auditStatus' }
  },
  {
    title: '创建时间',
    dataIndex: 'createTime',
    width: 180,
    align: 'center'
  },
  {
    title: '操作',
    scopedSlots: { customRender: 'action' }
  }
]
export default {
  name: 'UserAuditingStatus',
  data() {
    return {
      columns,
      auditsVo: {
        selectProductName: '',
        selectAuditsStatus: ''
      },
      selectedRowKeys: [],
      recordList: []
    }
  },
  created() {
    this.getList()
  },
  computed: {
    hasSelected() {
      return this.selectedRowKeys.length > 0
    }
  },
  methods: {
    getList() {
      getAuditsList(this.auditsVo).then(res => {
        if (res.code === '200') {
          this.recordList = res.data
        } else {
          this.$message.error('当前审核信息异常')
        }
      })
    },
    userAuditsDetailed(record) {
      storage.set('userPubProductAuditsDetailed', record, new Date().getTime() + 7 * 24 * 60 * 60 * 1000)
      // this.$router.push({ name: 'userAdminProductMore', params: { productMore: record } })
      this.$router.push({ name: 'userPubProductAuditsDetailed' })
    },
    // 修改
    updateAudits(record){
      storage.set('userUpdateAuditsStatus', record, new Date().getTime() + 7 * 24 * 60 * 60 * 1000)
      this.$router.push({ name: 'userUpdateAuditsStatus' })
    },
    // 查看原因并修改
    updateError(record) {
      // this.$notification.error({
      //   message: '查看原因并修改',
      //   description: record.auditRemark
      // })
      storage.set('userUpdateAuditsStatus', record, new Date().getTime() + 7 * 24 * 60 * 60 * 1000)
      this.$router.push({ name: 'userUpdateAuditsStatus' })
    },
    cancelPop(){

    },
    successPop(){

    },
    handleChangeState(value) {
      this.auditsVo.selectAuditsStatus = value
      this.getList()
    },
    handleChangeProductName() {
      this.getList()
    },
    filterOption(input, option) {
      return (
        option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0
      )
    },
    onSelectChange(selectedRowKeys) {
      console.log('selectedRowKeys changed: ', selectedRowKeys)
      this.selectedRowKeys = selectedRowKeys
    },
    // 上传物品
    uploadGoods() {
      this.$emit('change-tab', '1')
      // 触发自定义事件并传递要激活的标签页的 key
      // this.$router.push({ name: 'userAdminProductAdd' })
    }
  }
}
</script>

<style scoped>

</style>