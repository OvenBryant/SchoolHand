<template>
  <div>
    <a-card style='height: 50px;background-color: #FAFAFA'>
      <span
        style='font-weight: bolder;font-size: 20px;margin-top:-15px;display: flex;align-content: center;justify-content: center'>我 的 购 物 车</span>
    </a-card>

    <a-card :body-style='{ padding: 0, margin: 0 }' style='margin-top: 10px' v-for='item in cartList'
            :key='item.cartId'>
      <a-row>
        <a-col :span='3'>
          <img :src='item.image[0].url' style='width: 100px;height: 100px'>
        </a-col>
        <a-col :span='21'>
          <a-row style='margin-top: 5px'>
            名称：<span style='margin-right: 10px;color: green'>{{ item.productName }}</span>
            价格: <span style='color: red'>￥{{ item.salePrice }}</span>
          </a-row>
          <a-row>
            <span class='ellipsis'>{{ item.description }}</span>
          </a-row>
          <a-row>
            状态：<span
            :style="{ color: item.status === 1 ? 'green' : 'red'}">{{ item.status === 1 ? '正在出售' : '已售完'
            }} </span>
            <a-divider type='vertical' />
            <span>上架日期：{{ item.createTime }}</span>
            <a-button type='primary' @click='myBuy(item)' style='margin-left: 400px;height: 28px'>购买</a-button>
            <a-divider type='vertical' />
            <a-popconfirm
              ok-text='确定'
              cancel-text='取消'
              @confirm='deleteRow(item.cartId)'
              @cancel='cancelDelPop'>
              <template slot='title'>
                <p>是否确认删除购物车中名称为 【{{ item.productName }}】 的数据项?</p>
              </template>
              <a-button type='danger' style='height: 28px'>删除</a-button>
            </a-popconfirm>
          </a-row>
        </a-col>
      </a-row>
    </a-card>
  </div>
</template>

<script>
import storage from 'store'
import { deleteCartById, getUserAddress, listProductCart, ljBuy } from '@/api/product-man'


export default {
  name: 'ShoppingCart',
  data() {
    return {
      currentGoodShoppingCart: {},
      cartList: [],
      buyData: {
        userId: 0,
        productId: 0,
        building: 1,
        floor: 1,
        roomNumber: 1,
        fullAddress: ''
      }
    }
  },
  mounted() {
    this.currentGoodShoppingCart = storage.get('currentGoodAddShoppingCart') ? storage.get('currentGoodAddShoppingCart') : this.$route.params.item
    this.getAddress()
    this.getList()
  },
  methods: {
    getList() {
      listProductCart().then(res => {
        if (res.code === '200') {
          this.cartList = res.data
        } else {
          this.$message.error('当前购物车有误!')
        }
      }).catch(err => {
        console.log(err)
      })
    },
    deleteRow(id) {
      deleteCartById(id).then(res => {
        if (res.code === '200') {
          this.$message.success('删除成功')
          this.getList()
        } else {
          this.$message.success('删除失败')
        }
      }).catch(err => {
        console.log(err)
      })
    },
    cancelDelPop() {

    },
    getAddress() {
      getUserAddress().then(res => {
        if (res.code === '200') {
          this.buyData.building = res.data.building
          this.buyData.floor = res.data.floor
          this.buyData.roomNumber = res.data.roomNumber
          this.buyData.fullAddress = res.data.fullAddress
        }
      })
    },
    myBuy(item) {
      this.buyData.userId = item.proUserId
      this.buyData.productId = item.id
      ljBuy(this.buyData).then(res => {
        if (res.code === '200') {
          this.getList()
          // this.$router.push({ name: 'userAdminProductBuy' })
          this.$notification.success({
            message: '操作提示',
            description: '购买成功'
          })
        } else {
          this.$notification.error({
            message: '操作提示',
            description: res.msg
          })
        }
      })
    }
  }
}
</script>

<style scoped>
.ellipsis {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  color: #9B9B9B;
  -webkit-box-orient: vertical;
  overflow: hidden;
  font-size: 12px;
  text-overflow: ellipsis;
  line-height: 1.5;
  height: 3em;
  margin-top: 7px;
}
</style>