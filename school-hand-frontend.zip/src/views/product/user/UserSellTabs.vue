<template>
  <a-tabs :default-active-key='activeTabKey' v-model='activeTabKey'>
    <a-tab-pane key='1'>
      <span slot='tab'>
        <img src='@/assets/upload.png' />
        上传物品
      </span>
      <UserSell />
    </a-tab-pane>
    <a-tab-pane key='2'>
      <span slot='tab'>
       <img src='@/assets/auditing.png' />
        审核状态
      </span>
      <UserAuditingStatus @change-tab='handleTabChange' />
    </a-tab-pane>
  </a-tabs>
</template>

<script>
import UserSell from '@/views/product/user/UserSell'
import UserAuditingStatus from '@/views/product/user/UserAuditingStatus'

export default {
  components: {
    UserSell, UserAuditingStatus
  },
  name: 'UserSellTabs',
  data() {
    return {
      activeTabKey: '1'
    }
  },
  created() {
    const tabIdData = this.$route.query.tabId ? this.$route.query.tabId : '1'
    this.activeTabKey = tabIdData
  },
  computed: {
    computedActiveTabKey() {
      return this.activeTabKey
    }
  },
  methods: {
    handleTabChange(newTabKey) {
      // console.log('newTabKey: ',newTabKey)
      this.activeTabKey = newTabKey
    }
  }
}
</script>

<style scoped>

</style>