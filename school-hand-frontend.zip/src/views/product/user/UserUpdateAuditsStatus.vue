<template>
  <a-card>
    <div style='height: 100px;background-color: #FCEBEA'
         v-if='productDetailed.auditRemark!="" && productDetailed.auditRemark !=null'>
      <a-row>
        <img src='@/assets/auditserror.png' />
        <span style='margin-left: 10px;color: #D93026;font-weight: bolder;font-size: 20px'>审核意见</span>
      </a-row>
      <a-row>
        <span style='margin-left: 43px;color: #D93026'>{{ productDetailed.auditTime }}</span>
        <span style='margin-left: 5px;color: #D93026'>{{ productDetailed.auditRemark }}</span>
      </a-row>
    </div>

    <a-form style='margin-top: 20px' :form='form' @submit='handleSubmit' :label-col='{span:6}' :wrapper-col='{span:12}'>
      <a-form-item label='商品图片'>
        <div class='clearfix'>
          <a-upload
            :customRequest='customRequest'
            :beforeUpload='beforeUpload'
            list-type='picture-card'
            :file-list='fileList'
            @preview='handlePreview'
            @change='handleChange'
          >
            <div v-if='fileList.length < 2'>
              <a-icon type='plus' />
              <div class='ant-upload-text'>
                Logo
              </div>
            </div>
          </a-upload>
          <a-modal :visible='previewVisible' :footer='null' @cancel='handleCancel'>
            <img alt='example' style='width: 100%' :src='previewImage' />
          </a-modal>
        </div>
      </a-form-item>
      <a-form-item label='商品名称：'>
        <a-input
          v-decorator="[
                'productName',
            {
             rules: [
                { required: true, message: '商品名称不能为空'},
                  ],
                  validateTrigger: 'change',
                  initialValue:productForm.productName,
                },
              ]"
          placeholder='请输入商品名称'
        >
        </a-input>
      </a-form-item>
      <a-form-item label='商品类别：'>
        <a-select placeholder='类别' style='width:130px;'
                  v-decorator="['category', { rules: [{ required: true, message: '请输入商品类别名称' }],initialValue:productForm.category },]"
                  allowClear>
          <a-select-option
            v-for='(value,index) in dictCategoryName'
            :key='index'
            :label=value
            :value=value>
            {{ value }}
          </a-select-option>
        </a-select>
      </a-form-item>
      <a-form-item label='商品数量：'>
        <a-input-number id='inputNumber' :min='1' :max='1000' :step='1'
                        v-decorator="['quantity', { rules: [{ required: true, message: '请输入商品数量' }],initialValue:productForm.quantity }]" />
      </a-form-item>
      <a-form-item label='商品原价：'>
        <span>￥</span>
        <a-input-number id='inputNumber' :min='1' :max='1000'
                        v-decorator="['originalPrice', { rules: [{ required: true, message: '请输入商品原价' }],initialValue:productForm.originalPrice }]" />
      </a-form-item>
      <a-form-item label='商品售价：'>
        <span>￥</span>
        <a-input-number id='inputNumber' :min='1' :max='1000'
                        v-decorator="['salePrice', { rules: [{ required: true, message: '请输入商品售价' }], initialValue:productForm.salePrice}]" />
      </a-form-item>
      <a-form-item label='商品描述'>
        <a-input
          type='textarea'
          :rows='4'
          v-decorator="[
                'description',
            {
             rules: [
                { required: true, message: '商品描述不能为空' },
                  ],
                  validateTrigger: 'change',
                  initialValue:productForm.description,
                },
              ]"
          placeholder='请输入商品描述'
        />
      </a-form-item>
      <a-form-item style='margin: 50px auto;display: flex;justify-content: center'>
        <div class='main' @click='handleSubmit' data-text='提 交' style='--c: #409EFF' />
        <div class='main' @click='handleReset' data-text='重 置'
             style='--c: #67C23A;position: relative;top:-32px;left:150px' />
        <div class='main' @click='goUserPubAudits' data-text='取 消'
             style='--c: #3A67C2;position: relative;bottom:64px;left:300px' />
      </a-form-item>
    </a-form>

    <avatar-modal ref='modal' @ok='setavatar' />

  </a-card>
</template>

<script>

import storage from 'store'

function getBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = () => resolve(reader.result)
    reader.onerror = error => reject(error)
  })
}

import { getDictNameByCategoryId } from '@/api/dict'
import { updateProductImg } from '@/api/product'

import AvatarModal from '@/views/product/AvatarModal'
import { addProductRecord } from '@/api/product-record'

export default {
  name: 'UserUpdateAuditsStatus',
  components: {
    AvatarModal
  },
  data() {
    return {
      previewVisible: false,
      previewImage: 'https://bs-api-oss.oss-cn-wulanchabu.aliyuncs.com/2024/04/21/e534cf5aed61493bb8be00f04d93da66薯片1.png',
      fileData: {},
      databaseImages: [],
      fileList: [],
      form: this.$form.createForm(this),
      formLayout: 'horizontal',
      dictCategoryName: [],
      img: require('@/assets/productIcon.png'),
      productForm: {
        productName: '',
        description: '',
        image: '',
        category: '',
        quantity: 1,
        originalPrice: 1,
        salePrice: 1,
        status: '1'
      },
      // 修改审核信息
      productDetailed: {}
    }
  },
  created() {
    this.productDetailed = storage.get('userUpdateAuditsStatus') ? storage.get('userUpdateAuditsStatus') : null
    this.productForm.productName = this.productDetailed.productName
    this.productForm.description = this.productDetailed.description
    this.productForm.category = this.productDetailed.category
    this.productForm.quantity = this.productDetailed.quantity
    this.productForm.originalPrice = this.productDetailed.originalPrice
    this.productForm.salePrice = this.productDetailed.salePrice
    this.productForm.category = this.productDetailed.category

    const countImg = this.productDetailed.image.length
    for (let i = 0; i < countImg; i++) {
      this.fileList.push({
        uid: `-${i + 1}`,
        name: `image${i + 1}.png`,
        status: 'done',
        url: this.productDetailed.image[i].url
      })
    }

    getDictNameByCategoryId().then(res => {
      if (res.code === '200') {
        this.dictCategoryName = res.data
      } else {
        this.$message.error('获取字典类型错误!')
      }
    })
  },
  methods: {
    handleCancel() {
      this.previewVisible = false
    },
    async handlePreview(file) {
      if (!file.url && !file.preview) {
        file.preview = await getBase64(file.originFileObj)
      }
      this.previewImage = file.url || file.preview
      this.previewVisible = true
    },
    // 该方法当上传列表新增上传和删除上传项都会执行，我们可以通过状态来获取最新的fileList内容，其中状/态有loading,removed,done
    handleChange(data) {
      console.log('fileList: ', this.fileList)
      if (data.file.status === 'removed') {
        this.fileList = data.fileList
      }
    },
    customRequest(file) {
      const formData = new FormData()
      formData.append('file', file.file)
      updateProductImg(formData).then(res => {
        this.fileList.push({
          uid: this.fileList.length + 1,
          name: file.file.name,
          status: 'done',
          url: res.data
        })
      })
    },
    // 上传头像前校验
    beforeUpload(file) {
      const isJpgOrPng =
        file.type === 'image/jpeg' ||
        file.type === 'image/jpg' ||
        file.type === 'image/png'
      if (!isJpgOrPng) {
        this.$message.error('只能上传jpg/png格式的图片')
      }
      // const isLt2M = file.size / 1024 / 1024 < 2
      // if (!isLt2M) {
      //   this.$message.error('图片不得大于2MB!')
      // }
      return isJpgOrPng
    },
    setavatar(url) {
      // this.option.img = url
      this.productForm.image = url
    },
    handleReset() {
      this.form.resetFields()
      this.productForm = {}
    },
    handleSubmit(e) {
      this.$message.error('开发中...')
    },
    goUserPubAudits() {
      this.$router.push({ name: 'userAdminProductAdd', query: { tabId: '2' } })
    }
  }
}
</script>

<style scoped>
/* 样式可以根据需要进行调整 */
.a-form-item-label {
  text-align: right;
}

.main {
  position: relative;
  width: 116px;
  height: 32px;
  background: #1890ff;
  margin-right: 20px;
  display: flex;
  flex: 1 0 auto;
  justify-content: center;
  align-items: center;
  overflow: hidden;
  border-radius: 5px;
  transition: 1s linear;
}

.main::before {
  content: '';
  width: 300px;
  height: 60px;
  background: var(--c);
  position: absolute;
  animation: roll 4s linear infinite;
  filter: blur(5px);
  transition: 1s linear;
}

.main::after {
  width: 111px;
  height: 27px;
  content: attr(data-text);
  position: absolute;
  color: rgba(0, 0, 0, 0.65);
  font-size: 14px;
  text-align: center;
  line-height: 29px;
  background: #fff;
  text-transform: uppercase;
  font-family: Arial, Helvetica, sans-serif;
  /*border-radius: 5px;*/
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  transition: 1s linear;
}

@keyframes roll {
  100% {
    transform: rotate(360deg);
    filter: blur(5px) hue-rotate(360deg);
  }
}

.main:hover {
  box-shadow: 0 0 2px var(--c);
  background: var(--c);
}

.main:hover::before {
  height: 500px;
  width: 500px;
  animation-play-state: paused;
  filter: hue-rotate(0);
}

.main:hover::after {
  background: var(--c);
  color: white;
}
</style>
