<template>
  <div>
    <a-card>
      <a-form layout='inline'>
        <a-row>
          <a-col :span='24'>
            <a-form-item label='商品名称' style='font-weight: bold'>
              <a-input type='text' style='width:200px;' v-model='queryParams.productName'
                       placeholder='请输入商品名称' allowClear @change='showChange()' />
            </a-form-item>
            <a-form-item label='商品类别' style='font-weight: bold;margin-left: 20px'>
              <a-select v-model='queryParams.category' placeholder='类别' style='width:130px;' allowClear
                        @change='showChange()'>
                <a-select-option
                  v-for='(value,index) in dictCategoryName'
                  :key='index'
                  :label=value
                  :value=value>
                  {{ value }}
                </a-select-option>
              </a-select>
            </a-form-item>
            <a-button icon='reload' type='danger' @click='resetChange' style='margin-left:15px'>重置</a-button>
          </a-col>
        </a-row>
      </a-form>
    </a-card>
    <a-divider />
    <a-row v-if='productListData.length > 0'>
      <a-col v-for='(item, rowIndex) in productListData' :key='rowIndex' :span='4' style='margin:10px 10px 0 20px'>
        <a-card :body-style='{padding:0,margin:0}' style='height: 320px;width: 220px;' @click='goodsClick(item)'>
          <img
            slot='cover'
            alt='example'
            :src='item.image[0].url'
            style='width: 220px;height: 200px'
          />
          <span class='ellipsis'>{{ item.description }}</span>
          <span style='font-size: 22px;color:red'>￥ {{ item.salePrice }}</span><br />
          <img src='@/assets/goodsIcon.png' />
          <span style='font-size: 15px;color:#9B9B9B;margin-left: 10px;'>{{ item.productName }}</span>
        </a-card>
      </a-col>
    </a-row>
    <a-result v-else title='没有该物品!' />

    <!--    <a-row style='margin-top: 5px' v-for="(item, rowIndex) in productListData" :key="rowIndex" :gutter="5" v-if="rowIndex % 6 === 0">-->
    <!--      <a-col v-for="(ignored, colIndex) in Array(6)" :key="colIndex + rowIndex * 6" :span="4">-->
    <!--        <a-card  hoverable v-if="rowIndex + colIndex < productListData.length" style='width: 220px;margin-top: 15px'>-->
    <!--          <img-->
    <!--            slot="cover"-->
    <!--            alt="example"-->
    <!--            :src="productListData[rowIndex + colIndex].image[0].url"-->
    <!--            style='width: 220px;height: 200px'-->
    <!--          />-->
    <!--          <a-card-meta :title="productListData[rowIndex + colIndex].productName">-->
    <!--            <template slot="description">-->
    <!--              售价: {{ productListData[rowIndex + colIndex].salePrice }}-->
    <!--            </template>-->
    <!--          </a-card-meta>-->
    <!--        </a-card>-->
    <!--      </a-col>-->
    <!--    </a-row>-->

  </div>
</template>

<script>
import { getlistProductPage } from '@/api/product'
import { getDictNameByCategoryId } from '@/api/dict'
import storage from 'store'

export default {
  name: 'Buy',
  data() {
    return {
      form: this.$form.createForm(this, { name: 'coordinated' }),
      queryParams: {
        productName: undefined,
        category: undefined
      },
      dictCategoryName: [],
      productListData: []
    }
  },
  created() {
    this.getDictName()
    this.getProductData()
  },
  methods: {
    // 获取字典数据
    getDictName() {
      getDictNameByCategoryId().then(res => {
        if (res.code === '200') {
          this.dictCategoryName = res.data
        } else {
          this.$message.error('获取字典类型异常!')
        }
      })
    },
    // 获取可以售出的物品数据
    getProductData() {
      getlistProductPage(this.queryParams)
        .then((res) => {
          this.productListData = res.data.records
          console.log(res.data)
        })
        .catch((error) => {
          console.log(error)
        })
    },
    // 单个物品的点击事件
    goodsClick(currentGood) {
      storage.set('currentGood', currentGood, new Date().getTime() + 7 * 24 * 60 * 60 * 1000)
      this.$router.push({ name: 'userAdminProductBuyMore', params: { item: currentGood } })
    },
    // 昵称 输入框内容变化时的回调
    showChange() {
      this.getProductData()
      // this.$refs.table.refresh(true)
    },
    // 重置
    resetChange() {
      this.queryParams = {}
      this.getProductData()
    },
    // 更多商品
    handleMoreProduct(record) {
      // 点击查看商品详情
      // this.$router.push({ name: 'userAdminEditUser', params: { userId: 123 } });

      storage.set('currentProductMore', record, new Date().getTime() + 7 * 24 * 60 * 60 * 1000)
      // this.$router.push({ name: 'userAdminProductMore', params: { productMore: record } })
      this.$router.push({ name: 'userAdminProductMore' })
    }
  }
}
</script>
<style scoped>
.btnDelete {
  background-color: #FFEDED;
  color: #FF4949;
  border: none;
}

.btnDelete:hover {
  background-color: #FF4949;
  color: white;
}

.btnUpdate {
  margin: 20px 20px;
  background-color: #E7FAF0;
  color: #57CE66;
  border: none;
  transition: background-color 0.3s ease; /* 添加过渡效果，使背景色变化更加平滑 */
}

.btnUpdate:hover {
  background-color: #13CE66;
  color: white;
}

.btnAdd {
  background-color: #E8F4FF;
  color: #1890FF;
  border: none;
}

.btnAdd:hover {
  background-color: #1890FF;
  color: white;
}

.ellipsis {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  color: #9B9B9B;
  -webkit-box-orient: vertical;
  overflow: hidden;
  font-size: 18px;
  text-overflow: ellipsis;
  margin-top: 7px;
  line-height: 1.5; /* 根据你的字体大小调整行高 */
  height: 3em; /* 两行的高度，假设你的行高是1.5，那么两行就是3em */
  /* 为了确保内容居中，可以添加一些额外的样式 */
}

/*.ellipsis {*/
/*  display: -webkit-box;*/
/*  -webkit-box-orient: vertical;*/
/*  -webkit-line-clamp: 2;*/
/*  overflow: hidden;*/
/*  text-overflow: ellipsis;*/
/*  font-size: 18px;*/
/*  color: #9B9B9B;*/
/*  margin-top: 7px;*/
/*  line-height: 1.5; !* 假设行高是1.5 *!*/
/*  max-height: 3em; !* 两行的高度，18px * 1.5 * 2 *!*/
/*}*/


</style>
