<template>
  <div>
    <a-card style='border-radius: 80px;height:80px;overflow: hidden;'>
      <a-row>
        <a-col :span='20' style='margin-top: -10px'>
          <img style='border-radius: 50%;width: 50px;' src='@/assets/good.png' />
          <span style='font-size: 15px;margin-left: 10px'>商品详情</span>
          <span style='font-size: 17px;margin-left: 17px;font-weight: bolder'>{{ currentGood.category }}</span>
          <a-divider type='vertical' />
          <span style='font-size: 17px;font-weight: bolder'>{{ currentGood.productName }}</span>
        </a-col>
        <a-col :span='4'>
          <a-button shape='round' @click='contactSellClick'>
            <img src='@/assets/contactsell.png'
                 style='width: 15px;height: 15px;color: #000000;margin-right: 5px;font-weight: bolder' />
            联系卖家
          </a-button>
        </a-col>
      </a-row>
    </a-card>
    <a-card style='margin-top: 20px'>
      <a-row :gutter='20'>
        <a-col :span='12'>
          <div style='background-color: #FAFAFA;width: 500px;height: 500px'>
            <a-carousel arrows dots-class='slick-dots slick-thumb'>
              <div slot='customPaging' slot-scope='props'>
                <img :src='getImgIndex(props.i)' />
                <!--<img v-for='(url,index) in imageUrls' :key='index' :src='url' />-->
              </div>
              <a v-for='(url,index) in imageUrls' :key='index'>
                <img :src='url' />
              </a>
            </a-carousel>
          </div>
        </a-col>
        <a-col :span='12'>
          <div style='margin-left: 10px;'>
            <div>
              <a-tooltip placement='topLeft'>
                <template slot='title'>
                  {{ currentGood.description }}
                </template>
                <span class='descText'>{{ currentGood.description }}</span>
              </a-tooltip>
            </div>
            <div>
              <span style='color: red'>￥</span>
              <span style='font-size: 33px;color: red'>{{ currentGood.salePrice }}</span>
              <span
                style='margin-left: 30px;color: black;text-decoration: line-through;font-weight: bold;'>原价:￥{{ currentGood.originalPrice
                }}</span>
            </div>
            <div style='margin-top: 10px'>
              <span>上架时间：</span>
              <span style='font-weight: bolder;color: black'>{{ currentGood.createTime }}</span>
            </div>
            <div style='margin-top: 10px'>
              <img src='@/assets/peisong.png' />
              <span style='color: #6DB99F;font-size: 18px;padding-top:2px;margin-left: 5px;'>3小时内发货</span>
            </div>
            <div style='margin: 5px 0'>
              <span style='color: black;'>免配送费</span>
            </div>
            <div>
              <a-input type='number' v-model='buyData.building' min='1' style='width: 70px'></a-input>
              <span style='font-size: 18px;font-weight: bolder;margin: 0 3px'>栋</span>
              <a-input type='number' v-model='buyData.floor' min='1' style='width: 70px'></a-input>
              <span style='font-size: 18px;font-weight: bolder;margin: 0 3px'>层</span>
              <a-input type='number' v-model='buyData.roomNumber' min='1' style='width: 70px'></a-input>
              <span style='font-size: 18px; font-weight: bolder;margin: 0 3px'>寝室号</span>
            </div>
            <div style='margin-top: 5px'>
              <a-input placeholder='请输入详细地址' v-model='buyData.fullAddress' style='width: 500px'></a-input>
              <span style='font-size: 18px;font-weight: bolder;margin: 0 3px'>详细地址</span>
            </div>
            <a-button-group style='margin-top: 100px'>
              <a-button shape='round' @click='msBug'
                        style='background-color: #FF0B3C;color: white;font-size: 16px;height: 40px;border-radius: 20px 0 0 20px;'>
                立即购买
              </a-button>
              <a-button shape='round' @click='addShoppingCart'
                        style='background-color: #FFC400;color: white;font-size: 16px;height: 40px;border-radius: 0 20px 20px 0;'>
                加入购物车
              </a-button>
            </a-button-group>
          </div>
        </a-col>
      </a-row>
    </a-card>
  </div>

</template>

<script>
import storage from 'store'
import { addProductCart, ljBuy, getUserAddress } from '@/api/product-man'

export default {
  name: 'BuyMore',
  data() {
    return {
      currentGood: {},
      imgNumber: 0,
      imageUrls: [],
      baseUrl: 'https://raw.githubusercontent.com/vueComponent/ant-design-vue/master/components/vc-slick/assets/img/react-slick/',
      buildingData: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'],
      buyData: {
        userId: 0,
        productId: 0,
        building: 1,
        floor: 1,
        roomNumber: 1,
        fullAddress: ''
      }
    }
  },
  mounted() {
    // this.currentGood = this.$route.params.item
    this.currentGood = storage.get('currentGood') ? storage.get('currentGood') : this.$route.params.item
    this.imgNumber = this.currentGood.image.length
    console.log(this.currentGood)
    this.getImgUrl()
    this.getAddress()
  },
  methods: {
    getAddress() {
      getUserAddress().then(res => {
        if (res.code === '200') {
          this.buyData.building = res.data.building
          this.buyData.floor = res.data.floor
          this.buyData.roomNumber = res.data.roomNumber
          this.buyData.fullAddress = res.data.fullAddress
        }
      })
    },
    getImgUrl() {
      this.imageUrls = []
      for (let i = 0; i < this.imgNumber; i++) {
        if (this.currentGood.image[i] && this.currentGood.image[i].url) {
          this.imageUrls.push(this.currentGood.image[i].url)
        } else {
          // 如果某个图片对象或其 url 不存在，可以记录错误或跳过
          console.error('某个图片对象或其 URL 不存在', i)
        }
      }
    },
    getImgIndex(j) {
      return this.currentGood.image[j].url
      // for (let i = 0; i < this.imgNumber; i++) {
      //   if (this.currentGood.image[i] && this.currentGood.image[i].url) {
      //     return this.currentGood.image[i].url
      //   } else {
      //     console.error('某个图片对象或其 URL 不存在', i)
      //     return null
      //     // 如果某个图片对象或其 url 不存在，可以记录错误或跳过
      //   }
      // }
    },
    contactSellClick() {
      storage.set('currentGoodBuyMoreContactSell', this.currentGood, new Date().getTime() + 7 * 24 * 60 * 60 * 1000)
      this.$router.push({ name: 'userAdminProductBuyMoreContactSell', params: { item: this.currentGood } })
    },
    // 立即购买
    msBug() {
      this.buyData.userId = this.currentGood.userId
      this.buyData.productId = this.currentGood.id
      ljBuy(this.buyData).then(res => {
        if (res.code === '200') {
          this.$router.push({ name: 'userAdminProductBuy' })
          this.$notification.success({
            message: '操作提示',
            description: '购买成功'
          })
        } else {
          this.$notification.error({
            message: '操作提示',
            description: res.msg
          })
        }
      })
    },

    // 购物车
    addShoppingCart() {
      if (this.currentGood.id < 1) {
        this.$message.error('当前商品id有误!')
        return
      }
      addProductCart(this.currentGood.id).then(res => {
        if (res.code === '200') {
          storage.set('currentGoodAddShoppingCart', this.currentGood, new Date().getTime() + 7 * 24 * 60 * 60 * 1000)
          this.$router.push({ name: 'userAdminProductBuyMoreShopCart', params: { item: this.currentGood } })
        } else {
          this.$message.error('添加购物车失败')
        }
      }).catch(err => {
        console.log(err)
      })
    }

  }
}
</script>

<style scoped>
.ant-carousel >>> .slick-dots {
  height: auto;
}

.ant-carousel >>> .slick-slide img {
  border: 5px solid #fff;
  display: block;
  margin: auto;
  max-width: 80%;
}

.ant-carousel >>> .slick-thumb {
  bottom: -45px;
}

.ant-carousel >>> .slick-thumb li {
  width: 60px;
  height: 45px;
}

.ant-carousel >>> .slick-thumb li img {
  width: 100%;
  height: 100%;
  filter: grayscale(100%);
}

.ant-carousel >>> .slick-thumb li.slick-active img {
  filter: grayscale(0%);
}

.ant-carousel[data-v-1f868d5e] .slick-slide img {
  border: 5px solid #fff;
  display: block;
  margin: auto;
  max-width: 80%;
  width: 300px;
  height: 400px;
}

.ant-carousel[data-v-1f868d5e] .slick-thumb li img {
  width: 60px;
  height: 60px;
  -webkit-filter: grayscale(100%);
  filter: grayscale(100%);
}

/* 覆盖所有 Ant Design Vue 按钮的悬停样式 */
.ant-btn:hover,
.ant-btn:focus {
  background-color: transparent; /* 或者你想要的背景颜色 */
  color: inherit; /* 或者你想要的文字颜色 */
  border-color: #D9D9D9;
}

.descText {
  display: -webkit-box;
  -webkit-line-clamp: 1;
  color: black;
  -webkit-box-orient: vertical;
  overflow: hidden;
  font-size: 16px;
  font-weight: bolder;
  text-overflow: ellipsis;
  /* 为了确保内容居中，可以添加一些额外的样式 */
}

</style>