<template>
  <a-card :bordered='false'>
    <a-form layout='inline'>
      <a-row>
        <a-col :span='7'>
          <a-form-item label='公告标题' style='font-weight: bold'>
            <a-input type='text' style='width:200px;' v-model='queryParams.title'
                     placeholder='请输入公告标题' allowClear @change='showChange()' />
          </a-form-item>
        </a-col>
        <a-col :span='7'>
          <a-form-item label='操作人员' style='font-weight: bold;'>
            <a-input v-model='queryParams.createBy' placeholder='请输入操作人员' allowClear
                     style='width:200px;border-radius: 10px' @change='showChange()' />
          </a-form-item>
        </a-col>
        <a-col :span='10'>
          <a-form-item label='类型' style='font-weight: bold;'>
            <a-select v-model='queryParams.status' placeholder='状态' style='width:130px;' allowClear
                      @change='showChange()'>
              <a-select-option
                v-for='(value,index) in ["正常","关闭"]'
                :key='index'
                :label=value
                :value=value>
                {{ value }}
              </a-select-option>
            </a-select>
          </a-form-item>
          <a-form-item>
            <a-button type='primary' @click='$refs.table.refresh(true)' icon='search'>搜索</a-button>
            <a-button icon='reload' @click='()=>(this.queryParams={},$refs.table.refresh(true))'
                      style='margin-left:15px'>重置
            </a-button>
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>

    <a-modal title='添加公告' :visible.sync='visibleNoticeModel' width='780px' :destroy-on-close='true'
             @cancel='cancelNoticeModal'>
      <a-form>
        <a-row>
          <a-col :span='9'>
            <a-form-item label='公告标题' style='font-weight: bold;'>
              <a-input v-model='modalNotice.title' placeholder='请输入公告标题' />
            </a-form-item>
          </a-col>
          <a-col :span='6'>

          </a-col>
          <a-col :span='9'>
            <a-form-item label='状态' style='font-weight: bold;'>
              <a-radio-group v-model='modalNotice.status'>
                <a-radio :value='0'>正常</a-radio>
                <a-radio :value='1'>关闭</a-radio>
              </a-radio-group>
            </a-form-item>
          </a-col>
          <a-col :span='24'>
            <a-form-item label='内容' style='font-weight: bold;'>
              <div class='input' style='margin: 2%; margin-bottom: 0;'>
                <mavon-editor v-model='modalNotice.content' class='formclass' :editable='!check'>
                </mavon-editor>
              </div>
            </a-form-item>
          </a-col>
        </a-row>
      </a-form>
      <div slot='footer' class='dialog-footer'>
        <a-button type='primary' @click='addNoticeData'>确 定</a-button>
        <a-button @click='cancelNoticeModal'>取 消</a-button>
      </div>
    </a-modal>

    <a-modal title='修改公告' :visible.sync='visibleUpdateNoticeModel' width='780px' :destroy-on-close='true'
             @cancel='cancelUpdateNoticeModal'>
      <a-form>
        <a-row>
          <a-col :span='9'>
            <a-form-item label='公告标题' style='font-weight: bold;'>
              <a-input v-model='modalNotice.title' placeholder='请输入公告标题' />
            </a-form-item>
          </a-col>
          <a-col :span='6'>

          </a-col>
          <a-col :span='9'>
            <a-form-item label='状态' style='font-weight: bold;'>
              <a-radio-group v-model='modalNotice.status'>
                <a-radio :value='0'>正常</a-radio>
                <a-radio :value='1'>关闭</a-radio>
              </a-radio-group>
            </a-form-item>
          </a-col>
          <a-col :span='24'>
            <a-form-item label='内容' style='font-weight: bold;'>
              <div class='input' style='margin: 2%; margin-bottom: 0;'>
                <mavon-editor v-model='modalNotice.content' class='formclass' :editable='!check'>
                </mavon-editor>
              </div>
            </a-form-item>
          </a-col>
        </a-row>
      </a-form>
      <div slot='footer' class='dialog-footer'>
        <a-button type='primary' @click='updateNoticeDataModal'>修 改</a-button>
        <a-button @click='cancelUpdateNoticeModal'>取 消</a-button>
      </div>
    </a-modal>

    <a-button style='margin:20px 0' type='primary' icon='plus' @click='addNotice'>添 加</a-button>
    <a-button class='btnUpdate' :disabled='selectedRowKeys.length!==1' icon='edit' @click='handleEdit2'>修 改</a-button>

    <a-popconfirm
      :visible.sync='isVisible'
      ok-text='确定'
      cancel-text='取消'
      @confirm='deleteRow'
      @cancel='cancelDelPop'>
      <template slot='title'>
        <p>是否确认删除编号为 {{ selectedDeleteId }} 的数据项?</p>
      </template>
      <a-button class='btnDelete' @click='isVisible=true' :disabled='!selectedRowKeys.length > 0 ' icon='delete'>删 除
      </a-button>
    </a-popconfirm>

    <s-table
      ref='table'
      size='default'
      rowKey='id'
      :columns='columns'
      :data='loadData'
      :alert='true'
      :rowSelection='rowSelection'
      showPagination='auto'
    >
      <span slot='status' slot-scope='text'>
      <a-tag :color="text=== '0' ? 'blue':'red'">
        {{ text === '1' ? '关闭' : '正常' }}
        </a-tag>
    </span>
      <span slot='action' slot-scope='text, record'>
          <template>
            <a @click='handleEdit(record)'>
            <a-icon type='edit' />修改
            </a>
            <a-divider type='vertical' />
          <a @click='record.showConfirm = true'>
              <a-icon type='delete' />删除
          </a>
             <a-popconfirm
               :title="'是否确认删除编号为【 ' + record.id + ' 】的数据项?'"
               :visible.sync='record.showConfirm'
               placement='top'
               ok-text='确定'
               cancel-text='取消'
               @confirm='handleDel(record)'
               @cancel='record.showConfirm = false'
             >
            </a-popconfirm>
          </template>
      </span>
    </s-table>

  </a-card>
</template>

<script>

import { getPageNoticeList, addNotice, updateCurrentNotice, updateNoticeDeleteById } from '@/api/notice'
import { STable } from '@/components'

import { mavonEditor } from 'mavon-editor'
import 'mavon-editor/dist/css/index.css'
import { stringToNumber, numberToString } from '@/utils/util'
import { updateUserIsDeleteById } from '@/api/manage'
import notification from 'ant-design-vue/lib/notification'

const columns = [
  {
    title: '序号',
    align: 'center',
    width: 80,
    dataIndex: 'id'
  },
  {
    title: '公告标题',
    width: 120,
    align: 'center',
    dataIndex: 'title'
  },
  {
    title: '状态',
    dataIndex: 'status',
    width: 80,
    align: 'center',
    scopedSlots: { customRender: 'status' }
  },
  {
    title: '创建者',
    width: 100,
    align: 'center',
    dataIndex: 'createBy'
  },
  {
    title: '创建时间',
    dataIndex: 'createTime',
    width: 180,
    sorter: true,
    align: 'center'
  },
  {
    title: '操作',
    dataIndex: 'action',
    width: '150px',
    scopedSlots: { customRender: 'action' }
  }
]

export default {
  name: 'notice',
  components: {
    STable, mavonEditor
  },
  data() {
    this.columns = columns
    return {
      selectedRowKeys: [],
      selectedRows: [],
      selectedDeleteId: [],
      check: false,
      delPop: false,
      isVisible: false,
      queryParams: {
        title: undefined,
        createBy: undefined,
        status: undefined
      },
      modalNotice: {
        status: 0,
        title: '',
        content: '',
        id: 0
      },
      visibleNoticeModel: false,
      visibleUpdateNoticeModel: false,
      loadData: (parameter) => {
        const requestParameters = Object.assign({}, parameter, this.queryParams)
        console.log('通知参数: ', requestParameters)
        return new Promise((resolve, reject) => {
          getPageNoticeList(requestParameters)
            .then((res) => {
              console.log('通知数据: ', res)
              resolve(res.data)
            })
            .catch((error) => {
              reject(error)
            })
        })
      }
    }
  },
  computed: {
    rowSelection() {
      return {
        selectedRowKeys: this.selectedRowKeys,
        onChange: this.onSelectChange
      }
    }
  },
  methods: {
    // 昵称 输入框内容变化时的回调
    showChange() {
      this.$refs.table.refresh(true)
    },
    // 修改当前公告
    handleEdit(record) {
      this.modalNotice.status = 0
      this.modalNotice.title = ''
      this.modalNotice.content = ''
      this.modalNotice.id = 0

      this.visibleUpdateNoticeModel = true
      this.modalNotice.title = record.title
      this.modalNotice.content = record.content
      this.modalNotice.id = record.id
      this.modalNotice.status = stringToNumber(record.status)
    },
    handleEdit2() {
      this.modalNotice.status = 0
      this.modalNotice.title = ''
      this.modalNotice.content = ''
      this.modalNotice.id = 0

      this.visibleUpdateNoticeModel = true
      this.modalNotice.title = this.selectedRows[0].title
      this.modalNotice.content = this.selectedRows[0].content
      this.modalNotice.id = this.selectedRows[0].id
      this.modalNotice.status = stringToNumber(this.selectedRows[0].status)
    },
    handleDel(record) {
      let selectIdArr = []
      if (!isNaN(record.id)) {
        selectIdArr = [parseInt(record.id)]
      } else {
        selectIdArr = []
      }
      updateNoticeDeleteById({ ids: selectIdArr }).then(res => {
        if (res.code === '200') {
          notification.success({
            message: '操作提示',
            description: '删除成功!'
          })
          this.selectedRowKeys = []
          this.selectedRows = []
          // 刷新表格
          this.$refs.table.refresh(true)
        } else {
          notification.error({
            message: '操作提示',
            description: '删除失败!'
          })
        }
      })
    },
    deleteRow() {
      const rowIds = this.selectedRows.map(row => row.id)
      updateNoticeDeleteById({ ids: rowIds }).then(res => {
        if (res.code === '200') {
          this.$message.success('删除成功')
          this.isVisible = false
          // 刷新表格
          this.selectedRowKeys = []
          this.selectedRows = []
          this.$refs.table.refresh(true)
        } else {
          this.$message.error('删除失败')
        }
      })
    },
    cancelDelPop() {
      this.isVisible = false
    },
    onSelectChange(selectedRowKeys, selectedRows) {
      this.selectedRowKeys = []
      this.selectedRows = []
      this.selectedRowKeys = selectedRowKeys
      this.selectedRows = selectedRows
      this.selectedDeleteId = this.selectedRows.map(row => row.id)
      console.log('onSelectChange: 执行了')
    },
    // 显示对话框
    addNotice() {
      this.modalNotice = {}
      this.visibleNoticeModel = true
    },
    getList() {
    },
    // 添加公告
    addNoticeData() {
      addNotice(this.modalNotice).then(res => {
        if (res.code === '200') {
          this.$message.success('添加成功')
          this.$refs.table.refresh(true)
          this.selectedRowKeys = []
          this.selectedRows = []
          this.cancelNoticeModal()

        } else {
          this.$message.error(res.msg)
        }
      })
      console.log(this.modalNotice)
    },
    // 修改公告
    updateNoticeDataModal() {
      updateCurrentNotice(this.modalNotice).then(res => {
        if (res.code === '200') {
          this.$message.success('修改成功')
          this.cancelUpdateNoticeModal()
          this.selectedRowKeys = []
          this.selectedRows = []
          this.$refs.table.refresh(true)
        } else {
          this.$message.error('修改失败')
        }
      })
    },
    cancelNoticeModal() {
      this.visibleNoticeModel = false
    },
    cancelUpdateNoticeModal() {
      this.visibleUpdateNoticeModel = false
    }
  }
}
</script>
<style scoped>
.btnDelete {
  background-color: #FFEDED;
  color: #FF4949;
  border: none;
}

.btnDelete:hover {
  background-color: #FF4949;
  color: white;
}

.btnUpdate {
  margin: 20px 20px;
  background-color: #E7FAF0;
  color: #57CE66;
  border: none;
  transition: background-color 0.3s ease; /* 添加过渡效果，使背景色变化更加平滑 */
}

.btnUpdate:hover {
  background-color: #13CE66;
  color: white;
}
</style>
