<template>
  <a-card>
    <a-form :form='form' @submit='handleSubmit' :label-col='{span:6}' :wrapper-col='{span:12}'>
      <a-form-item label='昵称：'>
        <a-input
          v-decorator="[
                'nickname',
            {
             rules: [
                { required: true, message: $t('addUser.user.nickname.required') },
                  ],
                  validateTrigger: 'change',
                  initialValue:user.nickname,
                },
              ]"
          placeholder='请输入昵称'
        >
          <a-icon slot='prefix' type='usergroup-delete' style='color:rgba(0,0,0,.25)' />
        </a-input>
      </a-form-item>
      <a-form-item label='账号：'>
        <a-input
          v-decorator="[
          'username',
          {
            rules: [
              { required: true, message: '账号不能为空' },
              { pattern: /^\d{7}$/, message: '账号必须为7位数字' },
            ],
            validateTrigger: 'change',
            initialValue: user.username,
          },
        ]"
          placeholder='请输入账号'
        >
          <a-icon slot='prefix' type='user' style='color:rgba(0,0,0,.25)' />
        </a-input>
        <a-button type='danger' @click='getUsernameNumber'>生成账号</a-button>

      </a-form-item>
      <a-form-item label='性别：'>
        <a-radio-group
          v-decorator="[
                'sex',
            {
             rules: [
                { required: true, message:'性别不能为空' },
                  ],
                  validateTrigger: 'change',
                  initialValue:user.sex,
                },
              ]">
          <a-radio value='1'>男</a-radio>
          <a-radio value='0'>女</a-radio>
        </a-radio-group>
      </a-form-item>
      <a-form-item label='密码：'>
        <a-input
          type='password'
          v-decorator="[
                'password',
            {
             rules: [
                { required: true, message: '密码不能为空' },
                  ],
                  validateTrigger: 'change',
                  initialValue:user.password,
                },
              ]"
          placeholder='请输入密码'
        >
          <a-icon slot='prefix' type='lock' style='color:rgba(0,0,0,.25)' />
        </a-input>
      </a-form-item>
      <a-form-item label='邮箱'>
        <a-input
          v-decorator="[
                'email',
            {
             rules: [
                { required: true, message:'邮箱不能为空' },
                  ],
                  validateTrigger: 'change',
                  initialValue:user.email,
                },
              ]"
          placeholder='请输入邮箱'
        >
          <a-icon slot='prefix' type='mail' style='color: rgba(0, 0, 0, 0.25)' />
        </a-input>
      </a-form-item>
      <a-form-item label='手机号'>
        <a-input
          v-decorator="[
                'phone',
            {
             rules: [
                { required: true, message: '手机号不能为空' },
                  ],
                  validateTrigger: 'change',
                  initialValue:user.phone,
                },
              ]"
          placeholder='请输入手机号'
        >
          <a-icon slot='prefix' type='phone' style='color:rgba(0,0,0,.25)' />
        </a-input>
      </a-form-item>
      <a-form-item label='个人简介'>
        <a-input
          type='textarea'
          :rows='4'
          v-decorator="[
                'persProfile',
            {
             rules: [
                { required: true, message: '个人简介不能为空' },
                  ],
                  validateTrigger: 'change',
                  initialValue:user.persProfile,
                },
              ]"
          placeholder='请输入个人简介'
        />
      </a-form-item>
      <a-form-item label='用户状态' :rules="[{ required: true, message: '请选择用户状态' }]">
        <a-radio-group
          v-decorator="[
                'status',
            {
             rules: [
                { required: true, message:'用户状态' },
                  ],
                  validateTrigger: 'change',
                  initialValue:user.status,
                },
              ]">
          <a-radio value='0'>正常</a-radio>
          <a-radio value='1'>锁定</a-radio>
        </a-radio-group>
      </a-form-item>
      <a-form-item label='用户角色'>
        <a-radio-group
          v-decorator="[
                'role',
            {
             rules: [
                { required: true, message:'用户角色' },
                  ],
                  validateTrigger: 'change',
                  initialValue:user.role,
                },
              ]">
          <a-radio value='0'>普通用户</a-radio>
          <a-radio value='1'>管理员</a-radio>
        </a-radio-group>
      </a-form-item>
      <a-form-item style='margin: 50px auto;display: flex;justify-content: center'>
        <div class='main' @click='handleSubmit' data-text='添 加' style='--c: #409EFF' />
        <div class='main' @click='handleReset' data-text='重 置'
             style='--c: #67C23A;position: relative;top:-32px;left:150px' />
        <div class='main' @click='goUserAdminList' data-text='去用户列表'
             style='--c: #3A67C2;position: relative;bottom:64px;left:300px' />
      </a-form-item>
    </a-form>
  </a-card>
</template>

<script>

import { generateSevenDigitNumber } from '@/utils/util'
import { addUser } from '@/api/adminUser'

export default {
  data() {
    return {
      form: this.$form.createForm(this),
      formLayout: 'horizontal',
      user: {
        avatar: 'https://bs-api-oss.oss-cn-wulanchabu.aliyuncs.com/2024/01/18/889370b8bc1548d881666d264a243cc6show.png',
        nickname: '狗熊',
        username: '1234567',
        sex: '1',
        password: '123456',
        email: '4565478976@qq.com',
        phone: '13898786751',
        persProfile: '我喜欢吃蜂蜜',
        status: '0',
        role: '0'
      }
    }
  },
  methods: {
    getUsernameNumber() {
      this.form.setFieldsValue({ 'username': generateSevenDigitNumber() })
    },
    handleReset() {
      this.form.resetFields()
      this.user = {}
    },
    handleSubmit(e) {
      e.preventDefault()
      this.form.validateFields((errors, values) => {
        if (!errors) {
          values.avatar = this.user.avatar
          // 发送请求保存用户数据
          console.log('用户数据:', values)
          addUser(values).then(res => {
            if (res.code === '200') {
              this.$notification.info({ message: '操作提示', description: '新增用户成功!' })
              this.$router.push({ name: 'userAdminList' })
            } else {
              this.$notification.error({
                message: '操作提示',
                description: res.msg
              })
            }
          })
        }
      })
    },
    goUserAdminList() {
      this.$router.push({ name: 'userAdminList' })
    }
  }
}
</script>

<style scoped>
/* 样式可以根据需要进行调整 */
.a-form-item-label {
  text-align: right;
}

.main {
  position: relative;
  width: 116px;
  height: 32px;
  background: #1890ff;
  margin-right: 20px;
  display: flex;
  flex: 1 0 auto;
  justify-content: center;
  align-items: center;
  overflow: hidden;
  border-radius: 5px;
  transition: 1s linear;
}

.main::before {
  content: '';
  width: 300px;
  height: 60px;
  background: var(--c);
  position: absolute;
  animation: roll 4s linear infinite;
  filter: blur(5px);
  transition: 1s linear;
}

.main::after {
  width: 111px;
  height: 27px;
  content: attr(data-text);
  position: absolute;
  color: rgba(0, 0, 0, 0.65);
  font-size: 14px;
  text-align: center;
  line-height: 29px;
  background: #fff;
  text-transform: uppercase;
  font-family: Arial, Helvetica, sans-serif;
  /*border-radius: 5px;*/
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  transition: 1s linear;
}

@keyframes roll {
  100% {
    transform: rotate(360deg);
    filter: blur(5px) hue-rotate(360deg);
  }
}

.main:hover {
  box-shadow: 0 0 2px var(--c);
  background: var(--c);
}

.main:hover::before {
  height: 500px;
  width: 500px;
  animation-play-state: paused;
  filter: hue-rotate(0);
}

.main:hover::after {
  background: var(--c);
  color: white;
}
</style>
