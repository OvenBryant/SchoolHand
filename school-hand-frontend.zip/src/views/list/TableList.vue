<template>
  <page-header-wrapper>
    <a-card :bordered='false'>
      <div class='table-page-search-wrapper'>
        <a-form layout='inline'>
          <a-row :gutter='48'>
            <a-col :md='8' :sm='24'>
              <a-form-item label='昵称'>
                <a-input v-model='queryParam.nickname' placeholder='模糊查询' @change='showChange()' allowClear />
              </a-form-item>
            </a-col>
            <a-col :md='8' :sm='24'>
              <a-form-item label='性别'>
                <a-select v-model='queryParam.sex' placeholder='请选择' default-value='0' allowClear
                          @change='showChange()'>
                  <a-select-option value='1'>男</a-select-option>
                  <a-select-option value='0'>女</a-select-option>
                </a-select>
              </a-form-item>
            </a-col>
            <template v-if='advanced'>
              <!-- <a-col :md="8" :sm="24">
                <a-form-item label="调用次数">
                  <a-input-number v-model="queryParam.callNo" style="width: 100%"/>
                </a-form-item>
              </a-col> -->
              <a-col :md='8' :sm='24'>
                <a-form-item label='注册日期'>
                  <a-range-picker
                    :ranges="{ Today: [moment(), moment()], 'This Month': [moment(), moment().endOf('month')] }"
                    v-model='dateIntervalMoment'
                    @change='showChange()'
                    allowClear
                    format='YYYY-MM-DD'>
                    <template slot='dateRender' slot-scope='current'>
                      <div class='ant-calendar-date' :style='getCurrentStyle(current)'>
                        {{ current.date() }}
                      </div>
                    </template>
                  </a-range-picker>
                </a-form-item>
              </a-col>
              <a-col :md='8' :sm='24'>
                <a-form-item label='状态'>
                  <a-select v-model='queryParam.status' placeholder='请选择' @change='showChange()' allowClear>
                    <a-select-option value='0'>正常</a-select-option>
                    <a-select-option value='1'>锁定</a-select-option>
                  </a-select>
                </a-form-item>
              </a-col>
              <a-col :md='8' :sm='24'>
                <a-form-item label='isDelete'>
                  <a-select v-model='queryParam.isDelete' placeholder='请选择' @change='showChange()' allowClear>
                    <a-select-option value='0'>正常</a-select-option>
                    <a-select-option value='1'>删除</a-select-option>
                  </a-select>
                </a-form-item>
              </a-col>
            </template>
            <a-col :md='(!advanced && 8) || 24' :sm='24'>
              <span
                class='table-page-search-submitButtons'
                :style="(advanced && { float: 'right', overflow: 'hidden' }) || {}"
              >
                <a-button type='primary' @click='$refs.table.refresh(true)'>查询</a-button>
                <a-button style='margin-left: 8px'
                          @click='() => (this.queryParam = {},this.dateIntervalMoment=[])'>重置</a-button>
                <a @click='toggleAdvanced' style='margin-left: 8px'>
                  {{ advanced ? '收起' : '展开' }}
                  <a-icon :type="advanced ? 'up' : 'down'" />
                </a>
              </span>
            </a-col>
          </a-row>
        </a-form>
      </div>

      <div class='table-operator'>
        <a-button type='primary' icon='plus' @click='handleAdd'>新增用户</a-button>

        <a-dropdown v-action:edit v-if='selectedRowKeys.length > 0' v-model='dropdownVisible'
                    @visibleChange='callbackDropdownDelVisible'>
          <a-menu slot='overlay'>
            <a-menu-item key='1' @click='clickDelete'>
              <a-popconfirm
                :visible.sync='popConfirm'
                placement='top'
                ok-text='确定'
                cancel-text='取消'
                @confirm='confirm'
                @cancel='cancel'>
                <template slot='title'>
                  <p>{{ popText }}</p>
                </template>
                <a-icon type='delete' />
                删除
              </a-popconfirm>
            </a-menu-item>
            <a-menu-item key='2' @click='clickRestore'>
              <a-icon type='hourglass' />
              恢复
            </a-menu-item>
            <a-menu-item key='3' @click='clickLock'>
              <a-icon type='lock' />
              锁定
            </a-menu-item>
            <a-menu-item key='4' @click='clickunLock'>
              <a-icon type='key' />
              解锁
            </a-menu-item>
          </a-menu>
          <a-button style='margin-left: 8px'> 批量操作
            <a-icon type='down' />
          </a-button>
        </a-dropdown>

        <input type='file' ref='fileInput' style='display: none' @change='handleFileChange'>
        <a-button type='danger' icon='download' @click='importUser'>导 入</a-button>

        <a-popconfirm
          title='确定要导出数据吗?'
          ok-text='是的'
          cancel-text='不用了'
          @confirm='ExportConfirm'
          @cancel='ExportCancel'
        >
          <a-button type='dashed' icon='upload'>导 出</a-button>
        </a-popconfirm>
      </div>

      <s-table
        ref='table'
        size='default'
        rowKey='id'
        :columns='columns'
        :data='loadData'
        :alert='true'
        :rowSelection='rowSelection'
        showPagination='auto'
      >
        <span slot='serial' slot-scope='text, record, index'>
          {{ index + 1 }}
        </span>
        <span slot='avatar' slot-scope='text'>
          <a-avatar :src='text' />
        </span>
        <span slot='sex' slot-scope='text'>
           <a-tag :color="text === '1' ? '#2db7f5' : '#87d068' ">
             {{ text === '1' ? '男' : '女' }}</a-tag>
        </span>
        <span slot='status' slot-scope='text'>
          <a-badge :status='text | statusTypeFilter' :text='text | statusFilter' />
        </span>
        <span slot='isDelete' slot-scope='text'>
          <a-badge :status='text | isDeleteTypeFilter' :text='text | isDeleteFilter' />
        </span>
        <span slot='action' slot-scope='text, record'>
          <template>
            <a @click='handleEdit(record)'>
            <a-icon type='edit' />修改
            </a>
            <a-divider type='vertical' />
            <a @click='handleDel(record)'>
              <a-icon type='delete' />删除
            </a>
          </template>
        </span>

      </s-table>

      <create-form
        ref='createModal'
        :visible='visible'
        :loading='confirmLoading'
        :model='mdl'
        @cancel='handleCancel'
        @ok='handleOk'
      />
      <step-by-step-modal ref='modal' @ok='handleOk' />
    </a-card>
  </page-header-wrapper>
</template>

<script>
import moment from 'moment'
import { Ellipsis, STable } from '@/components'
import { getPageUserList, updateUserIsDeleteById, updateUserStatusById } from '@/api/manage'

import StepByStepModal from './modules/StepByStepModal'
import CreateForm from './modules/CreateForm'
import notification from 'ant-design-vue/lib/notification'
import request from '@/utils/request'
import { exportExcel, importExcel, userAdmin } from '@/api/adminUser'
import storage from 'store'
import { ACCESS_TOKEN } from '@/store/mutation-types'

const columns = [
  // {
  //   title: '头像',
  //   dataIndex: 'avatar'
  // },
  {
    title: '#',
    scopedSlots: { customRender: 'serial' }
  },
  // {
  //   title: 'id',
  //   dataIndex: 'id'
  // },
  {
    title: '头像',
    dataIndex: 'avatar',
    scopedSlots: { customRender: 'avatar' }
  },
  {
    title: '昵称',
    dataIndex: 'nickname',
    width: 80
  },
  {
    title: '用户名',
    width: 90,
    align: 'center',
    dataIndex: 'username'
  },
  {
    title: '性别',
    dataIndex: 'sex',
    scopedSlots: { customRender: 'sex' }
  },
  // {
  //   title: '服务调用次数',
  //   dataIndex: 'callNo',
  //   sorter: true,
  //   needTotal: true,
  //   customRender: (text) => text + ' 次'
  // },
  {
    title: '状态',
    dataIndex: 'status',
    width: 90,
    align: 'center',
    scopedSlots: { customRender: 'status' }
  },
  {
    title: 'isDelete',
    dataIndex: 'isDelete',
    scopedSlots: { customRender: 'isDelete' }
  },
  {
    title: '创建时间',
    dataIndex: 'createTime',
    width: 180,
    sorter: true,
    align: 'center'
  },
  {
    title: '更新时间',
    dataIndex: 'updateTime',
    width: 180,
    sorter: true,
    align: 'center'

  },
  {
    title: '操作',
    dataIndex: 'action',
    width: '150px',
    scopedSlots: { customRender: 'action' }
  }
]

const statusMap = {
  0: {
    status: 'processing',
    text: '正常'
  },
  1: {
    status: 'error',
    text: '锁定'
  }
}

const isDeleteMap = {
  0: {
    status: 'success',
    text: '正常'
  },
  1: {
    status: 'error',
    text: '删除'
  }
}

export default {
  name: 'TableList',
  components: {
    STable,
    Ellipsis,
    CreateForm,
    StepByStepModal
  },
  data() {
    this.columns = columns
    return {
      // create model
      visible: false,
      confirmLoading: false,
      mdl: null,
      // 高级搜索 展开/关闭
      advanced: false,
      // 查询参数
      dateIntervalMoment: [], // 开始日期和结束日期
      queryParam: {
        // sortField: 'createTime', // 默认的排序字段
        // sortOrder: 'descend', // 默认的排序方式
        isDelete: '0',
        status: '0'
      },
      selectedDeleteUsername: [],
      dropdownVisible: false, // 下拉框菜单的收起与展开
      deleteFlag: false,
      restoreFlag: false,
      lockFlag: false,
      unlockFlag: false,
      popConfirm: false,
      popText: '', // 气泡对话框显示内容
      // 加载数据方法 必须为 Promise 对象
      // loadData: (parameter) => {
      //   console.log('参数: ', parameter)
      //   this.verifyDate() // 验证日期
      //   const requestParameters = Object.assign({}, parameter, this.queryParam)
      //   console.log('loadData request parameters:', requestParameters)
      //   return getPageUserList(requestParameters).then((res) => {
      //     console.log('表格数据: ', res)
      //     return res.data
      //   })
      // },
      // 加载数据方法 必须为 Promise 对象
      loadData: (parameter) => {
        console.log('参数: ', parameter)
        this.verifyDate() // 验证日期
        const requestParameters = Object.assign({}, parameter, this.queryParam)
        console.log('loadData request parameters:', requestParameters)
        const time = this.getCurrentDateTime()
        console.log('当前时间: ', time)

        return new Promise((resolve, reject) => {
          getPageUserList(requestParameters)
            .then((res) => {
              console.log('表格数据: ', res)
              resolve(res.data)
            })
            .catch((error) => {
              console.error('Error fetching data:', error)
              reject(error)
            })
        })
      },

      selectedRowKeys: [],
      selectedRows: []
    }
  },
  filters: {
    statusFilter(type) {
      return statusMap[type].text
    },
    statusTypeFilter(type) {
      return statusMap[type].status
    },
    isDeleteFilter(type) {
      return isDeleteMap[type].text
    },
    isDeleteTypeFilter(type) {
      return isDeleteMap[type].status
    }

  },
  created() {
    // getRoleList({ t: new Date() })
  },
  computed: {
    rowSelection() {
      return {
        selectedRowKeys: this.selectedRowKeys,
        onChange: this.onSelectChange
      }
    }
  },
  methods: {
    moment,
    ExportConfirm() {
      this.exportUser()
    },
    ExportCancel() {

    },
    getCurrentDateTime() {
      const now = new Date()
      const year = now.getFullYear()
      const month = (now.getMonth() + 1).toString().padStart(2, '0')
      const day = now.getDate().toString().padStart(2, '0')
      const hours = now.getHours().toString().padStart(2, '0')
      const minutes = now.getMinutes().toString().padStart(2, '0')
      const seconds = now.getSeconds().toString().padStart(2, '0')

      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
    },
    clickDelete() {
      this.deleteFlag = true
      this.dropdownVisible = true
      this.popConfirm = true
      this.popText = `是否删除用户名为:【 ${this.selectedDeleteUsername} 】的用户？`
    },
    clickRestore() {
      this.restoreFlag = true
      this.dropdownVisible = true
      this.popConfirm = true
      this.popText = `是否恢复用户名为:【 ${this.selectedDeleteUsername} 】的用户？`
    },
    clickLock() {
      this.lockFlag = true
      this.dropdownVisible = true
      this.popConfirm = true
      this.popText = `是否锁定用户名为:【 ${this.selectedDeleteUsername} 】的用户？`
    },
    clickunLock() {
      this.unlockFlag = true
      this.dropdownVisible = true
      this.popConfirm = true
      this.popText = `是否解锁用户名为:【 ${this.selectedDeleteUsername} 】的用户？`
    },
    callbackDropdownDelVisible(visible) {
      // 如果点击了删除,就显示下拉框,不自动缩回去
      if (this.deleteFlag) {
        this.dropdownVisible = true
      }
      if (this.restoreFlag) {
        this.dropdownVisible = true
      }
      if (this.lockFlag) {
        this.dropdownVisible = true
      }
      if (this.unlockFlag) {
        this.dropdownVisible = true
      }
    },
    cancel() {
      this.popConfirm = false
      this.deleteFlag = false
      this.restoreFlag = false
      this.lockFlag = false
      this.unlockFlag = false
      this.dropdownVisible = false
    },
    // 一旦点击确定的时候,就必须要if了
    confirm() {
      if (this.deleteFlag) {
        this.deleteRowKeys()
      }
      if (this.restoreFlag) {
        this.restoreRowKeys()
      }
      if (this.lockFlag) {
        this.lockRowKeys()
      }
      if (this.unlockFlag) {
        this.unlockRowKeys()
      }
      this.popConfirm = false
      this.deleteFlag = false
      this.restoreFlag = false
      this.lockFlag = false
      this.unlockFlag = false
      this.dropdownVisible = false
    },

    verifyDate() {
      if (this.dateIntervalMoment[0] && this.dateIntervalMoment[0].isValid() && this.dateIntervalMoment[1] && this.dateIntervalMoment[1].isValid()) {
        this.queryParam.createTime = this.dateIntervalMoment[0].format('YYYY-MM-DD')
        this.queryParam.updateTime = this.dateIntervalMoment[1].format('YYYY-MM-DD')
      } else {
        this.queryParam.createTime = ''
        this.queryParam.updateTime = ''
      }
    },

    // 删除表格选中行
    deleteRowKeys() {
      // console.log('this.selectedRowKeys: ', this.selectedRowKeys)  选中的个数
      // console.log('this.selectedRows: ', this.selectedRows)  行数据
      const selectedIds = this.selectedRows.map(row => row.id)
      console.log('删除表格行ID: ', selectedIds)
      updateUserIsDeleteById({ ids: selectedIds, extraParam: 1 }).then(res => {
        if (res.code === '200') {
          notification.success({
            message: '操作提示',
            description: '删除成功!'
          })
          // 刷新表格
          this.$refs.table.clearSelected()
          this.$refs.table.refresh()
        } else {
          notification.error({
            message: '操作提示',
            description: '删除失败!'
          })
        }
      })
    },
    restoreRowKeys() {
      const selectedIds = this.selectedRows.map(row => row.id)

      updateUserIsDeleteById({ ids: selectedIds, extraParam: 0 }).then(res => {
        if (res.code === '200') {
          notification.success({
            message: '操作提示',
            description: '恢复成功!'
          })
          // 刷新表格
          this.$refs.table.clearSelected()
          this.$refs.table.refresh()
        } else {
          notification.error({
            message: '操作提示',
            description: '恢复失败!'
          })
        }
      })
    },
    // 锁定表格选中行
    lockRowKeys() {
      const selectedIds = this.selectedRows.map(row => row.id)
      updateUserStatusById({ ids: selectedIds, extraParam: 1 }).then(res => {
        if (res.code === '200') {
          notification.success({
            message: '操作提示',
            description: '锁定成功!'
          })
          // 刷新表格
          this.$refs.table.clearSelected()
          this.$refs.table.refresh()
        } else {
          notification.error({
            message: '操作提示',
            description: '锁定失败!'
          })
        }
      })
    },
    // 锁定表格选中行
    unlockRowKeys() {
      const selectedIds = this.selectedRows.map(row => row.id)
      updateUserStatusById({ ids: selectedIds, extraParam: 0 }).then(res => {
        if (res.code === '200') {
          notification.success({
            message: '操作提示',
            description: '解锁成功!'
          })
          // 刷新表格
          this.$refs.table.clearSelected()
          this.$refs.table.refresh()
        } else {
          notification.error({
            message: '操作提示',
            description: '解锁失败!'
          })
        }
      })
    },
    getCurrentStyle(current, today) {
      const style = {}
      if (current.date() === 1) {
        style.border = '1px solid #1890ff'
        style.borderRadius = '50%'
      }
      return style
    },

    importUser() {
      // 触发文件输入元素点击事件
      this.$refs.fileInput.click()
    },
    handleFileChange(event) {
      // 处理文件选择的逻辑
      const file = event.target.files[0]
      if (file) {
        // 执行文件上传或解析逻辑
        this.uploadFile(file)
      }
    },
    uploadFile(file) {
      const formData = new FormData()
      formData.append('file', file)
      console.log('当前文件: ', file)
      importExcel(formData).then(res => {
        if (res.code === '200') {
          notification.success({
            message: '操作提示',
            description: '导入成功!'
          })
          // 刷新表格
          this.$refs.table.refresh()
        } else {
          notification.error({
            message: '操作提示',
            description: '导入失败!'
          })
        }
        // 清空文件输入元素的值
        this.$refs.fileInput.value = null
      })
    },
    // ...
    // 导出excel表
    exportUser() {
      getPageUserList(this.queryParam)
        .then((res) => {
          if (res.data.records.length > 0) {
            const token = storage.get(ACCESS_TOKEN)
            const url = request.defaults.baseURL + userAdmin.exportUrl + '?' + ACCESS_TOKEN + '=' + token
            window.open(url)
          } else {
            this.$message.error('当前没有需要导出的数据')
          }
        })
        .catch((error) => {
          console.log(error)
        })
      // exportExcel(url).then(res => {
      //   console.log(res)
      // })
      // const token = storage.get(ACCESS_TOKEN)
      // 设置请求头 这个不是添加请求头
      // const headers = {
      //   'Access-Token': token
      // }
      // window.open(url, { headers })
    },
    handleAdd() {
      // this.mdl = null
      // this.visible = true
      this.$router.push({ name: 'userAdminAddUser' })
    },
    handleEdit(record) {
      console.log(record)
      // this.visible = true
      // this.mdl = { ...record }
      this.$router.push({ name: 'userAdminEditUser', params: { oneUserInfo: record.id } })
      // this.$router.push({ name: 'userAdminEditUser', params: { oneUserInfo: JSON.stringify(record) } })
    },
    // 删除
    handleDel(record) {
      let selectIdArr = []
      if (!isNaN(record.id)) {
        selectIdArr = [parseInt(record.id)]
      } else {
        selectIdArr = []
      }
      updateUserIsDeleteById({ ids: selectIdArr, extraParam: 1 }).then(res => {
        if (res.code === '200') {
          notification.success({
            message: '操作提示',
            description: '删除成功!'
          })
          // 刷新表格
          this.$refs.table.clearSelected()
          this.$refs.table.refresh()
        } else {
          notification.error({
            message: '操作提示',
            description: '删除失败!'
          })
        }
      })
    },
    handleOk() {
      const form = this.$refs.createModal.form
      this.confirmLoading = true
      form.validateFields((errors, values) => {
        if (!errors) {
          console.log('values', values)
          if (values.id > 0) {
            // 修改 e.g.
            new Promise((resolve, reject) => {
              setTimeout(() => {
                resolve()
              }, 1000)
            }).then((res) => {
              this.visible = false
              this.confirmLoading = false
              // 重置表单数据
              form.resetFields()
              // 刷新表格
              this.$refs.table.refresh()
              this.$message.info('修改成功')
            })
          } else {
            // 新增
            new Promise((resolve, reject) => {
              setTimeout(() => {
                resolve()
              }, 1000)
            }).then((res) => {
              this.visible = false
              this.confirmLoading = false
              // 重置表单数据
              form.resetFields()
              // 刷新表格
              this.$refs.table.refresh()

              this.$message.info('新增成功')
            })
          }
        } else {
          this.confirmLoading = false
        }
      })
    },
    handleCancel() {
      this.visible = false

      const form = this.$refs.createModal.form
      form.resetFields() // 清理表单数据（可不做）
    },
    handleSub(record) {
      if (record.status !== 0) {
        this.$message.info(`${record.no} 订阅成功`)
      } else {
        this.$message.error(`${record.no} 订阅失败，规则已关闭`)
      }
    },
    onSelectChange(selectedRowKeys, selectedRows) {
      this.selectedRowKeys = []
      this.selectedRows = []
      this.selectedRowKeys = selectedRowKeys
      this.selectedRows = selectedRows
      this.selectedDeleteUsername = this.selectedRows.map(row => row.username)

    },
    toggleAdvanced() {
      this.advanced = !this.advanced
    },
    resetSearchForm() {
      this.queryParam = {
        date: moment(new Date())
      }
    },
    // 昵称 输入框内容变化时的回调
    showChange() {
      this.$refs.table.refresh(true)
    }
  }
}
</script>
