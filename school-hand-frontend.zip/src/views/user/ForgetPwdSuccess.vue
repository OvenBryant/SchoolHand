<template>
  <a-result status="success" title="密码已发送至您的邮箱,注意查收!" sub-title="">
    <template #extra>
      <a-button @click="goHomeHandle" key="console" type="primary"> 返回首页 </a-button>
    </template>
  </a-result>
</template>

<script>
export default {
  data() {
    return {
      result: '',
    }
  },
  created() {
    this.result = this.$route.params.result
    this.$emit('child-click', '2') // 更新父组件进度条
  },
  methods: {
    goHomeHandle() {
      this.$router.push({ name: 'login' })
    },
  },
}
</script>

<style scoped></style>
