<template>
  <div class='main'>
    <a-form id='formLogin' class='user-layout-login' ref='formLogin' :form='form' @submit='handleSubmit'>
      <a-tabs
        :activeKey='customActiveKey'
        :tabBarStyle="{ textAlign: 'center', borderBottom: 'unset' }"
        @change='handleTabClick'
      >
        <a-tab-pane key='tab1' :tab="$t('user.login.tab-login-credentials')">
          <a-alert v-if='isLoginError' type='error' showIcon style='margin-bottom: 24px' message='账户或密码错误' />
          <a-form-item>
            <a-input
              size='large'
              type='text'
              placeholder='账户：admin'
              v-decorator="[
                'username',
                {
                  rules: [
                    { required: true, message: $t('user.userName.required') },
                    { validator: handleUsernameOrEmail },
                  ],
                  validateTrigger: 'change',
                },
              ]"
            >
              <a-icon slot='prefix' type='user' :style="{ color: 'rgba(0,0,0,.25)' }" />
            </a-input>
          </a-form-item>

          <a-form-item>
            <a-input-password
              size='large'
              placeholder='密码：admin'
              v-decorator="[
                'password',
                { rules: [{ required: true, message: $t('user.password.required') }], validateTrigger: 'blur' },
              ]"
            >
              <a-icon slot='prefix' type='lock' :style="{ color: 'rgba(0,0,0,.25)' }" />
            </a-input-password>
          </a-form-item>
        </a-tab-pane>
        <a-tab-pane key='tab2' :tab="$t('user.login.tab-login-mobile')">
          <a-form-item>
            <a-input
              size='large'
              type='text'
              :placeholder="$t('user.login.mobile.placeholder')"
              v-decorator="[
                'mobile',
                {
                  rules: [
                    { required: true, pattern: /^1[345978]\d{9}$/, message: '手机号格式有误!' },
                  ],
                  validateTrigger: 'input',
                },
              ]"
            >
              <a-icon slot='prefix' type='mobile' :style="{ color: 'rgba(0,0,0,.25)' }" />
            </a-input>
          </a-form-item>

          <a-row :gutter='16'>
            <a-col class='gutter-row' :span='16'>
              <a-form-item>
                <a-input
                  size='large'
                  type='text'
                  placeholder='验证码'
                  v-decorator="[
                    'captcha',
                    {
                      rules: [{ required: true, message: $t('user.verification-code.required') }],
                      validateTrigger: 'blur',
                    },
                  ]"
                >
                  <a-icon slot='prefix' type='mail' :style="{ color: 'rgba(0,0,0,.25)' }" />
                </a-input>
              </a-form-item>
            </a-col>
            <a-col class='gutter-row' :span='8'>
              <a-button
                class='getCaptcha'
                tabindex='-1'
                :disabled='state.smsSendBtn'
                @click.stop.prevent='getCaptcha'
                v-text="(!state.smsSendBtn && $t('user.register.get-verification-code')) || state.time + ' s'"
              ></a-button>
            </a-col>
          </a-row>
        </a-tab-pane>
      </a-tabs>

      <a-form-item style='margin-top: 24px'>
        <a-button
          size='large'
          type='primary'
          htmlType='submit'
          class='login-button'
          :loading='state.loginBtn'
          :disabled='state.loginBtn'
        >登 录
        </a-button
        >
      </a-form-item>

      <a-form-item>
<!--        <a-checkbox v-decorator="['rememberMe', { valuePropName: 'checked' }]">-->
<!--          {{ $t('user.login.remember-me') }}-->
<!--        </a-checkbox>-->
        <router-link :to="{ name: 'ForgetPwdPhone', params: { user: 'aaa' } }" class='forge-password'
                     style='float: left'
        >忘记密码
        </router-link>

        <router-link class='register' style='float: right' :to="{ name: 'register' }">{{ $t('user.login.signup') }}</router-link>

        <!--        <a-button @click='forgetPwdClick'>忘记密码</a-button>-->
      </a-form-item>

<!--      <div class='user-login-other'>-->
<!--        &lt;!&ndash;        <span>{{ $t('user.login.sign-in-with') }}</span>&ndash;&gt;-->
<!--        &lt;!&ndash;        <a>&ndash;&gt;-->
<!--        &lt;!&ndash;          <a-icon class='item-icon' type='alipay-circle'></a-icon>&ndash;&gt;-->
<!--        &lt;!&ndash;        </a>&ndash;&gt;-->
<!--        &lt;!&ndash;        <a>&ndash;&gt;-->
<!--        &lt;!&ndash;          <a-icon class='item-icon' type='taobao-circle'></a-icon>&ndash;&gt;-->
<!--        &lt;!&ndash;        </a>&ndash;&gt;-->
<!--        &lt;!&ndash;        <a>&ndash;&gt;-->
<!--        &lt;!&ndash;          <a-icon class='item-icon' type='weibo-circle'></a-icon>&ndash;&gt;-->
<!--        &lt;!&ndash;        </a>&ndash;&gt;-->
<!--        <router-link class='register' :to="{ name: 'register' }">{{ $t('user.login.signup') }}</router-link>-->
<!--      </div>-->
    </a-form>

    <two-step-captcha
      v-if='requiredTwoStepCaptcha'
      :visible='stepCaptchaVisible'
      @success='stepCaptchaSuccess'
      @cancel='stepCaptchaCancel'
    ></two-step-captcha>

    <!--    &lt;!&ndash; 悬挂备案号部分 &ndash;&gt;-->
    <!--    <a-divider></a-divider>-->
    <!--    <div style='margin:10px 0px;text-align:center'>-->
    <!--      <a href='http://beian.miit.gov.cn/' style='text-decoration: none;color:black'-->
    <!--         target='_blank'>湘ICP备2023023480号-2 </a>-->
    <!--    </div> &lt;!&ndash; 悬挂备案号部分 &ndash;&gt;-->
  </div>


</template>

<script>
import md5 from 'md5'
import TwoStepCaptcha from '@/components/tools/TwoStepCaptcha'
import { mapActions } from 'vuex'
import { timeFix, getSecodes } from '@/utils/util'
import { getSmsCaptchaOfLogin, get2step, login, phoneLogin } from '@/api/login'
import { scorePassword } from '@/utils/util' // 存储密码等级

import storage from 'store'
import { ACCESS_TOKEN } from '@/store/mutation-types'

const levelNames = {
  0: 'user.password.strength.short',
  1: 'user.password.strength.low',
  2: 'user.password.strength.medium',
  3: 'user.password.strength.strong'
}

export default {
  components: {
    TwoStepCaptcha
  },
  data() {
    return {
      customActiveKey: 'tab1',
      loginBtn: false,
      // login type: 0 email, 1 username, 2 telephone
      loginType: 0,
      isLoginError: false,
      requiredTwoStepCaptcha: false,
      stepCaptchaVisible: false,
      form: this.$form.createForm(this),
      state: {
        time: 60,
        loginBtn: false,
        // login type: 0 email, 1 username, 2 telephone
        loginType: 0,
        smsSendBtn: false,
        level: 0,
        passwordLevel: 0
      }
    }
  },
  mounted() {
    this.form.setFieldsValue({ username: 'admin' })
    this.form.setFieldsValue({ password: 'admin' })
  },
  computed: {
    passwordLevelName() {
      return levelNames[this.state.passwordLevel]
    }
  },
  methods: {
    forgetPwdClick() {
      console.log('点击忘记密码')
      this.$router.push({ path: '/user/recover' })
    },
    ...mapActions(['Login', 'Logout']),
    // handler
    handleUsernameOrEmail(rule, value, callback) {
      const { state } = this
      const regex = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\.[a-zA-Z0-9_-]{2,3}){1,2})$/
      if (regex.test(value)) {
        state.loginType = 0
      } else {
        state.loginType = 1
      }
      callback()
    },
    handleTabClick(key) {
      this.customActiveKey = key
      // this.form.resetFields()
    },

    /**
     * 登录按钮
     */
    handleSubmit(e) {
      e.preventDefault()
      const {
        form: { validateFields },
        state,
        customActiveKey,
        Login
      } = this

      state.loginBtn = true

      const validateFieldsKey = customActiveKey === 'tab1' ? ['username', 'password'] : ['mobile', 'captcha']

      validateFields(validateFieldsKey, { force: true }, (err, values) => {
        if (!err) {
          console.log('login form', values)
          const loginParams = { ...values }
          console.log('validateFieldsKey: ', validateFieldsKey)

          if (this.customActiveKey === 'tab1') {
            // 账号和密码登录
            login(loginParams)
              .then((res) => this.loginSuccess(res, loginParams))
              .catch((err) => {
              })
              .finally(() => {
                state.loginBtn = false
              })
          } else {
            // 手机验证码登录
            //alert(this.customActiveKey)
            // phoneLogin(values)
            phoneLogin(values)
              .then((res) => this.loginSuccessAndPhone(res))
              .catch((err) => {
              })
              .finally(() => {
                state.loginBtn = false
              })
          }
        } else {
          setTimeout(() => {
            state.loginBtn = false
          }, 600)
        }
      })
    },

    getCaptcha(e) {
      e.preventDefault()
      const {
        form: { validateFields },
        state
      } = this

      validateFields(['mobile'], { force: true }, (err, values) => {
        if (!err) {
          state.smsSendBtn = true

          const interval = window.setInterval(() => {
            if (state.time-- <= 0) {
              state.time = 60
              state.smsSendBtn = false
              window.clearInterval(interval)
            }
          }, 1000)

          const hide = this.$message.loading('验证码发送中..', 0)
          getSmsCaptchaOfLogin(values.mobile)
            .then((res) => {
              setTimeout(hide, 2500)

              if (res.code === '200') {
                this.$notification['success']({
                  message: '提示',
                  description: '验证码获取成功，您的验证码为：' + res.data,
                  duration: 8
                })
              } else {
                this.$notification['error']({
                  message: '提示',
                  description: '验证码获取失败, ' + res.msg,
                  duration: 8
                })
              }
            })
            .catch((err) => {
              setTimeout(hide, 1)
              clearInterval(interval)
              state.time = 60
              state.smsSendBtn = false
              this.requestFailed(err)
            })
        }
      })
    },
    stepCaptchaSuccess() {
      this.loginSuccess()
    },
    stepCaptchaCancel() {
      this.Logout().then(() => {
        this.loginBtn = false
        this.stepCaptchaVisible = false
      })
    },

    // 获取密码强度
    handlePasswordLevelStr(value) {
      if (!value) {
        this.$message.error('密码不能为空!')
        return
      }
      console.log('密码强度 ; ', scorePassword(value))
      if (value.length >= 6) {
        if (scorePassword(value) >= 30) {
          this.state.level = 1
        }
        if (scorePassword(value) >= 60) {
          this.state.level = 2
        }
        if (scorePassword(value) >= 80) {
          this.state.level = 3
        }
      } else {
        this.state.level = 0
      }
      this.state.passwordLevel = this.state.level
    },
    loginSuccessAndPhone(res) {
      if (res.code === '200') {
        // this.$router.push({ path: '/' })
        // this.$cookie.set("user",res.data,{expires: getSecodes(60)})  //
        // this.$cookie.set('user', res.data.phone, { expires: 1 }) // 存储手机号  默认是天,当然也可以获取日期时间,秒分钟小时
        // storage.set('user', res.data.phone, new Date().getTime() + 7 * 24 * 60 * 60 * 1000)
        storage.set(ACCESS_TOKEN, res.data.token, new Date().getTime() + 7 * 24 * 60 * 60 * 1000)
        // this.$store.commit('SET_USERNAME',res.data.phone)
        this.$cookie.set('user', res.data.username, { expires: 1 }) // 存储手机号  默认是天,当然也可以获取日期时间,秒分钟小时
        storage.set('user', res.data.username, new Date().getTime() + 7 * 24 * 60 * 60 * 1000)
        this.$store.commit('SET_USERNAME', res.data.username)
        // 设置vuex 令牌
        this.$store.commit('SET_TOKEN', res.data.token)
        if (res.data.role === '1') {
          this.$router.push({ name: 'adminHome' })
        }
        if (res.data.role === '0') {
          this.$router.push({ name: 'userHome' })
        }
        // 延迟 1 秒显示欢迎信息
        setTimeout(() => {
          this.$notification.success({
            message: '欢迎',
            description: `${timeFix()}，欢迎回来`
          })
        }, 1000)
        this.isLoginError = false
      } else {
        this.requestFailed(res.msg)
      }
      // check res.homePage define, set $router.push name res.homePage
      // Why not enter onComplete
      /*
      this.$router.push({ name: 'analysis' }, () => {
        console.log('onComplete')
        this.$notification.success({
          message: '欢迎',
          description: `${timeFix()}，欢迎回来
        })
      })
      */
    },
    loginSuccess(res, loginParams) {
      if (res.code === '200') {
        // this.$cookie.set("user",res.data,{expires: getSecodes(60)})  //
        this.$cookie.set('user', res.data.username, { expires: 1 }) // 存储账号  默认是天,当然也可以获取日期时间,秒分钟小时
        this.$store.commit('SET_USERNAME', res.data.username)
        // 使用storage本地存储,设置token 7天后过期
        // storage.set(ACCESS_TOKEN, res.data.token, new Date().getTime() + 7 * 24 * 60 * 60 *
        // 1000)
        storage.set(ACCESS_TOKEN, res.data.token, new Date().getTime() + 7 * 24 * 60 * 60 * 1000)
        storage.set('user', res.data.username, new Date().getTime() + 7 * 24 * 60 * 60 * 1000)
        // 设置vuex 令牌
        this.$store.commit('SET_TOKEN', res.data.token)

        this.handlePasswordLevelStr(loginParams.password) // 获取密码强度字符串
        this.$cookie.set('pwdState', this.passwordLevelName)
        if (res.data.role === '1') {
          this.$router.push({ name: 'adminHome' })
        }
        if (res.data.role === '0') {
          this.$router.push({ name: 'userHome' })
        }
        // 延迟 1 秒显示欢迎信息
        setTimeout(() => {
          this.$notification.success({
            message: '欢迎',
            description: `${timeFix()}，欢迎回来`
          })
        }, 1000)
        this.isLoginError = false
      } else {
        this.requestFailed(res.msg)
      }
      // check res.homePage define, set $router.push name res.homePage
      // Why not enter onComplete
      /*
      this.$router.push({ name: 'analysis' }, () => {
        console.log('onComplete')
        this.$notification.success({
          message: '欢迎',
          description: `${timeFix()}，欢迎回来
        })
      })
      */
    },

    requestFailed(err) {
      this.isLoginError = true
      this.$notification['error']({
        message: '错误',
        description: err,
        duration: 4
      })
    }
  }
}
</script>

<style lang='less' scoped>
.user-layout-login {
  label {
    font-size: 14px;
  }

  .getCaptcha {
    display: block;
    width: 100%;
    height: 40px;
  }

  .forge-password {
    font-size: 14px;
  }

  button.login-button {
    padding: 0 15px;
    font-size: 16px;
    height: 40px;
    width: 100%;
  }

  .user-login-other {
    text-align: left;
    margin-top: 24px;
    line-height: 22px;

    .item-icon {
      font-size: 24px;
      color: rgba(0, 0, 0, 0.2);
      margin-left: 16px;
      vertical-align: middle;
      cursor: pointer;
      transition: color 0.3s;

      &:hover {
        color: #1890ff;
      }
    }

    .register {
      float: right;
    }
  }
}
</style>
