<template>
  <div style='margin-bottom:150px'>
    <div style='margin-bottom:50px'>
      <a-steps :current='currentStep' style='width: 900px; margin: 0 auto'>
        <a-step title='手机号' description='验证当前手机号'>
          <a-icon slot='icon' type='phone' />
        </a-step>
        <a-step title='QQ邮箱' description='验证手机号注册过的QQ邮箱'>
          <a-icon slot='icon' type='phone' />
        </a-step>
        <a-step title='完成' description='您的密码已发送至您的邮箱' />
      </a-steps>
    </div>

    <router-view @child-click='handleChildClick' />
  </div>
</template>

<script>
export default {
  data() {
    return {
      currentStep: 0
    }
  },
  methods: {
    handleChildClick(parameter) {
      // 在这里处理从子组件传递过来的参数
      console.log('子组件传递过来的参数: ', parameter)
      if (parameter === '1') {
        this.currentStep = 1
      }
      if (parameter === '2') {
        this.currentStep = 2
      }
      if (parameter === '3') {
        this.currentStep = 3
      }
    }
  }
}
</script>

<style scoped></style>
