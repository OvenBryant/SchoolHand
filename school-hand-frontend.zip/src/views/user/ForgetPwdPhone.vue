<template>
  <div style="display: flex; justify-content: center">
    <a-button size="large" disabled style="border: none">手机号</a-button>

    <a-spin tip="Loading..." :spinning="spinning">
      <a-input-search
        v-model="phone"
        style="width: 300px"
        placeholder="请输入手机号找回密码"
        size="large"
        @search="validCurrentPhone"
      >
        <a-button type="primary" slot="enterButton"> Next </a-button>
      </a-input-search>
    </a-spin>
  </div>
</template>

<script>
import { validPwdPhone } from '@/api/forgetPwd'

export default {
  data() {
    return {
      phone: '15674815919',
      spinning: false,
    }
  },
  methods: {
    validCurrentPhone() {
      if (!this.phone) {
        this.$message.error('手机号不能为空')
      }

      this.spinning = true

      setTimeout(() => {
        this.handleMethod()
      }, 1500) // 2000毫秒等于2秒钟
    },

    handleMethod() {
      validPwdPhone(this.phone)
        .then((res) => {
          if (res.code === '200') {
            // 在这里触发自定义事件，将参数传递给父组件
            this.$emit('child-click', '1')
            this.$router.push({ name: 'ForgetPwdEmail', params: { phone: this.phone } })
          } else {
            this.$notification['error']({
              message: '提示',
              description: res.msg,
              duration: 2,
            })
          }
        })
        .catch(() => {})
        .finally(() => {
          this.spinning = false
        })
    },
  },
}
</script>

<style scoped></style>
