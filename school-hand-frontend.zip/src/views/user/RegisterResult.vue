<template>
  <a-result
    :isSuccess="true"
    :content="false"
    :title="username"
    :sub-title="description">

    <template #extra>
      <!-- <a-button size="large" type="primary">查看邮箱</a-button> -->
      <a-button size="large" style="margin-left: 8px" @click="goHomeHandle">返回首页</a-button>
    </template>

  </a-result>
</template>

<script>
export default {
  name: 'RegisterResult',
  data () {
    return {
      description:'',
      // description: '激活邮件已发送到你的邮箱中，邮件有效期为24小时。请及时登录邮箱，点击邮件中的链接激活帐户。',
      username:'',
    }
  },

  created () {
    this.username = `你的账户为：${this.$route.params.username?this.$route.params.username:'xxx'}  注册成功`;
  },
  methods: {
    goHomeHandle () {
      this.$router.push({ name: 'login' })
    }
  }
}
</script>

<style scoped>

</style>
