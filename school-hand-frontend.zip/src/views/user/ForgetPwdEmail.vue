<template>
  <div>
    <div style="display: flex; justify-content: center">
      <a-button size="large" disabled style="border: none">当前手机号：</a-button>
      <span style="width: 300px; font-size: 24px">{{ currentPhone }}</span>
    </div>

    <div style="display: flex; justify-content: center">
      <a-button size="large" disabled style="border: none">QQ邮箱：</a-button>
      <a-spin tip="Loading..." :spinning="spinning">
        <a-input-search
          v-model="email"
          style="width: 300px"
          placeholder="请输入QQ邮箱找回密码"
          size="large"
          @search="validCurrentEmail"
        >
          <a-button type="primary" slot="enterButton"> 找回密码 </a-button>
        </a-input-search>
      </a-spin>
    </div>
  </div>
</template>

<script>
import { validPwdEmail } from '@/api/forgetPwd'

export default {
  data() {
    return {
      email: '3063899248@qq.com',
      currentPhone: '',
      spinning: false,
    }
  },
  created() {
    // this.currentPhone = this.$route.params.phone
    
    // // 获取当前路由路径
    //   const currentPath = this.$route.path
     
    //   // 使用 $router.push 跳转到新的路径
    //   this.$router.push({
    //     path: `${currentPath}/${this.currentPhone}/2`,
    //   })

 // 定义原始路由的路径
  const originalPath = '/user/recover/ForgetPwdEmail';

  // 检查当前路由是否以原始路由路径开头
  //const isOriginalRoute = currentPath.startsWith(originalPath);

  //if (isOriginalRoute) {
    // 获取当前路由中的phone参数 刷新的时候,输入框里面的手机号还有，有可能是动态路由的原因
    this.currentPhone = this.$route.params.phone;
    

    // 使用 $router.push 跳转到新的路径，保留原始路由并添加新的phone和step参数
    this.$router.push({
      path: `${originalPath}/${this.currentPhone}`,
    });

     this.$emit('child-click', '1') // 更新父组件进度条
 // }
  },

  methods: {
    validCurrentEmail() {
      
      this.spinning = true
      setTimeout(() => {
        this.handleMethod()
      }, 1500) // 2000毫秒等于2秒钟
    },
    handleMethod() {
      validPwdEmail(this.currentPhone, this.email)
        .then((res) => {
          console.log('email: ', res)
          if (res.code === '200') {
            this.$emit('child-click', '2') // 更新父组件进度条
            this.$router.push({ name: 'ForgetPwdSuccess', params: { result: res.data } })
          } else {
            this.$notification['error']({
              message: '提示',
              description: res.msg,
              duration: 2,
            })
          }
        })
        .catch(() => {})
        .finally(() => {
          this.spinning = false
        })
    },
  },
}
</script>

<style scoped></style>
