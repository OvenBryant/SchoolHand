export default {
  'addUser.user.nickname.required': '请输入用户昵称'
}