import basicForm from './form/basicForm'

export default {
    ...basicForm
  }
