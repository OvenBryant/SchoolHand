export default {
  'addUser.user.nickname.required': 'Please enter the user nickname'
}