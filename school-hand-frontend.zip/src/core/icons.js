/**
 * Custom icon list
 * All icons are loaded here for easy management
 * @see https://vue.ant.design/components/icon/#Custom-Font-Icon
 *
 * 自定义图标加载表
 * 所有图标均从这里加载，方便管理
 */
import bxAnaalyse from '@/assets/icons/bx-analyse.svg?inline' // path to your '*.svg?inline' file.
import home from '@/assets/icons/home.svg?inline'
import goods from '@/assets/icons/goods.svg?inline'
import noticeIcon from '@/assets/icons/noticeIcon.svg?inline'
import dictIcon from '@/assets/icons/dictIcon.svg?inline'
import productIcon from '@/assets/icons/productIcon.svg?inline'
import xtgl from '@/assets/icons/xtgl.svg?inline'
import yhgl from '@/assets/icons/yhgl.svg?inline'
import mxtgl from '@/assets/icons/mxtgl.svg?inline'
import rzgl from '@/assets/icons/rzgl.svg?inline'
import fb from '@/assets/icons/fb.svg?inline'
import gm from '@/assets/icons/gm.svg?inline'
import lxkf from '@/assets/icons/lxkf.svg?inline'

export { bxAnaalyse, home, goods, noticeIcon, dictIcon, productIcon, xtgl, yhgl, mxtgl, rzgl, fb, gm, lxkf }
