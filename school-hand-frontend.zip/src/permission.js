import router, { resetRouter } from './router'
import store from './store'
import storage from 'store'
import NProgress from 'nprogress' // progress bar
import '@/components/NProgress/nprogress.less' // progress bar custom style
import notification from 'ant-design-vue/es/notification'
import { setDocumentTitle, domTitle } from '@/utils/domUtil'
import { ACCESS_TOKEN } from '@/store/mutation-types'
import { i18nRender } from '@/locales'

NProgress.configure({ showSpinner: false }) // NProgress Configuration

const allowList = ['login', 'register', 'registerResult', 'ForgetPwdPhone','ForgetPwdEmail','ForgetPwdSuccess'] // no redirect allowList
const loginRoutePath = '/user/login'
// const defaultRoutePath = '/dashboard/workplace'
const defaultRoutePath = '/account'

router.beforeEach((to, from, next) => {
  NProgress.start() // start progress bar
  to.meta && typeof to.meta.title !== 'undefined' && setDocumentTitle(`${i18nRender(to.meta.title)} - ${domTitle}`)
  /* has token */
  const token = storage.get(ACCESS_TOKEN)
  if (token) {
    if (to.path === loginRoutePath) {
      next({ path: defaultRoutePath })
      NProgress.done()
    } else {
      if (store.getters.role !== 0 && store.getters.role !== 1) {
        // request login userInfo
        console.log('--------permission角色不等0,1-------- 开始执行')
        store
          .dispatch('GetInfo')
          .then((res) => {
            console.log('permission: ', res)
            // const roles = res.data.role === '1' ? ['1'] : ['0']
            const roles = res.data.role === '1' ? '1' : '0'
            store
              .dispatch('GenerateRoutes', roles)
              .then(() => {
                // resetRouter() // 重置路由 防止退出重新登录或者 token 过期后页面未刷新，导致的路由重复添加
                // router.addRouters(store.getters.addRouters)
                next()
              })
              .catch((error) => {
                console.error('GenerateRoutes 错误: ', error)
                notification.error({
                  message: '操作提示',
                  description: '请求角色路由失败，请重试'
                })
                // 失败时，获取用户信息失败时，调用登出，来清空历史保留信息
                store.dispatch('Logout').then(() => {
                  next()
                })
              })
          })
          .catch((error) => {
            console.error('GetInfo 错误: ', error)
            // 失败时，获取用户信息失败时，调用登出，来清空历史保留信息
            notification.error({
              message: '操作提示',
              description: '请求用户信息失败，请重试'
            })
            store.dispatch('Logout').then(() => {
              next()
            })
          })
      } else {
        console.log('store.getters.role结果: ', store.getters.role)
        next()
      }
    }

    // }
  } else {
    console.log('token不存在....')
    if (allowList.includes(to.name)) {
      // 在免登录名单，直接进入
      next()
    } else {
      next({ path: loginRoutePath })
      // NProgress.done() // if current page is login will not trigger afterEach hook, so manually handle it
      // next()
    }
  }
})

router.afterEach(() => {
  NProgress.done() // finish progress bar
})
