// eslint-disable-next-line
import { UserLayout, BasicLayout, BlankLayout } from '@/layouts'
import {
  bxAnaalyse,
  home,
  noticeIcon,
  dictIcon,
  productIcon,
  xtgl,
  yhgl,
  mxtgl,
  rzgl,
  fb,
  gm,
  lxkf
} from '@/core/icons'

const RouteView = {
  name: 'RouteView',
  render: (h) => h('router-view')
}

export const asyncRouterMap = [
  {
    path: '/',
    name: 'index',
    component: BasicLayout,
    meta: { title: 'menu.home', permission: ['0', '1'] },
    // redirect: '/admin/home',
    children: [
      {
        path: '/admin/home',
        name: 'adminHome',
        component: () => import('@/views/dashboard/AdminHome'),
        meta: { title: '首 页', keepAlive: true, icon: home, permission: ['1'] }
      },
      {
        path: '/user/home',
        name: 'userHome',
        component: () => import('@/views/dashboard/UserHome'),
        meta: { title: '首 页', keepAlive: true, icon: home, permission: ['0'] }
      },
      {
        path: '/userAdminProduct/add',
        name: 'userAdminProductAdd',
        component: () => import('@/views/product/user/UserSellTabs'),
        meta: { title: '发布商品', keepAlive: true, icon: fb, permission: ['0'] }
      },
      {
        path: '/userPubProductAuditsDetailed',
        name: 'userPubProductAuditsDetailed',
        hidden: true,
        component: () => import('@/views/product/user/UserPubProductAuditsDetailed'),
        meta: { title: '审核状态详情', keepAlive: true, hidden: true, permission: ['0'] }
      },
      {
        path: '/userUpdateAuditsStatus',
        name: 'userUpdateAuditsStatus',
        hidden: true,
        component: () => import('@/views/product/user/UserUpdateAuditsStatus'),
        meta: { title: '修改审核', keepAlive: true, hidden: true, permission: ['0'] }
      },
      // 普通用户商品列表-商品购买
      {
        path: '/userAdminProduct/buy',
        name: 'userAdminProductBuy',
        component: () => import('@/views/product/user/UserBuy'),
        meta: { title: '购买商品', keepAlive: true, icon: gm, permission: ['0'] }
      },
      // 客户端的个人设置
      {
        path: '/userAccount',
        component: RouteView,
        redirect: '/userAccount/settings',
        name: 'userAccount',
        meta: { title: '个人信息管理', icon: 'user', keepAlive: true, permission: ['0'] },
        children: [
          {
            path: '/userAccount/settings',
            name: 'settings',
            component: () => import('@/views/account/settings/Index'),
            meta: { title: 'menu.account.settings', hideHeader: true, permission: ['0'] },
            redirect: '/userAccount/settings/basic',
            hideChildrenInMenu: true,
            children: [
              {
                path: '/userAccount/settings/basic',
                name: 'BasicSettings',
                component: () => import('@/views/account/settings/BasicSetting'),
                meta: { title: 'account.settings.menuMap.basic', hidden: true, permission: ['0'] }
              },
              {
                path: '/userAccount/settings/security',
                name: 'SecuritySettings',
                component: () => import('@/views/account/settings/Security'),
                meta: {
                  title: 'account.settings.menuMap.security',
                  hidden: true,
                  keepAlive: true,
                  permission: ['0']
                }
              }
            ]
          },
          // 普通用户商品列表-我的商品
          {
            path: '/MyProductTabs',
            name: 'MyProductTabs',
            component: () => import('@/views/product/user/MyProductTabs'),
            meta: { title: '商品管理', keepAlive: true, permission: ['0'] }
          }
        ]
      },
      // 普通用户商品列表-联系管理员
      {
        path: '/contactAdmin',
        name: 'contactAdmin',
        component: () => import('@/views/contactAdmin/ContactAdmin'),
        meta: { title: '联系客服', keepAlive: true, icon: lxkf, permission: ['0'] }
      },
      // 普通用户商品列表-我要买详细信息
      {
        path: 'userAdminProduct/buy/More',
        name: 'userAdminProductBuyMore',
        hidden: true,
        component: () => import('@/views/product/user/BuyMore'),
        meta: { title: '我要买详细信息', keepAlive: true, icon: home, permission: ['0'] }
      },
      {
        path: 'userAdminProduct/buy/More/ShopCart',
        name: 'userAdminProductBuyMoreShopCart',
        hidden: true,
        component: () => import('@/views/product/user/ShoppingCart'),
        meta: { title: '购物车', keepAlive: true, icon: home, permission: ['0'] }
      },
      {
        path: 'userAdminProduct/buy/More/ContactSell',
        name: 'userAdminProductBuyMoreContactSell',
        hidden: true,
        component: () => import('@/views/product/user/ContactSell'),
        meta: { title: '联系卖家', keepAlive: true, icon: home, permission: ['0'] }
      },
      {
        path: '/userAdminManager',
        name: 'userAdminManager',
        component: RouteView,
        meta: { title: '系统管理', keepAlive: true, icon: mxtgl, permission: ['1'] },
        children: [
          {
            path: '/userAdmin',
            name: 'userAdmin',
            redirect: '/userAdmin/user',
            component: RouteView,
            // meta: { title: 'menu.dashboard', keepAlive: true, icon: bxAnaalyse, permission: ['1'] },
            meta: { title: '用户管理', keepAlive: true, icon: yhgl, permission: ['1'] },
            children: [
              {
                path: '/userAdmin/user',
                name: 'userAdminList',
                component: () => import('@/views/list/TableList'),
                meta: { title: '用户列表', keepAlive: true, permission: ['1'] }
              },
              {
                path: '/userAdmin/editUser/:oneUserInfo',
                name: 'userAdminEditUser',
                hidden: true,
                component: () => import('@/views/list/table/EditUser'),
                meta: { title: '用户修改隐藏', keepAlive: true, permission: ['1'] }
              },
              {
                path: '/userAdmin/addUser',
                name: 'userAdminAddUser',
                component: () => import('@/views/list/table/AddUser'),
                meta: { title: '新增用户', keepAlive: true, permission: ['1'] }
              }
            ]
          },
          {
            path: '/userAdmin/logManage',
            name: 'userAdminLogsManage',
            redirect: '/userAdminLogsManage/log',
            component: RouteView,
            meta: { title: '日志管理', keepAlive: true, icon: rzgl, permission: ['1'] },
            children: [
              {
                path: '/userAdminLogsManage/log',
                name: 'userAdminOperLog',
                component: () => import('@/views/log/Logs'),
                meta: { title: '操作日志', keepAlive: true, permission: ['1'] }
              }
            ]
          },
          {
            path: '/userAdminNotice',
            name: 'userAdminNotice',
            component: () => import('@/views/notice/index'),
            meta: { title: '通知公告', keepAlive: true, icon: noticeIcon, permission: ['1'] }
          },
          {
            path: '/userAdminDict',
            name: 'userAdminDict',
            component: () => import('@/views/dict/Dict'),
            meta: { title: '字典管理', keepAlive: true, icon: dictIcon, permission: ['1'] }
          },
          {
            path: '/userAdminProduct',
            name: 'userAdminProduct',
            component: RouteView,
            meta: { title: '商品管理', keepAlive: true, icon: productIcon, permission: ['1'] },
            children: [
              {
                path: '/userAdminProduct/list',
                name: 'userAdminProductList',
                component: () => import('@/views/product/admin/list'),
                meta: { title: '商品列表', keepAlive: true, permission: ['1'] }
              },
              {
                path: '/userAdminProduct/AddProduct',
                name: 'userAdminProductAddProduct',
                component: () => import('@/views/product/admin/AddProduct'),
                meta: { title: '添加商品', keepAlive: true, permission: ['1'] }
              },
              {
                path: '/userAdminProduct/AdminAuditsTabs',
                name: 'userAdminProductAdminAuditsTabs',
                component: () => import('@/views/product/admin/AdminAuditsTabs'),
                meta: { title: '商品审核', keepAlive: true, permission: ['1'] }
              },
              {
                path: '/userAdminProduct/AdminAuditsDetailed',
                name: 'userAdminProductAdminAuditsDetailed',
                hidden: true,
                component: () => import('@/views/product/admin/AuditsDetailed'),
                meta: { title: '审核详情', hidden: true, keepAlive: true, permission: ['1'] }
              },
              {
                path: '/userAdminProduct/AdminAuditsDetailedSuccess',
                name: 'userAdminProductAdminAuditsDetailedSuccess',
                hidden: true,
                component: () => import('@/views/product/admin/AuditsDetailedSuccess'),
                meta: { title: '成功详情', hidden: true, keepAlive: true, permission: ['1'] }
              },
              {
                path: '/userAdminProduct/AdminAuditsDetailedError',
                name: 'userAdminProductAdminAuditsDetailedError',
                hidden: true,
                component: () => import('@/views/product/admin/AuditsDetailedError'),
                meta: { title: '失败详情', hidden: true, keepAlive: true, permission: ['1'] }
              },
              {
                path: '/userAdminProduct/more',
                name: 'userAdminProductMore',
                hidden: true,
                component: () => import('@/views/product/admin/ProductMore'),
                meta: { title: '商品详细', keepAlive: true, permission: ['1'] }
              }
            ]
          },
          // {
          //   path: '/result',
          //   name: 'result',
          //   component: RouteView,
          //   redirect: '/result/success',
          //   meta: { title: 'menu.result', icon: 'check-circle-o', permission: ['1'] },
          //   children: [
          //     {
          //       path: '/result/success',
          //       name: 'ResultSuccess',
          //       component: () => import(/* webpackChunkName: "result" */ '@/views/result/Success'),
          //       meta: { title: 'menu.result.success', keepAlive: false, hiddenHeaderContent: true, permission: ['1'] }
          //     },
          //     {
          //       path: '/result/fail',
          //       name: 'ResultFail',
          //       component: () => import(/* webpackChunkName: "result" */ '@/views/result/Error'),
          //       meta: { title: 'menu.result.fail', keepAlive: false, hiddenHeaderContent: true, permission: ['1'] }
          //     }
          //   ]
          // },
          {
            // path: '/account',
            path: '/account',
            component: RouteView,
            redirect: '/account/settings',
            name: 'account',
            meta: { title: 'menu.account', icon: 'user', keepAlive: true, permission: ['0', '1'] },
            children: [
              // {
              //   path: '/account/center',
              //   name: 'center',
              //   component: () => import('@/views/account/center'),
              //   meta: { title: 'menu.account.center', keepAlive: true, permission: ['user'] }
              // },
              {
                path: '/account/settings',
                name: 'settings',
                component: () => import('@/views/account/settings/Index'),
                meta: { title: 'menu.account.settings', hideHeader: true, permission: ['0', '1'] },
                redirect: '/account/settings/basic',
                hideChildrenInMenu: true,
                children: [
                  {
                    path: '/account/settings/basic',
                    name: 'BasicSettings',
                    component: () => import('@/views/account/settings/BasicSetting'),
                    meta: { title: 'account.settings.menuMap.basic', hidden: true, permission: ['0', '1'] }
                  },
                  {
                    path: '/account/settings/security',
                    name: 'SecuritySettings',
                    component: () => import('@/views/account/settings/Security'),
                    meta: {
                      title: 'account.settings.menuMap.security',
                      hidden: true,
                      keepAlive: true,
                      permission: ['0', '1']
                    }
                  }
                  // {
                  //   path: '/account/settings/custom',
                  //   name: 'CustomSettings',
                  //   component: () => import('@/views/account/settings/Custom'),
                  //   meta: {
                  //     title: 'account.settings.menuMap.custom',
                  //     hidden: true,
                  //     keepAlive: true,
                  //     permission: ['0', '1']
                  //   }
                  // },
                  // {
                  //   path: '/account/settings/binding',
                  //   name: 'BindingSettings',
                  //   component: () => import('@/views/account/settings/Binding'),
                  //   meta: {
                  //     title: 'account.settings.menuMap.binding',
                  //     hidden: true,
                  //     keepAlive: true,
                  //     permission: ['0', '1']
                  //   }
                  // },
                  // {
                  //   path: '/account/settings/notification',
                  //   name: 'NotificationSettings',
                  //   component: () => import('@/views/account/settings/Notification'),
                  //   meta: {
                  //     title: 'account.settings.menuMap.notification',
                  //     hidden: true,
                  //     keepAlive: true,
                  //     permission: ['0', '1']
                  //   }
                  // }
                ]
              }
            ]
          }
        ]
      },
      {
        path: '/ManagerApi',
        name: 'ManagerApi',
        redirect: '/ManagerApi/knife4j',
        component: RouteView,
        meta: { title: '系统工具', keepAlive: true, icon: xtgl, permission: ['1'] },
        children: [
          {
            path: '/knife4j',
            name: 'knife4j',
            component: () => import('@/views/sysTool/knife4j'),
            // meta: { title: 'menu.dashboard', keepAlive: true, icon: bxAnaalyse, permission: ['1'] },
            meta: { title: '系统接口', keepAlive: false, permission: ['1'] }
          }
        ]
      }
    ]
  }
  // {
  //   path: '*',
  //   redirect: '/404',
  //   hidden: true,
  // },
]

/**
 * 基础路由
 * @type { *[] }
 */
export const constantRouterMap = [
  {
    path: '/user',
    component: UserLayout,
    redirect: '/user/login',
    hidden: true,
    children: [
      {
        path: 'login',
        name: 'login',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Login')
      },
      {
        path: 'register',
        name: 'register',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Register')
      },
      {
        path: 'register-result',
        name: 'registerResult',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/RegisterResult')
      },
      {
        path: 'recover',
        name: 'recover',
        redirect: '/user/recover/ForgetPwdPhone',
        component: () => import('@/views/user/FindPwdStep'),
        children: [
          {
            path: 'ForgetPwdPhone',
            name: 'ForgetPwdPhone',
            component: () => import('@/views/user/ForgetPwdPhone')
          },
          {
            path: 'ForgetPwdEmail',
            name: 'ForgetPwdEmail',
            component: () => import('@/views/user/ForgetPwdEmail')
          },
          {
            path: 'ForgetPwdEmail/:phone',
            name: 'ForgetPwdEmail',
            component: () => import('@/views/user/ForgetPwdEmail')
          },
          {
            path: 'ForgetPwdSuccess',
            name: 'ForgetPwdSuccess',
            component: () => import('@/views/user/ForgetPwdSuccess')
          }
        ]
      }
    ]
  },
  {
    path: '*',
    redirect: '/404',
    hidden: true
  },
  {
    path: '/404',
    component: () => import(/* webpackChunkName: "fail" */ '@/views/exception/404')
  }
]
